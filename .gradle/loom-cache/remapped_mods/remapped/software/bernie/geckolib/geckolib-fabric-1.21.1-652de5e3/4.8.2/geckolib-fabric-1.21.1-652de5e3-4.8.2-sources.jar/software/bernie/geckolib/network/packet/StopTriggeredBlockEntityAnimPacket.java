package software.bernie.geckolib.network.packet;

import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.GeckoLibConstants;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.util.ClientUtil;

import java.util.function.Consumer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.math.BlockPos;

public record StopTriggeredBlockEntityAnimPacket(BlockPos pos, String controllerName, String animName) implements MultiloaderPacket {
    public static final Id<StopTriggeredBlockEntityAnimPacket> TYPE = new Id<>(GeckoLibConstants.id("stop_triggered_blockentity_anim"));
    public static final PacketCodec<PacketByteBuf, StopTriggeredBlockEntityAnimPacket> CODEC = PacketCodec.tuple(
            BlockPos.PACKET_CODEC, StopTriggeredBlockEntityAnimPacket::pos,
            PacketCodecs.STRING, StopTriggeredBlockEntityAnimPacket::controllerName,
            PacketCodecs.STRING, StopTriggeredBlockEntityAnimPacket::animName,
            StopTriggeredBlockEntityAnimPacket::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return TYPE;
    }

    @Override
    public void receiveMessage(@Nullable PlayerEntity sender, Consumer<Runnable> workQueue) {
        workQueue.accept(() -> {
            if (ClientUtil.getLevel().getBlockEntity(this.pos) instanceof GeoBlockEntity blockEntity)
                blockEntity.stopTriggeredAnim(this.controllerName.isEmpty() ? null : this.controllerName, this.animName.isEmpty() ? null : this.animName);
        });
    }
}