package software.bernie.geckolib.mixin.client;

import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.BuiltinModelItemRenderer;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import software.bernie.geckolib.animatable.client.GeoRenderProvider;

/**
 * Injection into the BEWLR rendering point to defer to GeckoLib item rendering if applicable
 * <p>
 * Cancels the remainder of the render call if GeckoLib renders, otherwise does nothing
 */
@Mixin(BuiltinModelItemRenderer.class)
public class BlockEntityWithoutLevelRendererMixin {
    @Inject(method = "renderByItem", at = @At("HEAD"), cancellable = true)
    public void geckolib$renderGeckolibItem(ItemStack stack, ModelTransformationMode displayContext, MatrixStack poseStack, VertexConsumerProvider bufferSource, int packedLight, int packedOverlay, CallbackInfo ci) {
        final BuiltinModelItemRenderer geckolibRenderer = GeoRenderProvider.of(stack).getGeoItemRenderer();

        if (geckolibRenderer != null) {
            geckolibRenderer.render(stack, displayContext, poseStack, bufferSource, packedLight, packedOverlay);

            ci.cancel();
        }
    }
}
