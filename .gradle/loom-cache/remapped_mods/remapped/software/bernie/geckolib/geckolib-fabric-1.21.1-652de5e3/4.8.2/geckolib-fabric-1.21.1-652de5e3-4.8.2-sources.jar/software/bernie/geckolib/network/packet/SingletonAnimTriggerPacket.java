package software.bernie.geckolib.network.packet;

import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.GeckoLibConstants;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.function.Consumer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

public record SingletonAnimTriggerPacket(String syncableId, long instanceId, String controllerName, String animName) implements MultiloaderPacket {
    public static final CustomPayload.Id<SingletonAnimTriggerPacket> TYPE = new Id<>(GeckoLibConstants.id("singleton_anim_trigger"));
    public static final PacketCodec<PacketByteBuf, SingletonAnimTriggerPacket> CODEC = PacketCodec.tuple(
            PacketCodecs.STRING, SingletonAnimTriggerPacket::syncableId,
            PacketCodecs.VAR_LONG, SingletonAnimTriggerPacket::instanceId,
            PacketCodecs.STRING, SingletonAnimTriggerPacket::controllerName,
            PacketCodecs.STRING, SingletonAnimTriggerPacket::animName,
            SingletonAnimTriggerPacket::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return TYPE;
    }

    @Override
    public void receiveMessage(@Nullable PlayerEntity sender, Consumer<Runnable> workQueue) {
        workQueue.accept(() -> {
            GeoAnimatable animatable = GeckoLibUtil.getSyncedAnimatable(this.syncableId);

            if (animatable != null)
                animatable.getAnimatableInstanceCache().getManagerForId(this.instanceId).tryTriggerAnimation(this.controllerName, this.animName);
        });
    }
}
