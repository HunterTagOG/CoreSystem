package dev.huntertagog.coresystem.client.region;

import dev.huntertagog.coresystem.common.region.RegionImageFacing;
import dev.huntertagog.coresystem.common.region.RegionImageMode;
import dev.huntertagog.coresystem.fabric.common.net.payload.RegionImageSetS2CPayload;
import dev.huntertagog.coresystem.fabric.common.region.RegionImageDef;
import java.util.Locale;
import net.minecraft.class_238;
import net.minecraft.class_2960;

public final class RegionImageClientMapper {

    private RegionImageClientMapper() {
    }

    public static RegionImageDef fromPayload(RegionImageSetS2CPayload p) {
        var bounds = new class_238(
                p.minX(), p.minY(), p.minZ(),
                p.maxX(), p.maxY(), p.maxZ()
        );

        return new RegionImageDef(
                p.regionId(),
                p.worldId(),
                bounds,
                RegionImageMode.valueOf(p.mode().toUpperCase()),
                RegionImageFacing.from(p.facing()),
                p.baseY(),
                p.textureId()
        );
    }

    public static class_2960 textureIdentifier(String textureId) {
        // textureId MUSS z.B. "portal_1" sein
        String safe = textureId
                .toLowerCase(Locale.ROOT)
                .replace(".png", "")
                .replaceAll("[^a-z0-9/._-]", "_");

        return class_2960.method_60655(
                "coresystem",
                "textures/region_images/" + safe + ".png"
        );
    }

}
