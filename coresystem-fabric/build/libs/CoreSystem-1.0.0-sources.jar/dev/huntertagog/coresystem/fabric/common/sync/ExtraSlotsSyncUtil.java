package dev.huntertagog.coresystem.fabric.common.sync;

import net.minecraft.class_2487;
import net.minecraft.class_3222;

/**
 * Generischer Hook für zusätzliche Slots (Trinkets / Curios / Custom).
 * Erstmal minimal, bei Bedarf kannst du hier mod-spezifische Integrationen andocken.
 */
public final class ExtraSlotsSyncUtil {

    private ExtraSlotsSyncUtil() {
    }

    public static void encodeExtraSlots(class_3222 player, class_2487 target) {
        // Beispiel: Trinkets-API (optional, pseudo-code / soft-dependency)
        // if (FabricLoader.getInstance().isModLoaded("trinkets")) {
        //     NbtCompound trinketNbt = TrinketsApi.getTrinkets(player).writeNbt(new NbtCompound());
        //     target.put("trinkets", trinketNbt);
        // }

        // Hier könntest du später weitere Mods integrieren (Curios-Ports o. Ä.)
    }

    public static void applyExtraSlots(class_3222 player, class_2487 source) {
        // if (source.contains("trinkets") && FabricLoader.getInstance().isModLoaded("trinkets")) {
        //     NbtCompound trinketNbt = source.getCompound("trinkets");
        //     TrinketsApi.getTrinkets(player).readNbt(trinketNbt);
        // }
    }
}
