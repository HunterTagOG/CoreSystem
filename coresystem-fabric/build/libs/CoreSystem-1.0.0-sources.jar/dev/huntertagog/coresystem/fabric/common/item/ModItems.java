package dev.huntertagog.coresystem.fabric.common.item;

import dev.huntertagog.coresystem.common.text.CoreMessage;
import dev.huntertagog.coresystem.fabric.CoresystemCommon;
import dev.huntertagog.coresystem.fabric.common.item.impl.ServerKeyItem;
import dev.huntertagog.coresystem.fabric.common.text.MessageItems;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ModItems {

    // ------------------------------------------------------------------------
    // Item-Registrierung
    // ------------------------------------------------------------------------

    /**
     * Animierter, interaktiver Key mit GeckoLib + ServerSwitcher-Logik
     */
    public static final class_1792 SERVER_KEY = register(
            "server_key",
            new ServerKeyItem(new class_1792.class_1793().method_7889(1))
    );

    private ModItems() {
    }

    private static class_1792 register(String name, class_1792 item) {
        return class_2378.method_10230(
                class_7923.field_41178,
                class_2960.method_60655(CoresystemCommon.MOD_ID, name),
                item
        );
    }

    public static void init() {
        // damit die Klasse geladen wird
    }

    // ------------------------------------------------------------------------
    // Message-basierte Standard-Stacks
    // ------------------------------------------------------------------------

    /**
     * Standard-Stack des Server Keys mit lokalisiertem Namen & Lore.
     */
    public static class_1799 serverKeyStack() {
        return MessageItems.stack(
                SERVER_KEY,
                CoreMessage.ITEM_SERVER_KEY_NAME,
                CoreMessage.ITEM_SERVER_KEY_LORE_1,
                CoreMessage.ITEM_SERVER_KEY_LORE_2
        );
    }

    /**
     * Generic helper
     */
    public static class_1799 stackWithMessages(class_1792 item,
                                              CoreMessage displayName,
                                              CoreMessage... lore) {
        return MessageItems.stack(item, displayName, lore);
    }
}
