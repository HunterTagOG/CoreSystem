package dev.huntertagog.coresystem.fabric.server.command.impl;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import dev.huntertagog.coresystem.common.command.BaseCommand;
import dev.huntertagog.coresystem.common.permission.PermissionKeys;
import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import dev.huntertagog.coresystem.common.text.CoreMessage;
import dev.huntertagog.coresystem.fabric.common.chat.PlayerNicknameService;
import dev.huntertagog.coresystem.fabric.common.text.Messages;
import dev.huntertagog.coresystem.fabric.server.command.CoreCommand;
import dev.huntertagog.coresystem.platform.command.CommandMeta;
import net.minecraft.class_2168;
import net.minecraft.class_3222;
import net.minecraft.class_7157;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

@CommandMeta(value = "coresystem_nick", permission = PermissionKeys.NICK_USE, enabled = true)
public final class NickCommand extends BaseCommand implements CoreCommand {

    public NickCommand() {
    }

    @Override
    public void register(CommandDispatcher<class_2168> dispatcher,
                         class_7157 registryAccess,
                         net.minecraft.class_2170.class_5364 environment) {

        dispatcher.register(
                method_9247("nick")
                        .executes(ctx -> {
                            class_3222 player = ctx.getSource().method_44023();
                            if (player == null) {
                                Messages.send(ctx.getSource(), CoreMessage.ONLY_PLAYERS);
                                return 0;
                            }

                            // Nick entfernen
                            PlayerNicknameService service = ServiceProvider.getService(PlayerNicknameService.class);
                            if (service == null) {
                                Messages.send(player, CoreMessage.SERVICE_UNAVAILABLE);
                                return 0;
                            }

                            service.clearNickname(player.method_5667());
                            Messages.send(player, CoreMessage.NICK_CLEARED);
                            return 1;
                        })
                        .then(method_9244("nickname", StringArgumentType.greedyString())
                                .executes(ctx -> {
                                    class_3222 player = ctx.getSource().method_44023();
                                    if (player == null) {
                                        Messages.send(ctx.getSource(), CoreMessage.ONLY_PLAYERS);
                                        return 0;
                                    }

                                    String nick = StringArgumentType.getString(ctx, "nickname");

                                    // hier kannst du Length/Regex prüfen
                                    if (nick.length() < 3 || nick.length() > 16) {
                                        Messages.send(player, CoreMessage.NICK_INVALID_LENGTH);
                                        return 0;
                                    }

                                    PlayerNicknameService service = ServiceProvider.getService(PlayerNicknameService.class);
                                    if (service == null) {
                                        Messages.send(player, CoreMessage.SERVICE_UNAVAILABLE);
                                        return 0;
                                    }

                                    service.setNickname(player.method_5667(), nick);
                                    Messages.send(player, CoreMessage.NICK_SET, nick);
                                    return 1;
                                })
                        )
        );
    }
}
