package dev.huntertagog.coresystem.fabric.server.protection;

import dev.huntertagog.coresystem.common.log.Logger;
import dev.huntertagog.coresystem.common.log.LoggerFactory;
import dev.huntertagog.coresystem.platform.provider.Service;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;

import java.util.Locale;
import java.util.Set;

/**
 * Globale World-Schutz-Policy pro Minecraft-Server.
 * <p>
 * Aktuell:
 * - TNT-Explosionen blockieren
 * - Feuer-Tick (Spread) deaktivieren
 * <p>
 * Konfiguration per ENV:
 * PROTECT_TNT=true|false
 * PROTECT_FIRE=true|false
 * <p>
 * Optional: PROTECT_WORLD_FILTER = "all" (default) oder
 * CSV-Liste von World-Pfaden (z.B. "minecraft:overworld,coresystem:lobby")
 */
public final class WorldProtectionService implements Service {

    private static final Logger LOG = LoggerFactory.get("WorldProtection");

    private final MinecraftServer server;
    private final boolean protectTnt;
    private final boolean protectFire;
    private final ProtectionScope scope;

    public WorldProtectionService(MinecraftServer server) {
        this.server = server;

        this.protectTnt = Boolean.parseBoolean(
                System.getenv().getOrDefault("PROTECT_TNT", "false")
        );
        this.protectFire = Boolean.parseBoolean(
                System.getenv().getOrDefault("PROTECT_FIRE", "false")
        );

        String filterRaw = System.getenv().getOrDefault("PROTECT_WORLD_FILTER", "all")
                .trim()
                .toLowerCase(Locale.ROOT);

        if ("all".equals(filterRaw) || filterRaw.isBlank()) {
            this.scope = ProtectionScope.allWorlds();
        } else {
            this.scope = ProtectionScope.fromCsv(filterRaw);
        }

        LOG.info("WorldProtectionService initialized: TNT={}, FIRE={}, scope={}",
                protectTnt, protectFire, scope);
    }

    /**
     * Wird aufgerufen, wenn eine Welt geladen wurde – setzt z. B. GameRules.
     */
    public void applyOnWorldLoad(@NotNull class_3218 world) {
        if (!scope.isProtected(world)) {
            return;
        }

        class_1928 rules = world.method_8450();

        if (protectFire) {
            rules.method_20746(class_1928.field_19387).method_20758(false, server);
            LOG.info("Applied DO_FIRE_TICK=false for world {}", world.method_27983().method_29177());
        }

        // TNT gibt es in Java-Edition NICHT als eigenen Gamerule.
        // TNT-Explosionen werden weiter unten via Mixin/TNT-Hook geblockt.
    }

    /**
     * Wird im TNT-Mixin verwendet.
     */
    public boolean isTntBlocked(@NotNull class_1937 world) {
        if (!(world instanceof class_3218 serverWorld)) {
            return false; // nur auf Server-Welten schützen
        }
        return protectTnt && scope.isProtected(serverWorld);
    }

    /**
     * Optional, falls du später noch andere Mechaniken an World-Schutz knüpfen willst.
     */
    public boolean isFireTickBlocked(@NotNull class_1937 world) {
        if (!(world instanceof class_3218 serverWorld)) {
            return false; // nur auf Server-Welten schützen
        }
        return protectFire && scope.isProtected(serverWorld);
    }

    // ------------------------------------------------------------
    // Scope-Definition (welche Welten sind „geschützt“)
    // ------------------------------------------------------------

    private record ProtectionScope(boolean all, Set<String> protectedWorldIds) {

        static ProtectionScope allWorlds() {
            return new ProtectionScope(true, Set.of());
        }

        static ProtectionScope fromCsv(String csv) {
            String[] parts = csv.split(",");
            Set<String> ids = java.util.Arrays.stream(parts)
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .map(s -> s.toLowerCase(Locale.ROOT))
                    .collect(java.util.stream.Collectors.toSet());
            return new ProtectionScope(false, ids);
        }

        boolean isProtected(class_3218 world) {
            if (all) return true;
            String id = world.method_27983().method_29177().toString().toLowerCase(Locale.ROOT);
            return protectedWorldIds.contains(id);
        }

        @Override
        public @NotNull String toString() {
            if (all) return "all-worlds";
            return "worlds=" + protectedWorldIds;
        }
    }
}
