package dev.huntertagog.coresystem.fabric.server.player.playerdata;

import dev.huntertagog.coresystem.fabric.common.player.playerdata.PlayerInventoryCodec;
import dev.huntertagog.coresystem.platform.player.playerdata.PlayerDataCodec;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.io.IOException;
import java.util.Objects;
import java.util.UUID;

public final class FabricPlayerDataCodec implements PlayerDataCodec {

    private final MinecraftServer server;

    public FabricPlayerDataCodec(MinecraftServer server) {
        this.server = Objects.requireNonNull(server, "server");
    }

    @Override
    public String encodeInventoryToBase64(UUID playerId) throws IOException {
        class_3222 player = server.method_3760().method_14602(playerId);
        if (player == null) {
            throw new IllegalStateException("Player not online: " + playerId);
        }
        return PlayerInventoryCodec.encodeInventoryToBase64(server, player);
    }

    @Override
    public void applyInventoryFromBase64(UUID playerId, String payloadBase64) throws IOException {
        class_3222 player = server.method_3760().method_14602(playerId);
        if (player == null) {
            throw new IllegalStateException("Player not online: " + playerId);
        }
        PlayerInventoryCodec.applyInventoryFromBase64(server, player, payloadBase64);
    }
}
