package dev.huntertagog.coresystem.fabric.common.sync;

import net.minecraft.class_1730;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_7225;

public final class EnderChestCodecUtil {

    private EnderChestCodecUtil() {
    }

    public static class_2499 serializeEnderChest(class_1730 inv,
                                              class_7225.class_7874 registries) {
        class_2499 list = new class_2499();

        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 stack = inv.method_5438(i);
            if (stack.method_7960()) {
                continue;
            }

            // encode(...) returns NbtElement in your mappings → cast to NbtCompound
            class_2487 tag = (class_2487) stack.method_57358(registries);
            tag.method_10567("Slot", (byte) i);

            list.add(tag);
        }

        return list;
    }

    public static void deserializeEnderChest(class_1730 inv,
                                             class_2499 list,
                                             class_7225.class_7874 registries) {
        inv.method_5448();

        for (int i = 0; i < list.size(); i++) {
            // In deiner Mapping-Version: NbtList#get(int) -> NbtElement
            var element = list.method_10534(i);
            if (!(element instanceof class_2487 tag)) {
                continue; // defensive, falls jemand Mist in die NBT schreibt
            }

            int slot = tag.method_10571("Slot") & 0xFF;
            if (slot >= inv.method_5439()) {
                continue;
            }

            // fromNbt(...) -> Optional<ItemStack> bei dir
            class_1799 stack = class_1799.method_57360(registries, tag).orElse(class_1799.field_8037);
            inv.method_5447(slot, stack);
        }
    }
}
