package dev.huntertagog.coresystem.fabric.common.friends.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2540;

public record FriendGuiSnapshot(
        List<FriendEntry> friends,
        List<RequestEntry> incoming,
        List<RequestEntry> outgoing,
        FriendSettings settings
) {
    public static FriendGuiSnapshot read(class_2540 buf) {
        int f = buf.method_10816();
        List<FriendEntry> friends = new ArrayList<>(f);
        for (int i = 0; i < f; i++) friends.add(FriendEntry.read(buf));

        int in = buf.method_10816();
        List<RequestEntry> incoming = new ArrayList<>(in);
        for (int i = 0; i < in; i++) incoming.add(RequestEntry.read(buf));

        int out = buf.method_10816();
        List<RequestEntry> outgoing = new ArrayList<>(out);
        for (int i = 0; i < out; i++) outgoing.add(RequestEntry.read(buf));

        FriendSettings settings = FriendSettings.read(buf);
        return new FriendGuiSnapshot(friends, incoming, outgoing, settings);
    }

    public void write(class_2540 buf) {
        buf.method_10804(friends.size());
        for (FriendEntry e : friends) e.write(buf);

        buf.method_10804(incoming.size());
        for (RequestEntry e : incoming) e.write(buf);

        buf.method_10804(outgoing.size());
        for (RequestEntry e : outgoing) e.write(buf);

        settings.write(buf);
    }

    public record FriendEntry(
            UUID uuid,
            String name,
            boolean online,
            long lastSeenEpochMillis // 0 = unknown
    ) {
        public static FriendEntry read(class_2540 buf) {
            return new FriendEntry(
                    buf.method_10790(),
                    buf.method_10800(32),
                    buf.readBoolean(),
                    buf.readLong()
            );
        }

        public void write(class_2540 buf) {
            buf.method_10797(uuid);
            buf.method_10788(name, 32);
            buf.method_52964(online);
            buf.method_52974(lastSeenEpochMillis);
        }
    }

    public record RequestEntry(
            UUID uuid,
            String name
    ) {
        public static RequestEntry read(class_2540 buf) {
            return new RequestEntry(buf.method_10790(), buf.method_10800(32));
        }

        public void write(class_2540 buf) {
            buf.method_10797(uuid);
            buf.method_10788(name, 32);
        }
    }

    public record FriendSettings(
            boolean allowRequests,
            boolean allowFollow,
            boolean showLastSeen
    ) {
        public static FriendSettings read(class_2540 buf) {
            return new FriendSettings(
                    buf.readBoolean(),
                    buf.readBoolean(),
                    buf.readBoolean()
            );
        }

        public void write(class_2540 buf) {
            buf.method_52964(allowRequests);
            buf.method_52964(allowFollow);
            buf.method_52964(showLastSeen);
        }
    }
}
