package dev.huntertagog.coresystem.fabric.common.economy;

import dev.huntertagog.coresystem.platform.economy.CurrencyId;
import dev.huntertagog.coresystem.platform.economy.EconomyTransactionResult;
import dev.huntertagog.coresystem.platform.economy.Money;
import dev.huntertagog.coresystem.platform.provider.Service;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;
import net.minecraft.class_3222;

/**
 * Spezialisierte API für Player-Wallet-Operations.
 * Kapselt EconomyService + Player-spezifische Komfortfunktionen.
 */
public interface PlayerWalletService extends Service {

    CurrencyId DEFAULT_CURRENCY = CurrencyId.COINS;

    @NotNull
    Money getBalance(@NotNull UUID playerId);

    default @NotNull Money getBalance(@NotNull class_3222 player) {
        return getBalance(player.method_5667());
    }

    boolean hasAtLeast(@NotNull UUID playerId, long amount);

    default boolean hasAtLeast(@NotNull class_3222 player, long amount) {
        return hasAtLeast(player.method_5667(), amount);
    }

    @NotNull
    Money deposit(@NotNull UUID playerId, long amount, String reason);

    default @NotNull Money deposit(@NotNull class_3222 player, long amount, String reason) {
        return deposit(player.method_5667(), amount, reason);
    }

    @NotNull
    EconomyTransactionResult withdraw(@NotNull UUID playerId, long amount, String reason);

    default @NotNull EconomyTransactionResult withdraw(@NotNull class_3222 player, long amount, String reason) {
        return withdraw(player.method_5667(), amount, reason);
    }
}
