package dev.huntertagog.coresystem.fabric.common.chat;

import dev.huntertagog.coresystem.common.log.Logger;
import dev.huntertagog.coresystem.common.log.LoggerFactory;
import dev.huntertagog.coresystem.common.permission.CorePermission;
import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import dev.huntertagog.coresystem.fabric.common.permission.PermissionService;
import dev.huntertagog.coresystem.platform.chat.ChatFilterService;
import dev.huntertagog.coresystem.platform.clans.Clan;
import dev.huntertagog.coresystem.platform.clans.ClanService;
import dev.huntertagog.coresystem.platform.clans.chat.ClanChatService;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.minecraft.class_124;
import net.minecraft.class_2556;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.class_7471;
import net.minecraft.server.MinecraftServer;
import java.util.Optional;
import java.util.UUID;

public final class CoreChatListener {

    private static final Logger LOG = LoggerFactory.get("CoreChat");

    private static ChatDisplayNameFormatter formatter;
    private static ChatFilterService chatFilter;
    private static PermissionService permissionService;

    private static ClanService clanService;
    private static ClanChatService clanChatService;

    private CoreChatListener() {
    }

    public static void register(MinecraftServer server) {
        formatter = new ChatDisplayNameFormatter();
        chatFilter = ServiceProvider.getService(ChatFilterService.class);
        permissionService = ServiceProvider.getService(PermissionService.class);

        clanService = ServiceProvider.getService(ClanService.class);
        clanChatService = ServiceProvider.getService(ClanChatService.class);

        // Wir übernehmen das gesamte Chat-Handover
        ServerMessageEvents.ALLOW_CHAT_MESSAGE.register(
                (class_7471 signedMessage,
                 class_3222 sender,
                 class_2556.class_7602 params) -> {

                    // 1) DisplayName (Prefix + Nick des Senders)
                    class_2561 displayName = formatter.buildDisplayName(sender);

                    // 2) Roh-Content aus SignedMessage
                    String rawContent = signedMessage.method_46291().getString();

                    // 3) Gefilterter Content (für "normale" Spieler)
                    String filteredContent = (chatFilter != null)
                            ? chatFilter.filter(rawContent)
                            : rawContent;

                    // 4) ClanChat-Zustand / Clan des Senders
                    boolean senderClanChat = clanChatService != null && clanChatService.isClanChatEnabled(sender.method_5667());
                    Optional<Clan> finalSenderClanOpt = (clanService != null)
                            ? clanService.findByMember(sender.method_5667())
                            : Optional.empty();

                    // Fallback: ClanChat an, aber kein Clan -> automatisch deaktivieren
                    if (senderClanChat && finalSenderClanOpt.isEmpty()) {
                        if (clanChatService != null) {
                            clanChatService.setClanChatEnabled(sender.method_5667(), false);
                        }
                        senderClanChat = false;
                    }

                    // 5) Basiszeile für Logging / Server-Konsole (immer ungefiltert)
                    class_5250 baseLogLine = buildChatLine(displayName, rawContent);

                    boolean finalSenderClanChat = senderClanChat;

                    sender.field_13995.method_3760().method_43512(
                            baseLogLine, // fürs Server-Log
                            target -> {
                                // Admin/Staff: Chat Spy darf immer sehen
                                boolean spy = hasSpyPermission(target);

                                // Target ist im ClanChat-only Modus?
                                boolean targetClanChat = clanChatService != null && clanChatService.isClanChatEnabled(target.method_5667());

                                // Bypass: sieht ungefiltert
                                boolean bypassFilter = hasBypassPermission(target);
                                String contentForTarget = bypassFilter ? rawContent : filteredContent;

                                // CASE A) Sender schreibt im Clan-Chat -> nur an Clan (oder Spy)
                                if (finalSenderClanChat) {
                                    if (spy) {
                                        return buildClanChatLine(displayName, contentForTarget, true);
                                    }

                                    if (isSameClan(finalSenderClanOpt.get(), target)) {
                                        return buildClanChatLine(displayName, contentForTarget, false);
                                    }

                                    return null; // nicht zustellen
                                }

                                // CASE B) Sender schreibt im Global-Chat
                                // Empfänger im ClanChat-only Modus bekommt KEIN Global (außer Spy)
                                if (targetClanChat && !spy) {
                                    return null;
                                }

                                // Global normal zustellen
                                return buildChatLine(displayName, contentForTarget);
                            },
                            false
                    );

                    // zusätzlich ins eigene Log schreiben (ungefiltert)
                    LOG.info("[Chat] {}: {}", displayName.getString(), rawContent);

                    // Vanilla-Broadcast (signed) unterdrücken
                    return false;
                });

        LOG.info("CoreChatListener registered (prefix, nick, filter, clan-chat routing, admin bypass/spy).");
    }

    // -------------------------------
    // Chat Line Builder
    // -------------------------------

    private static class_5250 buildChatLine(class_2561 displayName, String content) {
        return class_2561.method_43473()
                .method_10852(displayName)
                .method_10852(class_2561.method_43470(" ").method_27692(class_124.field_1080))
                .method_10852(class_2561.method_43470("» ").method_27692(class_124.field_1063))
                .method_10852(class_2561.method_43470(content).method_27692(class_124.field_1068));
    }

    private static class_5250 buildClanChatLine(class_2561 displayName, String content, boolean spyView) {
        // Format: [Clan] <name> » msg  (Spy sieht zusätzlich Markierung)
        class_5250 prefix = class_2561.method_43470("[Clan] ").method_27692(class_124.field_1062);
        if (spyView) {
            prefix = prefix.method_10852(class_2561.method_43470("[Spy] ").method_27692(class_124.field_1063));
        }

        return class_2561.method_43473()
                .method_10852(prefix)
                .method_10852(displayName)
                .method_10852(class_2561.method_43470(" ").method_27692(class_124.field_1080))
                .method_10852(class_2561.method_43470("» ").method_27692(class_124.field_1063))
                .method_10852(class_2561.method_43470(content).method_27692(class_124.field_1068));
    }

    // -------------------------------
    // Permissions
    // -------------------------------

    private static boolean hasBypassPermission(class_3222 target) {
        if (permissionService == null) return false;
        try {
            return permissionService.has(target.method_5671(), CorePermission.STAFF_CHAT_FILTER_BYPASS);
        } catch (Exception e) {
            LOG.warn("Failed to evaluate chat filter bypass permission for {}", target.method_7334().getName(), e);
            return false;
        }
    }

    private static boolean hasSpyPermission(class_3222 target) {
        if (permissionService == null) return false;
        try {
            // -> Diese Permission musst du anlegen (CorePermission.STAFF_CHAT_SPY)
            return permissionService.has(target.method_5671(), CorePermission.STAFF_CHAT_SPY);
        } catch (Exception e) {
            LOG.warn("Failed to evaluate chat spy permission for {}", target.method_7334().getName(), e);
            return false;
        }
    }

    // -------------------------------
    // Clan helper
    // -------------------------------

    private static boolean isSameClan(Clan senderClan, class_3222 target) {
        if (clanService == null) return false;

        UUID tid = target.method_5667();
        return clanService.findByMember(tid)
                .map(c -> c.id().equals(senderClan.id()))
                .orElse(false);
    }
}
