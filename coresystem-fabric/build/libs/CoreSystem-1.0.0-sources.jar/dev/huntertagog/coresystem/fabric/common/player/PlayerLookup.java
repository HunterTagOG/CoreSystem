package dev.huntertagog.coresystem.fabric.common.player;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.Optional;
import java.util.UUID;

public final class PlayerLookup {

    private PlayerLookup() {
    }

    public static Optional<UUID> resolveUuid(MinecraftServer server, String name) {
        if (name == null || name.isBlank()) return Optional.empty();

        // 1) online
        class_3222 online = server.method_3760().method_14566(name);
        if (online != null) return Optional.of(online.method_5667());

        // 2) cached profiles
        if (server.method_3793() != null) {
            return server.method_3793().method_14515(name).map(GameProfile::getId);
        }

        return Optional.empty();
    }

    public static Optional<String> resolveName(MinecraftServer server, UUID uuid) {
        if (uuid == null) return Optional.empty();

        class_3222 online = server.method_3760().method_14602(uuid);
        if (online != null) return Optional.of(online.method_7334().getName());

        if (server.method_3793() != null) {
            return server.method_3793().method_14512(uuid).map(GameProfile::getName);
        }

        return Optional.empty();
    }
}
