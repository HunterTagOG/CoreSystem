package dev.huntertagog.coresystem.fabric.common.error;

import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.common.error.CoreException;
import dev.huntertagog.coresystem.common.log.Logger;
import dev.huntertagog.coresystem.common.log.LoggerFactory;
import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import dev.huntertagog.coresystem.platform.event.DomainEvent;
import dev.huntertagog.coresystem.platform.event.DomainEventBus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public final class CoreErrors {

    private static final Logger LOG = LoggerFactory.get("CoreError");
    private static final DomainEventBus EVENT_BUS =
            ServiceProvider.getService(DomainEventBus.class);

    private CoreErrors() {
    }

    public static CoreException fail(CoreErrorCode code,
                                     CoreErrorSeverity severity,
                                     String msg) {
        CoreError error = CoreError.of(code, severity, msg);
        log(error, null);
        publish(error);
        return new CoreException(error);
    }

    public static CoreException fail(CoreErrorCode code,
                                     CoreErrorSeverity severity,
                                     String msg,
                                     Throwable cause) {
        CoreError error = CoreError.of(code, severity, msg).withCause(cause);
        log(error, null);
        publish(error);
        return new CoreException(error);
    }

    public static void log(CoreError error, @Nullable Logger customLogger) {
        Logger logger = customLogger != null ? customLogger : LOG;

        switch (error.severity()) {
            case INFO -> logger.info(error.toLogString());
            case WARN -> logger.warn(error.toLogString());
            case ERROR, CRITICAL -> {
                if (error.cause() != null) {
                    logger.error(error.toLogString(), error.cause());
                } else {
                    logger.error(error.toLogString());
                }
            }
        }
    }

    public static void publish(CoreError error) {
        if (EVENT_BUS == null) return;

        EVENT_BUS.publishAsync(new CoreErrorEvent(error));
    }

    /**
     * Optional: generische Rückmeldung an Commands/Player ohne i18n-Bindung.
     * Für produktive Pfade lieber Messages + CoreMessage verwenden.
     */
    public static void sendToSource(class_2168 source,
                                    CoreError error,
                                    boolean includeCode) {
        String base = "Ein interner Fehler ist aufgetreten.";
        if (includeCode) {
            base += " (" + error.code().name() + ")";
        }
        source.method_9213(class_2561.method_43470(base));
    }

    public static void sendToPlayer(class_3222 player,
                                    CoreError error,
                                    boolean includeCode) {
        String base = "Es ist ein Fehler aufgetreten.";
        if (includeCode) {
            base += " (" + error.code().name() + ")";
        }
        player.method_7353(class_2561.method_43470(base), false);
    }

    // DomainEvent-Wrapper
    public record CoreErrorEvent(CoreError error) implements DomainEvent {

        @Override
        public @NotNull String toString() {
            return "CoreErrorEvent{" + error.toLogString() + '}';
        }

        @Override
        public long occurredAt() {
            return System.currentTimeMillis();
        }

        @Override
        public UUID correlationId() {
            return UUID.randomUUID();
        }
    }
}
