package dev.huntertagog.coresystem.fabric.server.region;

import dev.huntertagog.coresystem.common.region.RegionDefinitionDto;
import org.jetbrains.annotations.NotNull;

import java.util.*;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;

final class RegionNbtCodec {

    private static final String K_ID = "id";
    private static final String K_NAME = "name";
    private static final String K_OWNER = "ownerId";
    private static final String K_WORLD = "world";

    private static final String K_MIN_X = "minX";
    private static final String K_MIN_Y = "minY";
    private static final String K_MIN_Z = "minZ";
    private static final String K_MAX_X = "maxX";
    private static final String K_MAX_Y = "maxY";
    private static final String K_MAX_Z = "maxZ";

    private static final String K_FLAGS = "flags";
    private static final String K_ON_ENTER = "onEnter";
    private static final String K_ON_LEAVE = "onLeave";

    private RegionNbtCodec() {
    }

    static class_2487 writeDto(RegionDefinitionDto dto) {
        if (dto == null) return null;

        class_2487 n = getNbtCompound(dto);

        // flags (Set<String>)
        class_2499 flags = new class_2499();
        if (dto.flags() != null) {
            for (String f : dto.flags()) {
                if (f != null && !f.isBlank()) flags.add(class_2519.method_23256(f));
            }
        }
        n.method_10566(K_FLAGS, flags);

        // onEnterCommands
        class_2499 enter = new class_2499();
        if (dto.onEnterCommands() != null) {
            for (String cmd : dto.onEnterCommands()) {
                if (cmd != null && !cmd.isBlank()) enter.add(class_2519.method_23256(cmd));
            }
        }
        n.method_10566(K_ON_ENTER, enter);

        // onLeaveCommands
        class_2499 leave = new class_2499();
        if (dto.onLeaveCommands() != null) {
            for (String cmd : dto.onLeaveCommands()) {
                if (cmd != null && !cmd.isBlank()) leave.add(class_2519.method_23256(cmd));
            }
        }
        n.method_10566(K_ON_LEAVE, leave);

        return n;
    }

    private static @NotNull class_2487 getNbtCompound(RegionDefinitionDto dto) {
        class_2487 n = new class_2487();

        n.method_10582(K_ID, safe(dto.id()));
        n.method_10582(K_NAME, safe(dto.name()));

        if (dto.ownerId() != null) {
            n.method_10582(K_OWNER, dto.ownerId().toString());
        }

        n.method_10582(K_WORLD, safe(dto.world()));

        n.method_10569(K_MIN_X, dto.minX());
        n.method_10569(K_MIN_Y, dto.minY());
        n.method_10569(K_MIN_Z, dto.minZ());
        n.method_10569(K_MAX_X, dto.maxX());
        n.method_10569(K_MAX_Y, dto.maxY());
        n.method_10569(K_MAX_Z, dto.maxZ());
        return n;
    }

    static RegionDefinitionDto readDto(class_2487 n) {
        if (n == null) return null;

        String id = n.method_10558(K_ID);
        if (id == null || id.isBlank()) return null;

        String name = n.method_10558(K_NAME);
        String world = n.method_10558(K_WORLD);

        UUID ownerId = null;
        if (n.method_10573(K_OWNER, class_2520.field_33258)) {
            String ownerRaw = n.method_10558(K_OWNER);
            if (ownerRaw != null && !ownerRaw.isBlank()) {
                try {
                    ownerId = UUID.fromString(ownerRaw);
                } catch (Exception ignored) {
                }
            }
        }

        int minX = n.method_10550(K_MIN_X);
        int minY = n.method_10550(K_MIN_Y);
        int minZ = n.method_10550(K_MIN_Z);
        int maxX = n.method_10550(K_MAX_X);
        int maxY = n.method_10550(K_MAX_Y);
        int maxZ = n.method_10550(K_MAX_Z);

        Set<String> flags = new HashSet<>();
        if (n.method_10573(K_FLAGS, class_2520.field_33259)) {
            // WICHTIG: type ist Element-Type-ID (Strings => NbtElement.STRING_TYPE)
            class_2499 list = n.method_10554(K_FLAGS, class_2520.field_33258);
            for (int i = 0; i < list.size(); i++) {
                String f = list.method_10608(i);
                if (f != null && !f.isBlank()) flags.add(f);
            }
        }

        List<String> onEnter = new ArrayList<>();
        if (n.method_10573(K_ON_ENTER, class_2520.field_33259)) {
            class_2499 list = n.method_10554(K_ON_ENTER, class_2520.field_33258);
            for (int i = 0; i < list.size(); i++) {
                String s = list.method_10608(i);
                if (s != null && !s.isBlank()) onEnter.add(s);
            }
        }

        List<String> onLeave = new ArrayList<>();
        if (n.method_10573(K_ON_LEAVE, class_2520.field_33259)) {
            class_2499 list = n.method_10554(K_ON_LEAVE, class_2520.field_33258);
            for (int i = 0; i < list.size(); i++) {
                String s = list.method_10608(i);
                if (s != null && !s.isBlank()) onLeave.add(s);
            }
        }

        return new RegionDefinitionDto(
                id,
                name,
                ownerId,
                world,
                minX, minY, minZ,
                maxX, maxY, maxZ,
                flags,
                onEnter,
                onLeave
        );
    }

    private static String safe(String s) {
        return s == null ? "" : s;
    }
}
