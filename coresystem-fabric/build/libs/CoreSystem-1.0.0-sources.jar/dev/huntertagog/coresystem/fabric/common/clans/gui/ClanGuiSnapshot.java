package dev.huntertagog.coresystem.fabric.common.clans.gui;

import java.util.*;
import net.minecraft.class_2540;

public record ClanGuiSnapshot(
        boolean inClan,
        UUID clanId,
        String tag,
        String name,

        ClanSettings settings,
        List<MemberEntry> members,
        List<RoleEntry> roles,

        boolean canManageMembers,
        boolean canManageRoles,
        boolean canManageSettings
) {

    public record ClanSettings(
            boolean openInvites,
            boolean friendlyFire,
            boolean clanChatDefault
    ) {
    }

    public record MemberEntry(
            UUID uuid,
            String name,
            boolean online,
            long lastSeenEpochMillis,
            String roleId // z.B. "OWNER","ADMIN","MEMBER" oder custom
    ) {
    }

    public record RoleEntry(
            String roleId,
            String displayName,
            Set<String> permissions // Strings, damit du serverseitig frei erweitern kannst
    ) {
    }

    // ------------------------------------------------------------
    // Codec (einfach + robust)
    // ------------------------------------------------------------

    public void write(class_2540 buf) {
        buf.method_52964(inClan);
        buf.method_10797(clanId == null ? new UUID(0, 0) : clanId);
        buf.method_10814(tag == null ? "" : tag);
        buf.method_10814(name == null ? "" : name);

        buf.method_52964(settings != null && settings.openInvites());
        buf.method_52964(settings != null && settings.friendlyFire());
        buf.method_52964(settings != null && settings.clanChatDefault());

        buf.method_10804(members == null ? 0 : members.size());
        if (members != null) {
            for (var m : members) {
                buf.method_10797(m.uuid());
                buf.method_10814(m.name());
                buf.method_52964(m.online());
                buf.method_52974(m.lastSeenEpochMillis());
                buf.method_10814(m.roleId() == null ? "" : m.roleId());
            }
        }

        buf.method_10804(roles == null ? 0 : roles.size());
        if (roles != null) {
            for (var r : roles) {
                buf.method_10814(r.roleId());
                buf.method_10814(r.displayName());
                buf.method_10804(r.permissions().size());
                for (String p : r.permissions()) buf.method_10814(p);
            }
        }

        buf.method_52964(canManageMembers);
        buf.method_52964(canManageRoles);
        buf.method_52964(canManageSettings);
    }

    public static ClanGuiSnapshot read(class_2540 buf) {
        boolean inClan = buf.readBoolean();
        UUID clanId = buf.method_10790();
        String tag = buf.method_19772();
        String name = buf.method_19772();

        ClanSettings settings = new ClanSettings(
                buf.readBoolean(),
                buf.readBoolean(),
                buf.readBoolean()
        );

        int mSize = buf.method_10816();
        List<MemberEntry> members = new ArrayList<>(mSize);
        for (int i = 0; i < mSize; i++) {
            members.add(new MemberEntry(
                    buf.method_10790(),
                    buf.method_19772(),
                    buf.readBoolean(),
                    buf.readLong(),
                    buf.method_19772()
            ));
        }

        int rSize = buf.method_10816();
        List<RoleEntry> roles = new ArrayList<>(rSize);
        for (int i = 0; i < rSize; i++) {
            String roleId = buf.method_19772();
            String displayName = buf.method_19772();

            int pSize = buf.method_10816();
            Set<String> perms = new HashSet<>();
            for (int p = 0; p < pSize; p++) perms.add(buf.method_19772());

            roles.add(new RoleEntry(roleId, displayName, perms));
        }

        boolean canManageMembers = buf.readBoolean();
        boolean canManageRoles = buf.readBoolean();
        boolean canManageSettings = buf.readBoolean();

        // wenn nicht inClan -> clanId kann dummy sein
        if (!inClan) clanId = null;

        return new ClanGuiSnapshot(
                inClan, clanId, tag, name,
                settings, members, roles,
                canManageMembers, canManageRoles, canManageSettings
        );
    }
}
