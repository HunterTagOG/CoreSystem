package dev.huntertagog.coresystem.fabric.common.friends.gui;

import dev.huntertagog.coresystem.fabric.CoresystemCommon;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public final class FriendGuiPackets {

    public static final class_2960 ID_ACCEPT = class_2960.method_60655(CoresystemCommon.MOD_ID, "friends_gui/accept");
    public static final class_2960 ID_DENY = class_2960.method_60655(CoresystemCommon.MOD_ID, "friends_gui/deny");
    public static final class_2960 ID_REMOVE = class_2960.method_60655(CoresystemCommon.MOD_ID, "friends_gui/remove");
    public static final class_2960 ID_CANCEL = class_2960.method_60655(CoresystemCommon.MOD_ID, "friends_gui/cancel");
    public static final class_2960 ID_SETTINGS = class_2960.method_60655(CoresystemCommon.MOD_ID, "friends_gui/settings");
    public static final class_2960 ID_S2C_SNAPSHOT = class_2960.method_60655(CoresystemCommon.MOD_ID, "friends_gui/snapshot");
    public static final class_2960 ID_C2S_OPEN = class_2960.method_60655(CoresystemCommon.MOD_ID, "friends_gui/open");

    private FriendGuiPackets() {
    }

    public record C2SAccept(UUID from) implements class_8710 {
        public static final class_9154<C2SAccept> ID = new class_9154<>(ID_ACCEPT);
        public static final class_9139<class_9129, C2SAccept> CODEC =
                class_9139.method_56438(
                        (value, buf) -> buf.method_10797(value.from),
                        buf -> new C2SAccept(buf.method_10790())
                );

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record C2SDeny(UUID from) implements class_8710 {
        public static final class_9154<C2SDeny> ID = new class_9154<>(ID_DENY);
        public static final class_9139<class_9129, C2SDeny> CODEC =
                class_9139.method_56438(
                        (value, buf) -> buf.method_10797(value.from),
                        buf -> new C2SDeny(buf.method_10790())
                );

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record C2SRemove(UUID other) implements class_8710 {
        public static final class_9154<C2SRemove> ID = new class_9154<>(ID_REMOVE);
        public static final class_9139<class_9129, C2SRemove> CODEC =
                class_9139.method_56438(
                        (value, buf) -> buf.method_10797(value.other),
                        buf -> new C2SRemove(buf.method_10790())
                );

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record C2SCancel(UUID target) implements class_8710 {
        public static final class_9154<C2SCancel> ID = new class_9154<>(ID_CANCEL);
        public static final class_9139<class_9129, C2SCancel> CODEC =
                class_9139.method_56438(
                        (value, buf) -> buf.method_10797(value.target),
                        buf -> new C2SCancel(buf.method_10790())
                );

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record C2SSetSettings(boolean allowRequests, boolean allowFollow,
                                 boolean showLastSeen) implements class_8710 {
        public static final class_9154<C2SSetSettings> ID = new class_9154<>(ID_SETTINGS);
        public static final class_9139<class_9129, C2SSetSettings> CODEC =
                class_9139.method_56438(
                        (value, buf) -> {
                            buf.method_52964(value.allowRequests);
                            buf.method_52964(value.allowFollow);
                            buf.method_52964(value.showLastSeen);
                        },
                        buf -> new C2SSetSettings(buf.readBoolean(), buf.readBoolean(), buf.readBoolean())
                );

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record S2CSnapshot(FriendGuiSnapshot snapshot) implements class_8710 {
        public static final class_9154<S2CSnapshot> ID = new class_9154<>(ID_S2C_SNAPSHOT);

        public static final class_9139<class_9129, S2CSnapshot> CODEC =
                class_9139.method_56438(
                        (payload, buf) -> payload.snapshot.write(buf),
                        buf -> new S2CSnapshot(FriendGuiSnapshot.read(buf))
                );

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record C2SOpen() implements class_8710 {
        public static final class_9154<C2SOpen> ID = new class_9154<>(ID_C2S_OPEN);

        public static final class_9139<class_9129, C2SOpen> CODEC =
                class_9139.method_56438(
                        (value, buf) -> {
                        }, // leer
                        buf -> new C2SOpen()
                );

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }
}
