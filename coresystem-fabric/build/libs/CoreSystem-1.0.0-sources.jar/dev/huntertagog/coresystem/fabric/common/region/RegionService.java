package dev.huntertagog.coresystem.fabric.common.region;

import dev.huntertagog.coresystem.common.region.RegionFlag;
import dev.huntertagog.coresystem.fabric.server.region.RegionDefinition;
import dev.huntertagog.coresystem.platform.provider.Service;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public interface RegionService extends Service {

    void registerRegion(@NotNull RegionDefinition region);

    void removeRegion(@NotNull String id);

    Optional<RegionDefinition> findById(@NotNull String id);

    /**
     * Alle Regionen an einer Position (für Stacking / Priorisierung).
     */
    @NotNull
    List<RegionDefinition> findRegionsAt(@NotNull class_3218 world, @NotNull class_2338 pos);

    /**
     * Convenience: gibt true zurück, wenn mindestens eine Region am BlockPos den Flag gesetzt hat.
     */
    boolean hasFlagAt(@NotNull class_3218 world,
                      @NotNull class_2338 pos,
                      @NotNull RegionFlag flag);

    /**
     * Alle registrierten Regionen.
     */
    List<RegionDefinition> getAllRegions();

}
