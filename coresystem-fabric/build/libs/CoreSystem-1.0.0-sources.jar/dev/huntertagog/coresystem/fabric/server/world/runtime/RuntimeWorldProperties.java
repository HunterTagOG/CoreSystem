package dev.huntertagog.coresystem.fabric.server.world.runtime;

import net.minecraft.class_1267;
import net.minecraft.class_1928;
import net.minecraft.class_27;
import net.minecraft.class_5219;

public final class RuntimeWorldProperties extends class_27 {
    private final RuntimeWorldConfig config;
    private final class_1928 rules;

    public RuntimeWorldProperties(class_5219 saveProperties, RuntimeWorldConfig config) {
        super(saveProperties, saveProperties.method_27859());
        this.config = config;

        this.rules = new class_1928();
        config.getGameRules().applyTo(this.rules, null);
    }

    @Override
    public class_1928 method_146() {
        return this.rules;
    }

    @Override
    public void method_29035(long timeOfDay) {
        this.config.setTimeOfDay(timeOfDay);
    }

    @Override
    public long method_217() {
        return this.config.getTimeOfDay();
    }

    @Override
    public void method_167(int time) {
        this.config.setSunny(time);
    }

    @Override
    public int method_155() {
        return this.config.getSunnyTime();
    }

    @Override
    public void method_157(boolean raining) {
        this.config.setRaining(raining);
    }

    @Override
    public boolean method_156() {
        return this.config.isRaining();
    }

    @Override
    public void method_164(int time) {
        this.config.setRaining(time);
    }

    @Override
    public int method_190() {
        return this.config.getRainTime();
    }

    @Override
    public void method_147(boolean thundering) {
        this.config.setThundering(thundering);
    }

    @Override
    public boolean method_203() {
        return this.config.isThundering();
    }

    @Override
    public void method_173(int time) {
        this.config.setThundering(time);
    }

    @Override
    public int method_145() {
        return this.config.getThunderTime();
    }

    @Override
    public class_1267 method_207() {
        return this.config.getDifficulty();
    }
}
