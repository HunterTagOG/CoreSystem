package dev.huntertagog.coresystem.fabric.common.player;

import dev.huntertagog.coresystem.platform.player.PlayerProfileService;
import net.minecraft.class_3222;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class FabricPlayerProfileAdapter {

    private final PlayerProfileService delegate;

    public FabricPlayerProfileAdapter(PlayerProfileService delegate) {
        this.delegate = delegate;
    }

    public void onJoin(
            @NotNull class_3222 player,
            @NotNull String serverName,
            @Nullable String nodeId
    ) {
        delegate.updateOnJoin(
                player.method_5667(),
                player.method_7334().getName(),
                serverName,
                nodeId
        );
    }

    public void onQuit(
            @NotNull class_3222 player,
            @NotNull String serverName,
            @Nullable String nodeId
    ) {
        delegate.updateOnQuit(
                player.method_5667(),
                serverName,
                nodeId
        );
    }

    public void ensureProfile(@NotNull class_3222 player) {
        delegate.getOrCreate(
                player.method_5667(),
                player.method_7334().getName()
        );
    }
}
