package dev.huntertagog.coresystem.fabric.common.chat;

import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5250;

public final class ChatDisplayNameFormatter {

    private final PlayerNicknameService nicknameService;
    private final NamePrefixResolver prefixResolver;

    public ChatDisplayNameFormatter() {
        this.nicknameService = ServiceProvider.getService(PlayerNicknameService.class);
        this.prefixResolver = ServiceProvider.getService(NamePrefixResolver.class);
    }

    public class_2561 buildDisplayName(class_3222 player) {
        class_5250 result = class_2561.method_43473();

        if (prefixResolver != null) {
            class_2561 prefix = prefixResolver.resolvePrefix(player);
            if (prefix != null) {
                result.method_10852(prefix);
            }
        }

        String baseName;
        if (nicknameService != null) {
            baseName = nicknameService.getEffectiveName(player);
        } else {
            baseName = player.method_7334().getName();
        }

        // Farben-Strategie nach Rolle / Permission anpassbar
        class_124 nameColor = class_124.field_1068;
        // z.B. Staff farbig:
        // if (perms.has(...)) nameColor = Formatting.AQUA; etc.

        result.method_10852(class_2561.method_43470(baseName).method_27692(nameColor));
        return result;
    }
}
