package dev.huntertagog.coresystem.fabric.server.world;

import net.minecraft.class_2370;
import net.minecraft.class_2960;

public interface RemoveFromRegistry<T> {
    @SuppressWarnings("unchecked")
    static <T> boolean remove(class_2370<T> registry, class_2960 key) {
        return ((RemoveFromRegistry<T>) registry).remove(key);
    }

    boolean remove(class_2960 key);
}
