package dev.huntertagog.coresystem.fabric.server.world.island;

import java.util.UUID;
import net.minecraft.class_3218;

public final class IslandStyleSelector {

    private IslandStyleSelector() {
    }

    public static IslandStyle selectFor(class_3218 world, UUID ownerId, long worldSeed) {
        long h = worldSeed
                ^ ownerId.getMostSignificantBits()
                ^ ownerId.getLeastSignificantBits()
                ^ 0xCAFEBABECAFEL;

        IslandStyle[] values = IslandStyle.values();
        int idx = (int) (Math.abs(h) % values.length);
        return values[idx];
    }
}
