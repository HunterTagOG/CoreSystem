package dev.huntertagog.coresystem.fabric.common.clans.gui;

import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public final class ClanGuiPackets {

    public static final class_2960 ID_C2S_OPEN = class_2960.method_60655("coresystem", "clan_gui/open");
    public static final class_2960 ID_S2C_SNAPSHOT = class_2960.method_60655("coresystem", "clan_gui/snapshot");

    public static final class_2960 ID_C2S_KICK = class_2960.method_60655("coresystem", "clan_gui/kick");
    public static final class_2960 ID_C2S_SET_ROLE = class_2960.method_60655("coresystem", "clan_gui/set_role");
    public static final class_2960 ID_C2S_SETTINGS = class_2960.method_60655("coresystem", "clan_gui/settings");
    public static final class_2960 ID_C2S_ROLE_PERM = class_2960.method_60655("coresystem", "clan_gui/role_perm");

    public record C2SOpen() implements class_8710 {
        public static final class_9154<C2SOpen> ID = new class_9154<>(ID_C2S_OPEN);
        public static final class_9139<class_9129, C2SOpen> CODEC =
                class_9139.method_56438((v, buf) -> {
                }, buf -> new C2SOpen());

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record S2CSnapshot(ClanGuiSnapshot snapshot) implements class_8710 {
        public static final class_9154<S2CSnapshot> ID = new class_9154<>(ID_S2C_SNAPSHOT);
        public static final class_9139<class_9129, S2CSnapshot> CODEC =
                class_9139.method_56438(
                        (value, buf) -> value.snapshot().write(buf),
                        buf -> new S2CSnapshot(ClanGuiSnapshot.read(buf))
                );

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record C2SKick(UUID target) implements class_8710 {
        public static final class_9154<C2SKick> ID = new class_9154<>(ID_C2S_KICK);
        public static final class_9139<class_9129, C2SKick> CODEC =
                class_9139.method_56438((v, buf) -> buf.method_10797(v.target), buf -> new C2SKick(buf.method_10790()));

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record C2SSetRole(UUID target, String roleId) implements class_8710 {
        public static final class_9154<C2SSetRole> ID = new class_9154<>(ID_C2S_SET_ROLE);
        public static final class_9139<class_9129, C2SSetRole> CODEC =
                class_9139.method_56438(
                        (v, buf) -> {
                            buf.method_10797(v.target);
                            buf.method_10814(v.roleId);
                        },
                        buf -> new C2SSetRole(buf.method_10790(), buf.method_19772())
                );

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record C2SSetSettings(boolean openInvites, boolean friendlyFire,
                                 boolean clanChatDefault) implements class_8710 {
        public static final class_9154<C2SSetSettings> ID = new class_9154<>(ID_C2S_SETTINGS);
        public static final class_9139<class_9129, C2SSetSettings> CODEC =
                class_9139.method_56438(
                        (v, buf) -> {
                            buf.method_52964(v.openInvites);
                            buf.method_52964(v.friendlyFire);
                            buf.method_52964(v.clanChatDefault);
                        },
                        buf -> new C2SSetSettings(buf.readBoolean(), buf.readBoolean(), buf.readBoolean())
                );

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record C2SSetRolePermission(String roleId, String permissionKey, boolean enabled) implements class_8710 {
        public static final class_9154<C2SSetRolePermission> ID = new class_9154<>(ID_C2S_ROLE_PERM);
        public static final class_9139<class_9129, C2SSetRolePermission> CODEC =
                class_9139.method_56438(
                        (v, buf) -> {
                            buf.method_10814(v.roleId);
                            buf.method_10814(v.permissionKey);
                            buf.method_52964(v.enabled);
                        },
                        buf -> new C2SSetRolePermission(buf.method_19772(), buf.method_19772(), buf.readBoolean())
                );

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    private ClanGuiPackets() {
    }
}
