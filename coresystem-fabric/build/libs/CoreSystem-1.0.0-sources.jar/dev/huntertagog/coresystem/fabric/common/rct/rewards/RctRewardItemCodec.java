package dev.huntertagog.coresystem.fabric.common.rct.rewards;

import dev.huntertagog.coresystem.common.rct.rewards.dto.RctRewardItemDto;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Base64;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2507;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_7225;
import net.minecraft.class_7923;

public final class RctRewardItemCodec {

    private RctRewardItemCodec() {
    }

    public static RctRewardItemDto toDto(class_1799 stack, class_7225.class_7874 registries) {
        if (stack == null || stack.method_7960()) {
            return new RctRewardItemDto("minecraft:air", 0, "");
        }

        class_2960 id = class_7923.field_41178.method_10221(stack.method_7909());
        int count = stack.method_7947();

        class_2487 nbt = new class_2487();
        // "encode" kann NbtElement sein → robust handeln
        class_2520 encoded = stack.method_57358(registries);
        if (encoded instanceof class_2487 c) {
            nbt = c;
        } else {
            // Fallback: in Compound legen
            nbt.method_10566("stack", encoded);
        }

        String nbtB64 = NbtBase64Codec.toBase64(nbt);
        return new RctRewardItemDto(id.toString(), count, nbtB64);
    }

    public static class_1799 fromDto(RctRewardItemDto dto, class_7225.class_7874 registries) {
        if (dto == null || dto.itemId() == null || dto.itemId().isBlank() || dto.count() <= 0) {
            return class_1799.field_8037;
        }

        // Wenn NBT vorhanden ist: bevorzugt daraus den kompletten Stack rekonstruieren
        if (dto.nbtBase64() != null && !dto.nbtBase64().isBlank()) {
            class_2487 nbt = NbtBase64Codec.fromBase64(dto.nbtBase64());
            if (nbt != null) {
                // falls du oben "stack" als wrapper genutzt hast
                if (nbt.method_10573("stack", class_2520.field_33260)) {
                    nbt = nbt.method_10562("stack");
                }

                class_1799 rebuilt = ItemStackCompat.fromNbtCompat(registries, nbt);
                if (!rebuilt.method_7960()) {
                    // Count aus DTO ist “source of truth” (optional)
                    rebuilt.method_7939(dto.count());
                    return rebuilt;
                }
            }
        }

        // Fallback: Item + Count (ohne Custom-NBT)
        class_1792 item = class_7923.field_41178.method_10223(class_2960.method_60654(dto.itemId()));
        return new class_1799(item, dto.count());
    }

    // ------------------------------------------------------------
    // NBT<->Base64 helper (gzip) mit NbtSizeTracker/NbtAccounter Fallback
    // ------------------------------------------------------------
    private static final class NbtBase64Codec {

        static String toBase64(class_2487 nbt) {
            try {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                class_2507.method_10634(nbt, baos);
                return Base64.getEncoder().encodeToString(baos.toByteArray());
            } catch (Exception e) {
                return "";
            }
        }

        static class_2487 fromBase64(String base64) {
            try {
                byte[] bytes = Base64.getDecoder().decode(base64);
                ByteArrayInputStream bais = new ByteArrayInputStream(bytes);

                // MC-Versionen: mal NbtSizeTracker, mal NbtAccounter, mal ohne Parameter.
                // Wir lösen das robust per Reflection.
                return readCompressedCompat(bais);

            } catch (Exception e) {
                return null;
            }
        }

        private static class_2487 readCompressedCompat(ByteArrayInputStream in) throws Exception {
            // 1) NbtIo.readCompressed(InputStream) – falls vorhanden
            try {
                var m = class_2507.class.getMethod("readCompressed", java.io.InputStream.class);
                Object res = m.invoke(null, in);
                return (class_2487) res;
            } catch (NoSuchMethodException ignored) {
            }

            // 2) NbtIo.readCompressed(InputStream, NbtSizeTracker)
            try {
                Class<?> tracker = Class.forName("net.minecraft.nbt.NbtSizeTracker");
                var ofUnlimited = tracker.getMethod("ofUnlimitedBytes");
                Object trackerInstance = ofUnlimited.invoke(null);

                var m = class_2507.class.getMethod("readCompressed", java.io.InputStream.class, tracker);
                Object res = m.invoke(null, in, trackerInstance);
                return (class_2487) res;
            } catch (ClassNotFoundException | NoSuchMethodException ignored) {
            }

            // 3) NbtIo.readCompressed(InputStream, NbtAccounter)
            Class<?> accounter = Class.forName("net.minecraft.nbt.NbtAccounter");
            Object accounterInstance;
            try {
                accounterInstance = accounter.getMethod("unlimitedHeap").invoke(null);
            } catch (NoSuchMethodException e) {
                // older: constructor(long)
                accounterInstance = accounter.getConstructor(long.class).newInstance(Long.MAX_VALUE);
            }

            var m = class_2507.class.getMethod("readCompressed", java.io.InputStream.class, accounter);
            Object res = m.invoke(null, in, accounterInstance);
            return (class_2487) res;
        }
    }

    private static final class ItemStackCompat {

        private ItemStackCompat() {
        }

        static class_1799 fromNbtCompat(class_7225.class_7874 registries, class_2487 nbt) {
            try {
                // 1) ItemStack.fromNbt(WrapperLookup, NbtCompound)
                try {
                    var m = class_1799.class.getMethod("fromNbt", class_7225.class_7874.class, class_2487.class);
                    Object res = m.invoke(null, registries, nbt);
                    return (class_1799) res;
                } catch (NoSuchMethodException ignored) {
                }

                // 2) ItemStack.fromNbtOrEmpty(WrapperLookup, NbtCompound)
                try {
                    var m = class_1799.class.getMethod("fromNbtOrEmpty", class_7225.class_7874.class, class_2487.class);
                    Object res = m.invoke(null, registries, nbt);
                    return (class_1799) res;
                } catch (NoSuchMethodException ignored) {
                }

                // 3) older: ItemStack.of(NbtCompound)
                try {
                    var m = class_1799.class.getMethod("of", class_2487.class);
                    Object res = m.invoke(null, nbt);
                    return (class_1799) res;
                } catch (NoSuchMethodException ignored) {
                }

            } catch (Exception ignored) {
            }

            return class_1799.field_8037;
        }
    }

}
