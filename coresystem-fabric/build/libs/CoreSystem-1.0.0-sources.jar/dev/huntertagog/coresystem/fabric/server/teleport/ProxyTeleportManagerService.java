package dev.huntertagog.coresystem.fabric.server.teleport;

import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import dev.huntertagog.coresystem.fabric.common.teleport.TeleportManagerService;
import dev.huntertagog.coresystem.fabric.server.bridge.VelocityBridgeClient;
import dev.huntertagog.coresystem.platform.bridge.codec.BridgeCodec;
import dev.huntertagog.coresystem.platform.player.playerdata.PlayerDataSyncService;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;
import net.minecraft.class_3222;

public final class ProxyTeleportManagerService implements TeleportManagerService {

    private final VelocityBridgeClient bridge;
    private final String replyToNodeId;

    public ProxyTeleportManagerService(VelocityBridgeClient bridge, String replyToNodeId) {
        this.bridge = bridge;
        this.replyToNodeId = replyToNodeId;
    }

    @Override
    public boolean teleportPlayer(@NotNull class_3222 player,
                                  @NotNull String targetServerName,
                                  String inventoryContext,
                                  String reason
    ) {

        UUID requestId = UUID.randomUUID();
        UUID playerId = player.method_5667();

        byte[] payload = BridgeCodec.encodeTeleportRequest(
                requestId,
                playerId,
                targetServerName,
                reason,
                inventoryContext,
                replyToNodeId
        );

        PlayerDataSyncService service = ServiceProvider.getService(PlayerDataSyncService.class);
        service.saveInventorySnapshot(player.method_5667(), inventoryContext, "proxy-teleport-" + requestId);

        // fire-and-forget zum Proxy (carrier player wird intern gewählt)
        return bridge.sendToProxy(payload);
    }

    @Override
    public boolean handleJoinOnThisServer(@NotNull class_3222 player) {
        return false;
    }
}
