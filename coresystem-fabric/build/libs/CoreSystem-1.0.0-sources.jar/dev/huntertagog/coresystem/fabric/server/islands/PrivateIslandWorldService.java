package dev.huntertagog.coresystem.fabric.server.islands;

import com.google.common.collect.ImmutableList;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.common.log.Logger;
import dev.huntertagog.coresystem.common.log.LoggerFactory;
import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import dev.huntertagog.coresystem.fabric.common.teleport.TeleportManagerService;
import dev.huntertagog.coresystem.fabric.mixin.MinecraftServerAccess;
import dev.huntertagog.coresystem.fabric.server.world.gen.VoidWorldProgressListener;
import dev.huntertagog.coresystem.fabric.server.world.runtime.RuntimeWorldConfig;
import dev.huntertagog.coresystem.fabric.server.world.runtime.RuntimeWorldHandle;
import dev.huntertagog.coresystem.fabric.server.world.runtime.RuntimeWorldProperties;
import dev.huntertagog.coresystem.platform.task.TaskScheduler;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.minecraft.class_156;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_32;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4543;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_7924;
import net.minecraft.class_8565;
import net.minecraft.server.MinecraftServer;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

public final class PrivateIslandWorldService {

    private static final Logger LOG = LoggerFactory.get("PrivateIslandWorldService");

    public static final String ID = "piws";

    private static PrivateIslandWorldService instance;

    private final Set<class_3218> deletionQueue = new ReferenceOpenHashSet<>();
    private final MinecraftServer server;
    private final MinecraftServerAccess serverAccess;

    // optionaler Scheduler-Task für das regelmäßige Abarbeiten der Delete-Queue
    private TaskScheduler.ScheduledTask deletionTask;

    private PrivateIslandWorldService(MinecraftServer server) {
        this.server = server;
        this.serverAccess = (MinecraftServerAccess) server;

        // Scheduler-basiertes Ticking statt globalem ServerTickEvents
        TaskScheduler scheduler = ServiceProvider.getService(TaskScheduler.class);
        if (scheduler != null) {
            // alle Sekunde prüfen (20 Ticks)
            this.deletionTask = scheduler.runSyncRepeating(
                    this::tick,
                    20,
                    20
            );
            LOG.info("Registered deletion queue tick task for PrivateIslandWorldService.");
        } else {
            CoreError error = CoreError.of(
                            CoreErrorCode.SCHEDULER_MISSING,
                            CoreErrorSeverity.WARN,
                            "TaskScheduler not available – PrivateIslandWorldService will not tick deletion queue automatically."
                    )
                    .withContextEntry("service", "PrivateIslandWorldService");

            LOG.warn(error.toLogString());
        }
    }

    public static PrivateIslandWorldService get(MinecraftServer server) {
        if (instance == null || instance.server != server) {
            instance = new PrivateIslandWorldService(server);
        }
        return instance;
    }

    // --------------------------------------------------------
    // Lifecycle / Ticking
    // --------------------------------------------------------

    private void tick() {
        if (this.deletionQueue.isEmpty()) {
            return;
        }

        try {
            // nur Welten entfernen, die vollständig „leer“ sind
            this.deletionQueue.removeIf(this::tickDeleteWorld);
        } catch (Exception e) {
            CoreError error = CoreError.of(
                            CoreErrorCode.ISLAND_WORLD_DELETE_TICK_FAILED,
                            CoreErrorSeverity.ERROR,
                            "Unexpected error while ticking island deletion queue."
                    )
                    .withCause(e)
                    .withContextEntry("queueSize", this.deletionQueue.size());

            LOG.error(error.toLogString(), e);
        }
    }

    public void shutdown() {
        if (deletionTask != null && !deletionTask.isCancelled()) {
            deletionTask.cancel();
            deletionTask = null;
        }
        deletionQueue.clear();
        LOG.info("PrivateIslandWorldService shutdown – deletion task cancelled and queue cleared.");
    }

    // --------------------------------------------------------
    // Public API
    // --------------------------------------------------------

    public CompletableFuture<RuntimeWorldHandle> getOrOpenPersistentWorld(class_2960 key, RuntimeWorldConfig config) {
        // supplyAsync mit server als Executor = auf MC-Thread ausführen
        return CompletableFuture.supplyAsync(() -> {
                    try {
                        class_5321<class_1937> worldKey = class_5321.method_29179(class_7924.field_41223, key);
                        class_3218 world = this.server.method_3847(worldKey);
                        if (world != null) {
                            this.deletionQueue.remove(world);
                            return world;
                        }

                        return this.openPersistentWorld(key, config);
                    } catch (Exception e) {
                        CoreError error = CoreError.of(
                                        CoreErrorCode.RUNTIME_WORLD_OPEN_FAILED,
                                        CoreErrorSeverity.ERROR,
                                        "Failed to open or create persistent island world."
                                )
                                .withCause(e)
                                .withContextEntry("worldId", key.toString());

                        LOG.error(error.toLogString(), e);
                        throw e;
                    }
                }, this.server)
                .thenApply(world -> new RuntimeWorldHandle(this, world));
    }

    public void enqueueWorldDeletion(class_3218 world) {
        // wir laufen meistens ohnehin auf dem Server-Thread, aber zur Sicherheit:
        server.execute(() -> this.deletionQueue.add(world));
    }

    public Object getDeletionQueue() {
        return this.deletionQueue;
    }

    // --------------------------------------------------------
    // Intern: Welt-Erstellung / -Löschung
    // --------------------------------------------------------

    class_3218 openPersistentWorld(class_2960 key, RuntimeWorldConfig config) {
        try {
            class_5321<class_1937> worldKey = class_5321.method_29179(class_7924.field_41223, key);

            class_5363 options = new class_5363(
                    config.getDimensionType(this.server),
                    config.getGenerator()
            );

            RuntimeWorldProperties properties = new RuntimeWorldProperties(this.server.method_27728(), config);

            // Wichtig: RandomSequencesState wie Vanilla handhaben (Overworld teilen ist ok)
            class_3218 overworld = this.server.method_30002();
            class_8565 randomSequences =
                    overworld != null ? overworld.method_52168() : class_8565.method_51842(config.getSeed(), new class_2487());

            class_3218 world = new class_3218(
                    this.server,
                    class_156.method_18349(),
                    ((MinecraftServerAccess) this.server).getSession(),
                    properties,
                    worldKey,
                    options,
                    VoidWorldProgressListener.INSTANCE,
                    false,
                    class_4543.method_27984(config.getSeed()),
                    ImmutableList.of(),
                    false,
                    randomSequences
            );

            return this.addWorld(world);
        } catch (Exception e) {
            CoreError error = CoreError.of(
                            CoreErrorCode.RUNTIME_WORLD_CONSTRUCTION_FAILED,
                            CoreErrorSeverity.ERROR,
                            "Failed to construct island ServerWorld instance."
                    )
                    .withCause(e)
                    .withContextEntry("worldId", key.toString());
            LOG.error(error.toLogString(), e);
            throw e;
        }
    }

    private <T extends class_3218> T addWorld(T world) {
        this.serverAccess.getWorlds().put(world.method_27983(), world);
        ServerWorldEvents.LOAD.invoker().onWorldLoad(this.server, world);
        return world;
    }

    private boolean tickDeleteWorld(class_3218 world) {
        if (this.isWorldUnloaded(world)) {
            this.deleteWorld(world);
            return true;
        } else {
            this.kickPlayers(world);
            return false;
        }
    }

    private void kickPlayers(class_3218 world) {
        if (world.method_18456().isEmpty()) {
            return;
        }

        List<class_3222> players = new ArrayList<>(world.method_18456());
        for (class_3222 player : players) {
            TeleportManagerService tp = ServiceProvider.getService(TeleportManagerService.class);
            tp.teleportPlayer(player, "lobby", "delete-kick", "Player kicked from island world for deletion.");
        }
    }

    private boolean isWorldUnloaded(class_3218 world) {
        return world.method_18456().isEmpty()
                && world.method_14178().method_14151() <= 0;
    }

    private void deleteWorld(class_3218 world) {
        class_5321<class_1937> worldKey = world.method_27983();
        class_2960 id = worldKey.method_29177();

        if (this.serverAccess.getWorlds().remove(worldKey, world)) {
            ServerWorldEvents.UNLOAD.invoker().onWorldUnload(this.server, world);

            class_32.class_5143 session = this.serverAccess.getSession();
            File worldDirectory = session.method_27424(worldKey).toFile();
            if (worldDirectory.exists()) {
                try {
                    FileUtils.deleteDirectory(worldDirectory);
                } catch (IOException e) {
                    CoreError error = CoreError.of(
                                    CoreErrorCode.WORLD_DIRECTORY_DELETE_FAILED,
                                    CoreErrorSeverity.WARN,
                                    "Failed to delete world directory, scheduling deleteOnExit."
                            )
                            .withCause(e)
                            .withContextEntry("worldDir", worldDirectory.getAbsolutePath())
                            .withContextEntry("dimension", id.toString());

                    LOG.warn(error.toLogString(), e);

                    try {
                        FileUtils.forceDeleteOnExit(worldDirectory);
                    } catch (IOException ignored) {
                        // hier bewusst nur still, wir haben oben bereits den Error geloggt
                    }
                }
            }

            LOG.info("Deleted island world '{}'.", id);
        }
    }
}
