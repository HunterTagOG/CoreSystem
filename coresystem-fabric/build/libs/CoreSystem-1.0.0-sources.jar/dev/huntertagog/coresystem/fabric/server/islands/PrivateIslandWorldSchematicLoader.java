package dev.huntertagog.coresystem.fabric.server.islands;

import dev.huntertagog.coresystem.common.log.Logger;
import dev.huntertagog.coresystem.common.log.LoggerFactory;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3485;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.class_5819;

public final class PrivateIslandWorldSchematicLoader {

    private static final Logger LOG = LoggerFactory.get("IslandSchematic");

    private static final List<class_2960> ISLAND_TEMPLATES = List.of(
            class_2960.method_60655("coresystem", "starter_island_1"),
            class_2960.method_60655("coresystem", "starter_island_2"),
            class_2960.method_60655("coresystem", "starter_island_3")
    );

    private static final class_2470[] ROTATIONS = new class_2470[]{
            class_2470.field_11467,
            class_2470.field_11463,
            class_2470.field_11464,
            class_2470.field_11465
    };

    private PrivateIslandWorldSchematicLoader() {
    }

    public static void placeRandomStarterIsland(class_3218 world) {
        // ✅ One-Time Gate (persistiert)

        var psm = world.method_17983();

        // Type bereitstellen (dein TYPE mit Supplier + fromNbt)
        PrivateIslandInitState state = psm.method_17924(
                PrivateIslandInitState.TYPE,
                PrivateIslandInitState.KEY
        );

        if (state.isInitialized()) {
            // Already done -> kein Double-Placement
            return;
        }

        class_3485 stm = world.method_14183();
        class_5819 random = world.method_8409();

        class_2960 templateId = ISLAND_TEMPLATES.get(random.method_43048(ISLAND_TEMPLATES.size()));
        class_3499 template = stm.method_15094(templateId).orElse(null);
        if (template == null) {
            LOG.warn("Missing starter template: {} (world={})", templateId, world.method_27983().method_29177());
            return;
        }

        class_2470 rotation = ROTATIONS[random.method_43048(ROTATIONS.length)];
        class_2415 mirror = class_2415.field_11302;

        // ✅ “Business Default”: Spawn als Referenz (statt hart 0/64/0)
        class_2338 origin = world.method_43126();
        // Optional: auf “Bodenhöhe” korrigieren, wenn dein Spawn nur ein Marker ist
        // origin = new BlockPos(origin.getX(), Math.max(origin.getY(), world.getSeaLevel() + 3), origin.getZ());

        // ✅ Chunk sicher laden (billig, vermeidet “silent fail”)
        world.method_8497(origin.method_10263() >> 4, origin.method_10260() >> 4);

        class_3492 placementData = new class_3492()
                .method_15123(rotation)
                .method_15125(mirror)
                // Performance/Consistency: Entities im Template in 99% der Fälle nicht gewünscht
                .method_15133(true);

        // flags=2 ist ok (Block updates). Wenn du Redstone/Physics vermeiden willst: 18/34 je nach Bedarf.
        template.method_15172(world, origin, origin, placementData, random, 2);

        // ✅ Marker setzen (idempotent + auditierbar)
        state.markInitialized();

        LOG.info("Placed starter island template={} rotation={} world={}",
                templateId, rotation, world.method_27983().method_29177());
    }
}
