package dev.huntertagog.coresystem.fabric.server.region.image;

import dev.huntertagog.coresystem.common.region.RegionImageFacing;
import dev.huntertagog.coresystem.common.region.RegionImageMode;
import dev.huntertagog.coresystem.fabric.common.region.RegionImageDef;
import java.util.*;
import net.minecraft.class_18;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_7225;

public final class RegionImageState extends class_18 {

    public static final String KEY = "coresystem_region_images";

    public static final class_8645<RegionImageState> TYPE = new class_8645<>(
            RegionImageState::new,
            RegionImageState::fromNbt,
            null
    );

    private final Map<String, RegionImageDef> byRegionId = new HashMap<>();

    public Optional<RegionImageDef> get(String regionId) {
        return Optional.ofNullable(byRegionId.get(regionId));
    }

    public Collection<RegionImageDef> all() {
        return List.copyOf(byRegionId.values());
    }

    public void put(RegionImageDef entry) {
        byRegionId.put(entry.regionId(), entry);
        method_80();
    }

    public void remove(String regionId) {
        byRegionId.remove(regionId);
        method_80();
    }

    @Override
    public class_2487 method_75(class_2487 nbt, class_7225.class_7874 lookup) {
        class_2499 entries = new class_2499();

        for (RegionImageDef e : byRegionId.values()) {
            class_2487 c = new class_2487();
            c.method_10582("regionId", e.regionId());
            c.method_10582("worldId", e.worldId().toString());

            c.method_10582("mode", e.mode().name());

            c.method_10582("facing", e.facing() == null ? "" : e.facing().name());
            c.method_10569("baseY", e.baseY());

            entries.add(c);
        }

        nbt.method_10566("entries", entries);
        return nbt;
    }

    public static RegionImageState fromNbt(class_2487 nbt, class_7225.class_7874 lookup) {
        RegionImageState st = new RegionImageState();

        if (!nbt.method_10573("entries", class_2520.field_33259)) return st;

        class_2499 list = nbt.method_10554("entries", class_2520.field_33260);
        for (int i = 0; i < list.size(); i++) {
            class_2487 c = list.method_10602(i);

            String regionId = c.method_10558("regionId");
            class_2960 worldId = class_2960.method_12829(c.method_10558("worldId"));
            if (worldId == null || regionId == null || regionId.isBlank()) continue;

            String imageKey = c.method_10558("imageKey");

            RegionImageMode mode = c.method_10573("mode", class_2520.field_33258)
                    ? safeMode(c.method_10558("mode"))
                    : RegionImageMode.WALL;

            RegionImageFacing facing = RegionImageFacing.valueOf(c.method_10573("facing", class_2520.field_33258) ? c.method_10558("facing") : "");
            int baseY = c.method_10573("baseY", class_2520.field_33253) ? c.method_10550("baseY") : 0;

            class_238 bounds = new class_238(
                    0, 0, 0,
                    0, 0, 0
            );

            st.byRegionId.put(regionId, new RegionImageDef(
                    regionId, worldId,
                    bounds, mode,
                    facing, baseY,
                    imageKey
            ));
        }

        return st;
    }

    private static RegionImageMode safeMode(String raw) {
        try {
            return RegionImageMode.valueOf(raw.toUpperCase(Locale.ROOT));
        } catch (Exception ignored) {
            return RegionImageMode.WALL;
        }
    }

    private static class_2499 writeUuidList(List<UUID> ids) {
        class_2499 l = new class_2499();
        if (ids == null || ids.isEmpty()) return l;
        for (UUID id : ids) {
            if (id != null) l.add(class_2519.method_23256(id.toString()));
        }
        return l;
    }

    private static List<UUID> readUuidList(class_2499 list) {
        if (list == null || list.isEmpty()) return List.of();
        List<UUID> out = new ArrayList<>(list.size());
        for (int i = 0; i < list.size(); i++) {
            String s = list.method_10608(i);
            try {
                out.add(UUID.fromString(s));
            } catch (Exception ignored) {
            }
        }
        return List.copyOf(out);
    }

    // -------- BlockPos list (Light blocks) --------

    private static class_2499 writeBlockPosList(List<class_2338> positions) {
        class_2499 l = new class_2499();
        if (positions == null || positions.isEmpty()) return l;

        for (class_2338 p : positions) {
            if (p == null) continue;
            class_2487 c = new class_2487();
            c.method_10569("x", p.method_10263());
            c.method_10569("y", p.method_10264());
            c.method_10569("z", p.method_10260());
            l.add(c);
        }
        return l;
    }

    private static List<class_2338> readBlockPosList(class_2499 list) {
        if (list == null || list.isEmpty()) return List.of();
        List<class_2338> out = new ArrayList<>(list.size());

        for (int i = 0; i < list.size(); i++) {
            class_2487 c = list.method_10602(i);
            out.add(new class_2338(c.method_10550("x"), c.method_10550("y"), c.method_10550("z")));
        }
        return List.copyOf(out);
    }

    // -------- int list helpers --------

    private static int[] toIntArray(List<Integer> list) {
        if (list == null || list.isEmpty()) return new int[0];
        int[] arr = new int[list.size()];
        for (int i = 0; i < list.size(); i++) {
            Integer v = list.get(i);
            arr[i] = (v != null) ? v : 0;
        }
        return arr;
    }

    private static List<Integer> toIntList(int[] arr) {
        if (arr == null || arr.length == 0) return List.of();
        List<Integer> out = new ArrayList<>(arr.length);
        for (int v : arr) out.add(v);
        return List.copyOf(out);
    }
}
