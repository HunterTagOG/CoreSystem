package dev.huntertagog.coresystem.fabric.common.rct.rewards;

import java.util.List;
import net.minecraft.class_1799;

public record RctRewardSpec(
        int money,                 // optional: CobbleDollars o.ä.
        List<class_1799> items,     // optional
        List<String> consoleCommands, // optional, {player} placeholder
        List<String> permissionNodes  // optional, wenn du ein Perm-System “grant” hast
) {
    public static RctRewardSpec empty() {
        return new RctRewardSpec(0, List.of(), List.of(), List.of());
    }
}
