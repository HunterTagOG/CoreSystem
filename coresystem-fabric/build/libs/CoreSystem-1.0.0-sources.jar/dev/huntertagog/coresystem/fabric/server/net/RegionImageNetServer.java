package dev.huntertagog.coresystem.fabric.server.net;

import dev.huntertagog.coresystem.fabric.common.net.payload.RegionImageSyncRequestC2SPayload;
import dev.huntertagog.coresystem.fabric.server.region.image.RegionImageServerService;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public final class RegionImageNetServer {

    private RegionImageNetServer() {
    }

    public static void register() {
        ServerPlayNetworking.registerGlobalReceiver(RegionImageSyncRequestC2SPayload.ID, (payload, context) -> {
            context.player().field_13995.execute(() -> {
                var server = context.player().field_13995;

                class_5321<net.minecraft.class_1937> key = class_5321.method_29179(class_7924.field_41223, payload.worldId());
                class_3218 world = server.method_3847(key);
                if (world == null) return;

                // ✅ Antwort: alles aus PersistentState an genau diesen Player senden
                RegionImageServerService.syncToPlayer(world, context.player());
            });
        });
    }
}
