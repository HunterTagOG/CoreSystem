package dev.huntertagog.coresystem.fabric.mixin;

import dev.huntertagog.coresystem.common.log.Logger;
import dev.huntertagog.coresystem.common.log.LoggerFactory;
import dev.huntertagog.coresystem.fabric.server.islands.PrivateIslandWorldNodeConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.nio.file.Files;
import java.nio.file.Path;
import net.minecraft.class_1937;
import net.minecraft.class_32;
import net.minecraft.class_5321;

@Mixin(class_32.class_5143.class)
public abstract class LevelStorageSessionMixin {

    @Unique
    private static final Logger LOG = LoggerFactory.get("WorldStorage");

    @Inject(
            method = "getWorldDirectory(Lnet/minecraft/registry/RegistryKey;)Ljava/nio/file/Path;",
            at = @At("HEAD"),
            cancellable = true
    )
    private void coresystem$redirectWorldPath(class_5321<class_1937> key, CallbackInfoReturnable<Path> cir) {
        // Nur unsere eigenen Island-Welten umleiten
        if (!PrivateIslandWorldNodeConfig.isIslandWorldKey(key)) {
            return; // Vanilla-/Fremd-Welten laufen über die normale Mojang-Logik
        }

        Path base = PrivateIslandWorldNodeConfig.getIslandsBasePath();
        Path customPath = PrivateIslandWorldNodeConfig.resolveIslandPath(base, key);

        try {
            Files.createDirectories(customPath);
        } catch (Exception e) {
            LOG.warn("Failed to create world directory '{}' for dimension '{}': {}",
                    customPath, key.method_29177(), e.getMessage());
        }

        LOG.debug("Routing ISLAND world directory for dimension '{}' to '{}'.",
                key.method_29177(), customPath);

        cir.setReturnValue(customPath);
    }
}
