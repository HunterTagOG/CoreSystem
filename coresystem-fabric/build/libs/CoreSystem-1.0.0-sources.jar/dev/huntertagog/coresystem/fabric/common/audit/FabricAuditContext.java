package dev.huntertagog.coresystem.fabric.common.audit;

import dev.huntertagog.coresystem.platform.audit.AuditContext;
import java.util.Optional;
import net.minecraft.class_2168;
import net.minecraft.class_3222;

public final class FabricAuditContext implements AuditContext {

    private final class_2168 source;
    private final String nodeId;

    public FabricAuditContext(class_2168 source) {
        this.source = source;
        this.nodeId = Optional.ofNullable(System.getenv("SERVER_ID")).orElse("default");
    }

    private Optional<class_3222> player() {
        try {
            return Optional.ofNullable(source.method_44023());
        } catch (Exception ignored) {
            return Optional.empty();
        }
    }

    @Override
    public Optional<String> actorId() {
        return player().map(p -> p.method_5667().toString());
    }

    @Override
    public String actorName() {
        return player()
                .map(p -> p.method_7334().getName())
                .orElse("CONSOLE");
    }

    @Override
    public String serverName() {
        // Velocity-Servername wäre idealerweise über config/ENV, aber das passt als Fallback:
        return source.method_9211().method_16898();
    }

    @Override
    public String nodeId() {
        return nodeId;
    }

    @Override
    public AuditActorType actorType() {
        return player().isPresent()
                ? AuditActorType.PLAYER
                : AuditActorType.CONSOLE;
    }
}
