package dev.huntertagog.coresystem.fabric.common.net.payload;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record RegionImageSyncRequestC2SPayload(
        class_2960 worldId
) implements class_8710 {

    public static final class_2960 RAW_ID = class_2960.method_60655("coresystem", "region_image_sync_request_c2s");
    public static final class_8710.class_9154<RegionImageSyncRequestC2SPayload> ID = new class_8710.class_9154<>(RAW_ID);

    public static final class_9139<class_2540, RegionImageSyncRequestC2SPayload> CODEC =
            class_9139.method_56434(
                    class_2960.field_48267, RegionImageSyncRequestC2SPayload::worldId,
                    RegionImageSyncRequestC2SPayload::new
            );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
