package dev.huntertagog.coresystem.fabric.common.text;

import dev.huntertagog.coresystem.common.text.CoreMessage;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

public final class MessageItems {

    private MessageItems() {
    }

    /**
     * Baut einen ItemStack mit lokalisiertem Namen + Lore.
     */
    public static class_1799 stack(class_1792 item,
                                  CoreMessage displayNameKey,
                                  CoreMessage... loreKeys) {
        class_1799 stack = new class_1799(item);
        applyDisplayName(stack, displayNameKey);
        applyLore(stack, loreKeys);
        return stack;
    }

    /**
     * Setzt den angepassten Display-Namen via DataComponent CUSTOM_NAME.
     */
    public static void applyDisplayName(class_1799 stack, CoreMessage displayNameKey) {
        if (displayNameKey == null) {
            return;
        }
        class_2561 name = Messages.t(displayNameKey);
        stack.method_57379(class_9334.field_49631, name);
    }

    /**
     * Setzt Lore-Zeilen via DataComponent LORE.
     */
    public static void applyLore(class_1799 stack, CoreMessage... loreKeys) {
        if (loreKeys == null || loreKeys.length == 0) {
            return;
        }

        List<class_2561> lines = Arrays.stream(loreKeys)
                .map(Messages::t)
                .collect(Collectors.toList());

        if (lines.isEmpty()) {
            return;
        }

        class_9290 lore = new class_9290(lines);
        stack.method_57379(class_9334.field_49632, lore);
    }
}
