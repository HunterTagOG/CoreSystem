package dev.huntertagog.coresystem.fabric.server.world.island;

import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.common.log.Logger;
import dev.huntertagog.coresystem.common.log.LoggerFactory;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2397;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

public final class IslandDecorator {

    private static final Logger LOG = LoggerFactory.get("IslandDecorator");

    // Basisblöcke
    private static final class_2680 GRASS_BLOCK = class_2246.field_10219.method_9564();
    private static final class_2680 DIRT = class_2246.field_10566.method_9564();
    private static final class_2680 SAND = class_2246.field_10102.method_9564();
    private static final class_2680 WATER = class_2246.field_10382.method_9564();

    // Flora
    private static final class_2680 TALL_GRASS = class_2246.field_10214.method_9564();
    private static final class_2680 FERN = class_2246.field_10112.method_9564();
    private static final class_2680 FLOWER_1 = class_2246.field_10182.method_9564();
    private static final class_2680 FLOWER_2 = class_2246.field_10449.method_9564();
    private static final class_2680 FLOWER_3 = class_2246.field_10315.method_9564();

    // Logs / Leaves für Baumtypen
    private static final class_2680 OAK_LOG = class_2246.field_10431.method_9564();
    private static final class_2680 BIRCH_LOG = class_2246.field_10511.method_9564();
    private static final class_2680 SPRUCE_LOG = class_2246.field_10037.method_9564();

    private static final class_2680 OAK_LEAVES =
            class_2246.field_10503.method_9564()
                    .method_11657(class_2397.field_11200, true)
                    .method_11657(class_2397.field_11199, 7);

    private static final class_2680 BIRCH_LEAVES =
            class_2246.field_10539.method_9564()
                    .method_11657(class_2397.field_11200, true)
                    .method_11657(class_2397.field_11199, 7);

    private static final class_2680 SPRUCE_LEAVES =
            class_2246.field_9988.method_9564()
                    .method_11657(class_2397.field_11200, true)
                    .method_11657(class_2397.field_11199, 7);

    // „Felsen“-Material
    private static final class_2680 STONE = class_2246.field_10340.method_9564();
    private static final class_2680 COBBLESTONE = class_2246.field_10445.method_9564();
    private static final class_2680 GRAVEL = class_2246.field_10255.method_9564();
    private static final class_2680 COARSE_DIRT = class_2246.field_10253.method_9564();

    private IslandDecorator() {
    }

    /**
     * Dekoriert eine generierte Ocean-Insel.
     * Muss auf dem Server-Thread laufen.
     */
    public static void decorateOceanIsland(class_3218 world,
                                           IslandHeightmap heightmap,
                                           int islandRadiusBlocks,
                                           int seaLevel,
                                           IslandStyle style,
                                           long seed) {

        LOG.info("Decorating island (radius={} blocks, style={}) in world '{}'",
                islandRadiusBlocks, style.name(), world.method_27983().method_29177());

        try {
            Random random = new Random(seed ^ (style.ordinal() * 31L) ^ 0xDEADBEEFCAFEL);

            // 1) Beach-Rand
            decorateBeachRing(world, heightmap, islandRadiusBlocks, seaLevel, style, random);

            // 2) Optional: Rock-Patches
            if (style.groundProfile().stonePatchChance() > 0.01f) {
                placeRockPatches(world, heightmap, islandRadiusBlocks, seaLevel,
                        style.groundProfile().stonePatchChance(), random);
            }

            // 3) Tree-Spots sammeln
            float treeSpotDensity = computeTreeSpotDensity(islandRadiusBlocks, style.treeProfile());
            List<class_2338> treeSpots = findTreeSpots(world, heightmap, islandRadiusBlocks, seaLevel, random, treeSpotDensity);

            int treeCount = computeTreeCount(islandRadiusBlocks, style.treeProfile(), random);
            if (!treeSpots.isEmpty()) {
                treeCount = Math.min(treeCount, treeSpots.size());
            }

            LOG.info("Placing {} trees on island (style={}).", treeCount, style.name());

            for (int i = 0; i < treeCount; i++) {
                class_2338 base = treeSpots.get(i);
                placeStyleTree(world, base, heightmap, style.treeProfile(), random);
            }

            // 4) Flora
            decorateFlora(world, heightmap, islandRadiusBlocks, seaLevel, style.floraProfile(), random);

            LOG.info("Decoration of island in world '{}' (style={}) finished.",
                    world.method_27983().method_29177(), style.name());

        } catch (Exception e) {
            CoreError error = CoreError.of(
                            CoreErrorCode.MESSAGE_ERROR,           // falls du einen dedizierten WORLDGEN/DECORATION-Code hast, hier tauschen
                            CoreErrorSeverity.ERROR,
                            "Exception during island decoration"
                    )
                    .withCause(e)
                    .withContextEntry("world", world.method_27983().method_29177().toString())
                    .withContextEntry("radiusBlocks", islandRadiusBlocks)
                    .withContextEntry("seaLevel", seaLevel)
                    .withContextEntry("style", style != null ? style.name() : "null")
                    .withContextEntry("seed", seed);

            LOG.error(error.toLogString(), e);
        }
    }

    // ------------------------------------------------------
    // 1. Beach-Rand
    // ------------------------------------------------------

    private static void decorateBeachRing(class_3218 world,
                                          IslandHeightmap heightmap,
                                          int radiusBlocks,
                                          int seaLevel,
                                          IslandStyle style,
                                          Random random) {

        int padding = 3;
        int minRadius = radiusBlocks - padding;
        int maxRadius = radiusBlocks + 1;

        int step = 2;

        float baseCoverage = 0.4f;
        float coverage = baseCoverage * style.beachCoverageFactor();

        for (int x = -radiusBlocks - 2; x <= radiusBlocks + 2; x += step) {
            for (int z = -radiusBlocks - 2; z <= radiusBlocks + 2; z += step) {

                double dist = Math.sqrt(x * x + z * z);
                if (dist < minRadius || dist > maxRadius) continue;

                if (random.nextFloat() > coverage) continue;

                int h = heightmap.sampleHeight(x, z);
                if (h < 0) continue;

                class_2338 top = new class_2338(x, h, z);
                class_2680 current = world.method_8320(top);
                if (!current.method_27852(class_2246.field_10219) &&
                        !current.method_27852(class_2246.field_10566) &&
                        !current.method_27852(class_2246.field_10253)) {
                    continue;
                }

                // Sand nach unten
                for (int dy = 0; dy <= 3; dy++) {
                    class_2338 p = top.method_10087(dy);
                    if (p.method_10264() < world.method_31607()) break;
                    class_2680 s = world.method_8320(p);
                    if (s.method_27852(class_2246.field_10124) || s.method_27852(class_2246.field_10382)) break;
                    world.method_8652(p, SAND, class_2248.field_31028);
                }

                // Wasser bis Meeresspiegel auffüllen
                for (int y = h + 1; y <= seaLevel; y++) {
                    class_2338 waterPos = new class_2338(x, y, z);
                    if (world.method_8320(waterPos).method_26215()) {
                        world.method_8652(waterPos, WATER, class_2248.field_31028);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------
    // 2. Rock-Patches / kleine Hügel
    // ------------------------------------------------------

    private static void placeRockPatches(class_3218 world,
                                         IslandHeightmap heightmap,
                                         int radiusBlocks,
                                         int seaLevel,
                                         float stonePatchChance,
                                         Random random) {

        int basePatches = Math.max(1, radiusBlocks / 16);
        int patchCount = (int) Math.round(basePatches * (0.5 + stonePatchChance * 2.0));

        for (int i = 0; i < patchCount; i++) {
            int px = random.nextInt(radiusBlocks * 2 + 1) - radiusBlocks;
            int pz = random.nextInt(radiusBlocks * 2 + 1) - radiusBlocks;

            double dist = Math.sqrt(px * px + pz * pz);
            if (dist > radiusBlocks - 4) continue;

            int h = heightmap.sampleHeight(px, pz);
            if (h < 0) continue;
            if (h <= seaLevel + 1) continue;

            int radius = 2 + random.nextInt(3); // 2–4
            carveRockPatch(world, new class_2338(px, h, pz), radius, random);
        }
    }

    private static void carveRockPatch(class_3218 world, class_2338 center, int radius, Random random) {
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > radius + random.nextFloat() * 0.7f) continue;

                class_2338 ground = center.method_10069(dx, 0, dz);
                class_2680 below = world.method_8320(ground);

                if (!below.method_27852(class_2246.field_10219)
                        && !below.method_27852(class_2246.field_10566)
                        && !below.method_27852(class_2246.field_10253)) {
                    continue;
                }

                float r = random.nextFloat();
                class_2680 newState;
                if (r < 0.5f) newState = STONE;
                else if (r < 0.7f) newState = COBBLESTONE;
                else if (r < 0.85f) newState = GRAVEL;
                else newState = COARSE_DIRT;

                world.method_8652(ground, newState, class_2248.field_31028);

                class_2338 above = ground.method_10084();
                if (!world.method_8320(above).method_26215()) {
                    world.method_8652(above, class_2246.field_10124.method_9564(), class_2248.field_31028);
                }
            }
        }
    }

    // ------------------------------------------------------
    // 3. Tree-Spots & Anzahl
    // ------------------------------------------------------

    private static float computeTreeSpotDensity(int radiusBlocks,
                                                IslandStyle.TreeProfile treeProfile) {
        float base = 0.18f;
        float factor = Math.min(0.5f, treeProfile.maxTrees() / 32.0f);
        return Math.min(0.6f, base + factor);
    }

    private static List<class_2338> findTreeSpots(class_3218 world,
                                                IslandHeightmap heightmap,
                                                int radiusBlocks,
                                                int seaLevel,
                                                Random random,
                                                float density) {
        List<class_2338> spots = new ArrayList<>();

        int innerRadius = radiusBlocks - 4;
        int step = 2;

        for (int x = -innerRadius; x <= innerRadius; x += step) {
            for (int z = -innerRadius; z <= innerRadius; z += step) {
                double dist = Math.sqrt(x * x + z * z);
                if (dist > innerRadius) continue;

                int h = heightmap.sampleHeight(x, z);
                if (h < 0) continue;
                if (h <= seaLevel + 1) continue;

                class_2338 ground = new class_2338(x, h, z);
                class_2680 groundState = world.method_8320(ground);
                if (!groundState.method_27852(class_2246.field_10219)
                        && !groundState.method_27852(class_2246.field_10566)
                        && !groundState.method_27852(class_2246.field_10253)) {
                    continue;
                }

                class_2338 above = ground.method_10084();
                if (!world.method_8320(above).method_26215()) continue;

                if (random.nextFloat() > density) continue;

                spots.add(ground);
            }
        }

        Collections.shuffle(spots, random);
        return spots;
    }

    private static int computeTreeCount(int radiusBlocks,
                                        IslandStyle.TreeProfile treeProfile,
                                        Random random) {

        int min = treeProfile.minTrees();
        int max = treeProfile.maxTrees();

        double areaFactor = Math.min(1.5, Math.max(0.5, (radiusBlocks * radiusBlocks) / 1024.0));
        int base = (int) Math.round(min + (max - min) * areaFactor * 0.66);

        base += random.nextInt(3) - 1; // -1..+1

        if (base < min) base = min;
        if (base > max) base = max;
        return base;
    }

    // ------------------------------------------------------
    // 4. Tree-Placer mit Biome-Override
    // ------------------------------------------------------

    private static void placeStyleTree(class_3218 world,
                                       class_2338 ground,
                                       IslandHeightmap heightmap,
                                       IslandStyle.TreeProfile profile,
                                       Random random) {

        IslandHeightmap.BiomeType biome = heightmap.pickBiome(ground.method_10263(), ground.method_10260());

        // Biome-spezifische Overrides
        switch (biome) {
            case JUNGLE -> {
                placeOakLikeTree(world, ground, IslandStyle.TreeProfile.TreeType.PALM_LIKE_OAK, random);
                return;
            }
            case SAVANNA -> {
                placeOakLikeTree(world, ground, IslandStyle.TreeProfile.TreeType.SPARSE_OAK, random);
                return;
            }
            case TAIGA -> {
                placeSpruceTree(world, ground, random);
                return;
            }
            case FROSTLAND -> {
                // keine Bäume
                return;
            }
            case MEADOW -> {
                // fällt auf Style zurück
            }
        }

        // Style-basierte Standard-Bepflanzung
        IslandStyle.TreeProfile.TreeType type = profile.type();

        switch (type) {
            case OAK, SPARSE_OAK, PALM_LIKE_OAK -> placeOakLikeTree(world, ground, type, random);
            case MIXED_OAK_BIRCH -> {
                if (random.nextBoolean()) {
                    placeOakLikeTree(world, ground, IslandStyle.TreeProfile.TreeType.OAK, random);
                } else {
                    placeBirchTree(world, ground, random);
                }
            }
            case SPARSE_SPRUCE -> placeSpruceTree(world, ground, random);
        }
    }

    private static void placeOakLikeTree(class_3218 world,
                                         class_2338 ground,
                                         IslandStyle.TreeProfile.TreeType type,
                                         Random random) {

        switch (type) {
            case OAK -> {
                placeSimpleBlobTree(world, ground, random,
                        OAK_LOG, OAK_LEAVES,
                        4, 6,
                        2
                );
            }
            case SPARSE_OAK -> {
                placeSimpleBlobTree(world, ground, random,
                        OAK_LOG, OAK_LEAVES,
                        3, 4,
                        1
                );
            }
            case PALM_LIKE_OAK -> {
                int trunkHeight = 5 + random.nextInt(3); // 5–7

                for (int i = 1; i <= trunkHeight; i++) {
                    class_2338 pos = ground.method_10086(i);
                    if (!world.method_8320(pos).method_26215()) return;
                    world.method_8652(pos, OAK_LOG, class_2248.field_31028);
                }

                class_2338 top = ground.method_10086(trunkHeight);

                for (int dx = -2; dx <= 2; dx++) {
                    for (int dz = -2; dz <= 2; dz++) {
                        if (Math.abs(dx) + Math.abs(dz) > 3) continue;
                        class_2338 lp = top.method_10069(dx, 0, dz);
                        if (!world.method_8320(lp).method_26215()) continue;
                        if (random.nextFloat() < 0.9f) {
                            world.method_8652(lp, OAK_LEAVES, class_2248.field_31028);
                        }
                    }
                }

                if (world.method_8320(top.method_10084()).method_26215()) {
                    world.method_8652(top.method_10084(), OAK_LEAVES, class_2248.field_31028);
                }
            }
            default -> {
                placeSimpleBlobTree(world, ground, random,
                        OAK_LOG, OAK_LEAVES,
                        4, 5,
                        2
                );
            }
        }
    }

    private static void placeBirchTree(class_3218 world,
                                       class_2338 ground,
                                       Random random) {
        placeSimpleBlobTree(world, ground, random,
                BIRCH_LOG, BIRCH_LEAVES,
                5, 7,
                2
        );
    }

    private static void placeSpruceTree(class_3218 world,
                                        class_2338 ground,
                                        Random random) {

        int trunkHeight = 5 + random.nextInt(3);

        for (int i = 1; i <= trunkHeight; i++) {
            class_2338 pos = ground.method_10086(i);
            if (!world.method_8320(pos).method_26215()) return;
            world.method_8652(pos, SPRUCE_LOG, class_2248.field_31028);
        }

        class_2338 top = ground.method_10086(trunkHeight);

        int maxRadius = 2;
        for (int dy = -2; dy <= 1; dy++) {
            int yLevel = top.method_10264() + dy;
            int radius = maxRadius - Math.max(0, dy + 1);

            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (Math.abs(dx) + Math.abs(dz) > radius + 1) continue;

                    class_2338 lp = new class_2338(top.method_10263() + dx, yLevel, top.method_10260() + dz);
                    if (!world.method_8320(lp).method_26215()) continue;

                    if (random.nextFloat() < 0.9f) {
                        world.method_8652(lp, SPRUCE_LEAVES, class_2248.field_31028);
                    }
                }
            }
        }

        class_2338 tip = top.method_10084();
        if (world.method_8320(tip).method_26215()) {
            world.method_8652(tip, SPRUCE_LEAVES, class_2248.field_31028);
        }
    }

    private static void placeSimpleBlobTree(class_3218 world,
                                            class_2338 ground,
                                            Random random,
                                            class_2680 logState,
                                            class_2680 leafState,
                                            int minHeight,
                                            int maxHeight,
                                            int leafRadius) {

        int trunkHeight = minHeight + random.nextInt(maxHeight - minHeight + 1);

        for (int i = 1; i <= trunkHeight; i++) {
            class_2338 pos = ground.method_10086(i);
            if (!world.method_8320(pos).method_26215()) {
                return;
            }
            world.method_8652(pos, logState, class_2248.field_31028);
        }

        class_2338 top = ground.method_10086(trunkHeight);

        for (int dx = -leafRadius; dx <= leafRadius; dx++) {
            for (int dz = -leafRadius; dz <= leafRadius; dz++) {
                for (int dy = -1; dy <= 2; dy++) {
                    double dist = Math.sqrt(dx * dx + dz * dz + dy * dy * 0.5);
                    if (dist > leafRadius + 0.5) continue;

                    class_2338 lp = top.method_10069(dx, dy, dz);
                    if (!world.method_8320(lp).method_26215()) continue;

                    if (random.nextFloat() < 0.85f) {
                        world.method_8652(lp, leafState, class_2248.field_31028);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------
    // 5. Flora mit Biome-Overrides
    // ------------------------------------------------------

    private static void decorateFlora(class_3218 world,
                                      IslandHeightmap heightmap,
                                      int radiusBlocks,
                                      int seaLevel,
                                      IslandStyle.FloraProfile flora,
                                      Random random) {

        float total = flora.total();
        float grassThreshold = flora.grassChance() / total;
        float flowerThreshold = grassThreshold + flora.flowerChance() / total;
        float bushThreshold = flowerThreshold + flora.bushChance() / total;

        for (int x = -radiusBlocks; x <= radiusBlocks; x++) {
            for (int z = -radiusBlocks; z <= radiusBlocks; z++) {

                double dist = Math.sqrt(x * x + z * z);
                if (dist > radiusBlocks) continue;

                int h = heightmap.sampleHeight(x, z);
                if (h < 0) continue;
                if (h <= seaLevel + 1) continue;

                class_2338 ground = new class_2338(x, h, z);
                class_2680 groundState = world.method_8320(ground);
                if (!groundState.method_27852(class_2246.field_10219)
                        && !groundState.method_27852(class_2246.field_10566)
                        && !groundState.method_27852(class_2246.field_10253)
                        && !groundState.method_27852(class_2246.field_10520)) {
                    continue;
                }

                class_2338 above = ground.method_10084();
                if (!world.method_8320(above).method_26215()) continue;

                IslandHeightmap.BiomeType biome = heightmap.pickBiome(x, z);
                float r = random.nextFloat();

                // Biome-spezifische Flora
                switch (biome) {
                    case JUNGLE -> {
                        if (r < 0.6f) {
                            world.method_8652(above, TALL_GRASS, class_2248.field_31028);
                        } else if (r < 0.85f) {
                            placeLeafBush(world, above, random);
                        }
                        continue;
                    }
                    case SAVANNA -> {
                        if (r < 0.3f) {
                            world.method_8652(above, TALL_GRASS, class_2248.field_31028);
                        }
                        continue;
                    }
                    case TAIGA -> {
                        if (r < 0.1f) {
                            world.method_8652(above, FERN, class_2248.field_31028);
                        }
                        continue;
                    }
                    case FROSTLAND -> {
                        // keine Flora
                        continue;
                    }
                    case MEADOW -> {
                        // fällt auf Style-Profil zurück (unten)
                    }
                }

                // Style-basierte Standard-Flora
                if (r < grassThreshold) {
                    class_2680 plant = random.nextBoolean() ? TALL_GRASS : FERN;
                    world.method_8652(above, plant, class_2248.field_31028);
                } else if (r < flowerThreshold) {
                    class_2680 flower = pickRandomFlower(random);
                    world.method_8652(above, flower, class_2248.field_31028);
                } else if (r < bushThreshold) {
                    placeLeafBush(world, above, random);
                }
            }
        }
    }

    private static class_2680 pickRandomFlower(Random random) {
        return switch (random.nextInt(5)) {
            case 0 -> FLOWER_1;
            case 1 -> FLOWER_2;
            case 2 -> FLOWER_3;
            case 3 -> class_2246.field_10573.method_9564();
            default -> class_2246.field_10554.method_9564();
        };
    }

    private static void placeLeafBush(class_3218 world, class_2338 center, Random random) {
        class_2680 leaves = OAK_LEAVES;
        world.method_8652(center, leaves, class_2248.field_31028);

        if (random.nextBoolean()) world.method_8652(center.method_10095(), leaves, class_2248.field_31028);
        if (random.nextBoolean()) world.method_8652(center.method_10072(), leaves, class_2248.field_31028);
        if (random.nextBoolean()) world.method_8652(center.method_10078(), leaves, class_2248.field_31028);
        if (random.nextBoolean()) world.method_8652(center.method_10067(), leaves, class_2248.field_31028);

        if (random.nextFloat() < 0.3f) {
            world.method_8652(center.method_10084(), leaves, class_2248.field_31028);
        }
    }
}
