package dev.huntertagog.coresystem.fabric.common.friends.gui;

import dev.huntertagog.coresystem.common.friends.gui.FriendSettingsStore;
import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import dev.huntertagog.coresystem.platform.friends.FriendService;
import dev.huntertagog.coresystem.platform.player.PlayerProfile;
import dev.huntertagog.coresystem.platform.player.PlayerProfileService;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class FriendGuiServerNet {

    private FriendGuiServerNet() {
    }

    public static void register() {

        ServerPlayNetworking.registerGlobalReceiver(FriendGuiPackets.C2SOpen.ID, (payload, context) -> {
            context.server().execute(() -> sendSnapshot(context.server(), context.player()));
        });

        ServerPlayNetworking.registerGlobalReceiver(FriendGuiPackets.C2SAccept.ID, (payload, context) -> {
            UUID from = payload.from();
            context.server().execute(() -> {
                FriendService fs = ServiceProvider.getService(FriendService.class);
                if (fs != null) fs.acceptRequest(context.player().method_5667(), from);
                sendSnapshot(context.server(), context.player());
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(FriendGuiPackets.C2SDeny.ID, (payload, context) -> {
            UUID from = payload.from();
            context.server().execute(() -> {
                FriendService fs = ServiceProvider.getService(FriendService.class);
                if (fs != null) fs.denyRequest(context.player().method_5667(), from);
                sendSnapshot(context.server(), context.player());
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(FriendGuiPackets.C2SRemove.ID, (payload, context) -> {
            UUID other = payload.other();
            context.server().execute(() -> {
                FriendService fs = ServiceProvider.getService(FriendService.class);
                if (fs != null) fs.removeFriend(context.player().method_5667(), other);
                sendSnapshot(context.server(), context.player());
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(FriendGuiPackets.C2SCancel.ID, (payload, context) -> {
            UUID target = payload.target();
            context.server().execute(() -> {
                FriendService fs = ServiceProvider.getService(FriendService.class);
                // cancel outgoing -> simplest: denyRequest(target, me)
                if (fs != null) fs.denyRequest(target, context.player().method_5667());
                sendSnapshot(context.server(), context.player());
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(FriendGuiPackets.C2SSetSettings.ID, (payload, context) -> {
            boolean allowRequests = payload.allowRequests();
            boolean allowFollow = payload.allowFollow();
            boolean showLastSeen = payload.showLastSeen();

            context.server().execute(() -> {
                FriendSettingsStore.set(context.player().method_5667(), allowRequests, allowFollow, showLastSeen);
                sendSnapshot(context.server(), context.player());
            });
        });
    }

    private static void sendSnapshot(MinecraftServer server, class_3222 player) {
        FriendService fs = ServiceProvider.getService(FriendService.class);
        if (fs == null) return;

        PlayerProfileService profiles = ServiceProvider.getService(PlayerProfileService.class);

        var settings = FriendSettingsStore.get(player.method_5667());

        // Freunde
        List<UUID> friends = fs.getFriends(player.method_5667());
        List<FriendGuiSnapshot.FriendEntry> friendEntries = new ArrayList<>(friends.size());

        for (UUID id : friends) {
            String name = resolveName(server, id, profiles);
            boolean online = server.method_3760().method_14602(id) != null;

            long lastSeen = 0L;
            if (profiles != null) {
                PlayerProfile p = profiles.find(id).orElse(null);
                if (p != null) lastSeen = p.getLastSeenAt();
            }

            friendEntries.add(new FriendGuiSnapshot.FriendEntry(id, name, online, lastSeen));
        }

        // incoming/outgoing
        List<FriendGuiSnapshot.RequestEntry> incoming = new ArrayList<>();
        for (UUID id : fs.getIncomingRequests(player.method_5667())) {
            incoming.add(new FriendGuiSnapshot.RequestEntry(id, resolveName(server, id, profiles)));
        }

        List<FriendGuiSnapshot.RequestEntry> outgoing = new ArrayList<>();
        for (UUID id : fs.getOutgoingRequests(player.method_5667())) {
            outgoing.add(new FriendGuiSnapshot.RequestEntry(id, resolveName(server, id, profiles)));
        }

        FriendGuiSnapshot snap = new FriendGuiSnapshot(
                friendEntries,
                incoming,
                outgoing,
                new FriendGuiSnapshot.FriendSettings(settings.allowRequests(), settings.allowFollow(), settings.showLastSeen())
        );

        // S2C als Payload senden
        ServerPlayNetworking.send(player, new FriendGuiPackets.S2CSnapshot(snap));
    }

    private static String resolveName(MinecraftServer server, UUID id, PlayerProfileService profiles) {
        var online = server.method_3760().method_14602(id);
        if (online != null) return online.method_7334().getName();

        if (profiles != null) {
            PlayerProfile p = profiles.find(id).orElse(null);
            if (p != null && p.getName() != null && !p.getName().isBlank()) return p.getName();
        }
        return id.toString().substring(0, 8);
    }

    public static void openFor(MinecraftServer server, class_3222 player) {
        server.execute(() -> sendSnapshot(server, player));
    }
}
