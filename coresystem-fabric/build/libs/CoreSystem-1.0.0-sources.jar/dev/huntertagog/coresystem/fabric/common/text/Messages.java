package dev.huntertagog.coresystem.fabric.common.text;

import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.common.text.CoreMessage;
import java.util.function.Supplier;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public final class Messages {

    private static final class_2561 PREFIX = class_2561.method_43470("[Cobblecrew] ")
            .method_27692(class_124.field_1063);

    private Messages() {
    }

    // ------------------------------------------------------------------
    // Text-Erzeugung
    // ------------------------------------------------------------------

    public static class_2561 t(CoreMessage msg, Object... args) {
        return class_2561.method_43469(msg.key(), args);
    }

    public static class_2561 tp(CoreMessage msg, Object... args) {
        return PREFIX.method_27661().method_10852(t(msg, args));
    }

    // ------------------------------------------------------------------
    // Senden an CommandSource
    // ------------------------------------------------------------------

    public static void send(class_2168 source, CoreMessage msg, Object... args) {
        send(source, false, msg, args);
    }

    public static void send(class_2168 source,
                            boolean broadcastToOps,
                            CoreMessage msg,
                            Object... args) {

        Supplier<class_2561> supplier = () -> tp(msg, args);

        try {
            source.method_9226(supplier, broadcastToOps);
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.MESSAGE_ERROR,
                            CoreErrorSeverity.ERROR,
                            "Failed to send CoreMessage to ServerCommandSource"
                    )
                    .withCause(e)
                    .withContextEntry("msgKey", msg.key())
                    .withContextEntry("broadcastToOps", broadcastToOps)
                    .log();
        }
    }

    // ------------------------------------------------------------------
    // Direkt an Spieler
    // ------------------------------------------------------------------

    public static void send(class_3222 player, CoreMessage msg, Object... args) {
        try {
            player.method_43496(tp(msg, args));
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.MESSAGE_ERROR,
                            CoreErrorSeverity.ERROR,
                            "Failed to send CoreMessage to player"
                    )
                    .withCause(e)
                    .withContextEntry("msgKey", msg.key())
                    .withContextEntry("playerUuid", player.method_5667().toString())
                    .withContextEntry("playerName", player.method_7334().getName())
                    .log();
        }
    }

    public static void sendRaw(class_3222 player, CoreMessage msg, Object... args) {
        try {
            player.method_43496(t(msg, args));
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.MESSAGE_ERROR,
                            CoreErrorSeverity.ERROR,
                            "Failed to send raw CoreMessage to player"
                    )
                    .withCause(e)
                    .withContextEntry("msgKey", msg.key())
                    .withContextEntry("playerUuid", player.method_5667().toString())
                    .withContextEntry("playerName", player.method_7334().getName())
                    .log();
        }
    }

    public static class_2561 literal(String txt) {
        return class_2561.method_43470(txt);
    }

}
