package dev.huntertagog.coresystem.fabric.common.net.payload;

import dev.huntertagog.coresystem.fabric.server.bridge.BridgeChannel;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record BridgePayload(byte[] bytes) implements class_8710 {

    public static final class_9154<BridgePayload> ID =
            new class_9154<>(BridgeChannel.ID);

    public static final class_9139<class_9129, BridgePayload> CODEC =
            class_9139.method_56438(
                    // ✅ ENCODER: (value, buf)
                    (BridgePayload payload, class_9129 buf) -> {
                        byte[] data = payload.bytes();
                        buf.method_10804(data.length);
                        buf.method_52983(data);
                    },
                    // ✅ DECODER: (buf) -> value
                    (class_9129 buf) -> {
                        int len = buf.method_10816();
                        byte[] data = new byte[len];
                        buf.method_52979(data);
                        return new BridgePayload(data);
                    }
            );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
