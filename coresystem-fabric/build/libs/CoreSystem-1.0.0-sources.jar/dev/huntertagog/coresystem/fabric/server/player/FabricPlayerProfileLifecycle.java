package dev.huntertagog.coresystem.fabric.server.player;

import dev.huntertagog.coresystem.platform.player.PlayerProfileService;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_3222;

public final class FabricPlayerProfileLifecycle {

    private static PlayerProfileService profiles = null;
    private static String serverName = "";
    private static String nodeId = "";

    public FabricPlayerProfileLifecycle(PlayerProfileService profiles, String serverName) {
        FabricPlayerProfileLifecycle.profiles = profiles;
        FabricPlayerProfileLifecycle.serverName = serverName;
        nodeId = System.getenv("SERVER_ID");
    }

    public static void register() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 p = handler.field_14140;
            profiles.updateOnJoin(
                    p.method_5667(),
                    p.method_7334().getName(),
                    serverName,
                    nodeId
            );
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            class_3222 p = handler.field_14140;
            profiles.updateOnQuit(
                    p.method_5667(),
                    serverName,
                    nodeId
            );
        });
    }
}
