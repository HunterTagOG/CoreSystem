package dev.huntertagog.coresystem.fabric.server.region.image;

import dev.huntertagog.coresystem.fabric.common.net.payload.RegionImageRemoveS2CPayload;
import dev.huntertagog.coresystem.fabric.common.net.payload.RegionImageSetS2CPayload;
import dev.huntertagog.coresystem.fabric.common.region.RegionImageDef;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_26;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.Objects;

public final class RegionImageServerService {

    private RegionImageServerService() {
    }

    /**
     * Persistiert den Def in der Welt-PSM und broadcastet an alle Spieler dieser Welt.
     */
    public static void upsertAndBroadcast(class_3218 world, RegionImageDef def) {
        Objects.requireNonNull(world, "world");
        Objects.requireNonNull(def, "def");

        // Safety: nur in der passenden Welt persistieren/broadcasten
        if (!world.method_27983().method_29177().equals(def.worldId())) {
            // optional: throw, oder einfach ignorieren
            return;
        }

        // persist
        RegionImageState st = state(world);
        st.put(toStateEntry(def));
        st.method_80();

        // broadcast
        var payload = RegionImageSetS2CPayload.fromDef(def);
        for (class_3222 p : world.method_18456()) {
            ServerPlayNetworking.send(p, payload);
        }
    }

    /**
     * Entfernt Region-Image in dieser Welt und broadcastet Remove.
     */
    public static void removeAndBroadcast(class_3218 world, String regionId) {
        Objects.requireNonNull(world, "world");
        Objects.requireNonNull(regionId, "regionId");

        RegionImageState st = state(world);
        st.remove(regionId);
        st.method_80();

        var payload = new RegionImageRemoveS2CPayload(regionId, world.method_27983().method_29177());
        for (class_3222 p : world.method_18456()) {
            ServerPlayNetworking.send(p, payload);
        }
    }

    /**
     * Helper: Common-Def -> PersistentState Entry
     * (Damit bleibt State unabhängig vom Netzwerk-Payload.)
     */
    private static RegionImageDef toStateEntry(RegionImageDef def) {
        return new RegionImageDef(
                def.regionId(),
                def.worldId(),
                def.bounds(),
                def.mode(),
                def.facing(),
                def.baseY(),      // oder imageKey() je nach Naming in deinem Def
                def.textureId()
        );
    }

    public static RegionImageState state(class_3218 world) {
        class_26 psm = world.method_17983();
        return psm.method_17924(RegionImageState.TYPE, RegionImageState.KEY);
    }


    public static void syncToPlayer(class_3218 world, class_3222 player) {
        Objects.requireNonNull(world, "world");
        Objects.requireNonNull(player, "player");

        RegionImageState st = state(world);

        for (RegionImageDef e : st.all()) {
            // Safety: nur gleiche Dimension
            if (!world.method_27983().method_29177().equals(e.worldId())) continue;

            RegionImageDef def = toStateEntry(e); // -> Helper unten
            ServerPlayNetworking.send(player, RegionImageSetS2CPayload.fromDef(def));
        }
    }
}
