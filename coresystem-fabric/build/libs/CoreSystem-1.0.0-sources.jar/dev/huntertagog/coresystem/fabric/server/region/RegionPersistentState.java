package dev.huntertagog.coresystem.fabric.server.region;

import dev.huntertagog.coresystem.common.region.RegionDefinitionDto;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_3218;
import net.minecraft.class_7225;

public final class RegionPersistentState extends class_18 {

    public static final String KEY = "coresystem_regions_v1";

    /**
     * WICHTIG: neuer Type für getOrCreate
     */
    public static final class_8645<RegionPersistentState> TYPE =
            new class_8645<>(
                    RegionPersistentState::new,
                    RegionPersistentState::fromNbt,
                    null
            );

    private final Map<String, RegionDefinitionDto> regionsById = new HashMap<>();

    public Collection<RegionDefinitionDto> all() {
        return regionsById.values();
    }

    public RegionDefinitionDto get(String id) {
        return regionsById.get(id);
    }

    public void put(RegionDefinitionDto dto) {
        if (dto == null || dto.id() == null || dto.id().isBlank()) return;
        regionsById.put(dto.id(), dto);
        method_80();
    }

    public void remove(String id) {
        if (id == null || id.isBlank()) return;
        if (regionsById.remove(id) != null) {
            method_80();
        }
    }

    public static RegionPersistentState get(class_3218 world) {
        return world.method_17983().method_17924(TYPE, KEY);
    }

    // ------------------------------------------------------------
    // NBT
    // ------------------------------------------------------------

    private static RegionPersistentState fromNbt(
            class_2487 nbt,
            class_7225.class_7874 lookup
    ) {
        RegionPersistentState state = new RegionPersistentState();

        if (nbt.method_10573("regions", class_2520.field_33259)) {
            class_2499 list = nbt.method_10554("regions", class_2520.field_33260);
            for (int i = 0; i < list.size(); i++) {
                class_2487 r = list.method_10602(i);
                RegionDefinitionDto dto = RegionNbtCodec.readDto(r);
                if (dto != null && dto.id() != null && !dto.id().isBlank()) {
                    state.regionsById.put(dto.id(), dto);
                }
            }
        }

        return state;
    }

    @Override
    public class_2487 method_75(
            class_2487 nbt,
            class_7225.class_7874 lookup
    ) {
        class_2499 list = new class_2499();
        for (RegionDefinitionDto dto : regionsById.values()) {
            class_2487 r = RegionNbtCodec.writeDto(dto);
            if (r != null) list.add(r);
        }
        nbt.method_10566("regions", list);
        return nbt;
    }
}
