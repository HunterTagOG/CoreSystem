package dev.huntertagog.coresystem.fabric.common.rct;

import com.gitlab.srcmc.rctapi.api.RCTApi;
import com.gitlab.srcmc.rctapi.api.trainer.TrainerNPC;
import dev.huntertagog.coresystem.common.rct.RctRegionSpawnStore;
import dev.huntertagog.coresystem.fabric.CoresystemCommon;
import net.minecraft.class_1299;
import net.minecraft.class_1646;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3218;

public final class RegionTrainerSpawner {

    private static final String MOD_ID = CoresystemCommon.MOD_ID;

    private RegionTrainerSpawner() {
    }

    /**
     * Spawn exactly once globally for (worldId, regionId).
     */
    public static void ensureSpawned(class_3218 world,
                                     String regionId,
                                     String trainerId,
                                     class_2338 spawnPos) {

        class_2960 wid = world.method_27983().method_29177();
        String worldId = wid.toString();

        if (RctRegionSpawnStore.isSpawned(worldId, regionId)) {
            return;
        }

        // Spawn entity (example: villager)
        class_1646 villager = class_1299.field_6077.method_5883(world);
        if (villager == null) return;

        villager.method_5808(
                spawnPos.method_10263() + 0.5,
                spawnPos.method_10264(),
                spawnPos.method_10260() + 0.5,
                0f,
                0f
        );
        villager.method_5971();
        villager.method_5880(true);

        // (Optional) name from your trainer model or config:
        villager.method_5665(net.minecraft.class_2561.method_43470(trainerId));

        world.method_8649(villager);

        // Attach RCT trainer to this entity
        RCTApi api = RCTApi.getInstance(MOD_ID);
        TrainerNPC trainer = api.getTrainerRegistry().getById(trainerId, TrainerNPC.class);
        if (trainer != null) {
            trainer.setEntity(villager); // important
        }

        RctRegionSpawnStore.markSpawned(worldId, regionId);
    }
}
