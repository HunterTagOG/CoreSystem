package dev.huntertagog.coresystem.fabric.server.region.visual;

import dev.huntertagog.coresystem.common.log.Logger;
import dev.huntertagog.coresystem.common.log.LoggerFactory;
import dev.huntertagog.coresystem.fabric.common.region.visual.RegionOutlineService;
import dev.huntertagog.coresystem.fabric.server.region.RegionDefinition;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class NetworkRegionOutlineService implements RegionOutlineService {

    private static final Logger LOG = LoggerFactory.get("RegionOutline");

    // halbtransparentes hellgrün (ARGB)
    private static final int DEFAULT_COLOR = 0x80_00FF00;

    public NetworkRegionOutlineService() {
        LOG.info("NetworkRegionOutlineService initialized (client-side region outlines).");
    }

    @Override
    public void showSelection(class_3222 player,
                              class_2960 worldId,
                              class_2338 min,
                              class_2338 max,
                              int ticks) {
        RegionOutlinePackets.sendOutline(player, worldId, min, max, DEFAULT_COLOR, ticks);
    }

    @Override
    public void showRegion(class_3222 player,
                           RegionDefinition region,
                           int ticks) {
        class_2338 min = new class_2338(region.minX(), region.minY(), region.minZ());
        class_2338 max = new class_2338(region.maxX(), region.maxY(), region.maxZ());
        RegionOutlinePackets.sendOutline(player, region.worldId(), min, max, DEFAULT_COLOR, ticks);
    }

    @Override
    public void tick(class_3218 world) {
        // bei Netzwerk-Variante keine Server-Logik notwendig
    }
}
