package dev.huntertagog.coresystem.fabric.common.chat;

import dev.huntertagog.coresystem.common.permission.CorePermission;
import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import dev.huntertagog.coresystem.fabric.common.permission.PermissionService;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Nullable;

public final class DefaultNamePrefixResolver implements NamePrefixResolver {

    private final PermissionService perms;

    public DefaultNamePrefixResolver() {
        this.perms = ServiceProvider.getService(PermissionService.class);
    }

    @Override
    public @Nullable class_2561 resolvePrefix(class_3222 player) {
        if (perms == null) {
            return null;
        }

        // Beispiel-Logik – justierbar:
        if (perms.has(player.method_5671(), CorePermission.STAFF_ADMIN)) {
            return class_2561.method_43470("[Admin] ").method_27695(class_124.field_1061, class_124.field_1067);
        }
        if (perms.has(player.method_5671(), CorePermission.STAFF_MOD)) {
            return class_2561.method_43470("[Mod] ").method_27695(class_124.field_1078, class_124.field_1067);
        }
        if (perms.has(player.method_5671(), CorePermission.VIP)) {
            return class_2561.method_43470("[VIP] ").method_27692(class_124.field_1065);
        }

        return null; // kein Prefix
    }
}
