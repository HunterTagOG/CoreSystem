package dev.huntertagog.coresystem.fabric.common.backpack;

import dev.huntertagog.coresystem.common.log.Logger;
import dev.huntertagog.coresystem.common.log.LoggerFactory;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_3222;
import net.p3pp3rf1y.sophisticatedbackpacks.backpack.BackpackStorage;

import java.util.List;
import java.util.UUID;

public final class SbBackpacksSync {

    private static final Logger LOG = LoggerFactory.get("SbBackpacksSync");
    private static final String NBT_KEY = "sbBackpacks";

    private SbBackpacksSync() {
    }

    /**
     * Ergänzt den Spieler-Snapshot um alle Sophisticated-Backpacks,
     * die der Spieler aktuell trägt (Main/Armor/Offhand).
     */
    public static void enrichSnapshot(class_3222 player, class_2487 root) {
        List<UUID> ids = SbBackpackUtil.getCarriedBackpackUUIDs(player);
        if (ids.isEmpty()) {
            return;
        }

        class_2499 list = new class_2499();
        for (UUID id : ids) {
            try {
                // holt die Inhalte dieses Backpacks
                class_2487 contents = BackpackStorage.get().getOrCreateBackpackContents(id);

                class_2487 entry = new class_2487();
                entry.method_25927("id", id);
                // Kopie, damit wir keine Shared-Referenz im Snapshot halten
                entry.method_10566("data", contents.method_10553());

                list.add(entry);
            } catch (Exception e) {
                LOG.warn("Failed to snapshot SophisticatedBackpack contents for {}: {}", id, e.toString());
            }
        }

        if (!list.isEmpty()) {
            root.method_10566(NBT_KEY, list);
            LOG.debug("Snapshot for {}: stored {} Sophisticated Backpack(s)", player.method_7334().getName(), list.size());
        }
    }

    /**
     * Stellt die Inhalte der Sophisticated-Backpacks aus dem Snapshot wieder her.
     * Wird auf dem Zielserver nach dem normalen Inventory/Enderchest-Restore aufgerufen.
     */
    public static void restoreFromSnapshot(class_3222 player, class_2487 root) {
        if (!root.method_10573(NBT_KEY, class_2520.field_33259)) {
            return;
        }

        class_2499 list = root.method_10554(NBT_KEY, class_2520.field_33260);
        if (list.isEmpty()) {
            return;
        }

        for (int i = 0; i < list.size(); i++) {
            class_2487 entry = list.method_10602(i);
            try {
                UUID id = entry.method_25926("id");
                class_2487 data = entry.method_10562("data");

                class_2487 target = BackpackStorage.get().getOrCreateBackpackContents(id);
                // überschreiben mit dem Snapshot
                target.method_10543(data);
            } catch (Exception e) {
                LOG.warn("Failed to restore SophisticatedBackpack entry {} for {}: {}",
                        i, player.method_7334().getName(), e.toString());
            }
        }

        LOG.debug("Restored {} Sophisticated Backpack(s) for {}",
                list.size(), player.method_7334().getName());
    }
}
