package dev.huntertagog.coresystem.fabric.common.message;

import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.common.log.Logger;
import dev.huntertagog.coresystem.common.log.LoggerFactory;
import dev.huntertagog.coresystem.platform.message.PlatformText;
import dev.huntertagog.coresystem.platform.message.PlayerMessageService;
import dev.huntertagog.coresystem.platform.message.PlayerNotification;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_5905;
import net.minecraft.server.MinecraftServer;
import java.util.UUID;

public final class FabricPlayerMessageService implements PlayerMessageService {

    private static final Logger LOG = LoggerFactory.get("PlayerMessageService");

    private final MinecraftServer server;

    public FabricPlayerMessageService(MinecraftServer server) {
        this.server = server;
    }

    @Override
    public void send(UUID playerId, PlayerNotification notification) {
        class_3222 player = server.method_3760().method_14602(playerId);
        if (player == null) return;

        try {
            switch (notification.channel()) {
                case CHAT -> sendChatInternal(player, notification);
                case ACTION_BAR -> sendActionBarInternal(player, notification);
                case TITLE -> sendTitleInternal(player, notification);
                case SUBTITLE -> sendSubtitleInternal(player, notification);
                case SYSTEM -> sendSystemInternal(player, notification);
                case TOAST -> sendToastInternal(player, notification);
            }
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.PLAYER_MESSAGE_SEND_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to send player notification"
                    )
                    .withCause(e)
                    .withContextEntry("playerUuid", player.method_5845())
                    .withContextEntry("channel", notification.channel().name())
                    .withContextEntry("severity", notification.severity().name())
                    .withContextEntry("message", toText(notification.message()).getString())
                    .log();

            LOG.warn("Failed to send notification '{}' to player {} ({})",
                    toText(notification.message()).getString(),
                    player.method_7334().getName(),
                    player.method_5845());
        }
    }

    // ---------------- Chat ----------------

    private void sendChatInternal(class_3222 player, PlayerNotification n) {
        player.method_7353(applySeverityFormatting(n), false);
    }

    // ---------------- ActionBar ----------------

    private void sendActionBarInternal(class_3222 player, PlayerNotification n) {
        player.method_7353(applySeverityFormatting(n), true);
    }

    // ---------------- Title / Subtitle ----------------

    private void sendTitleInternal(class_3222 player, PlayerNotification n) {
        class_2561 title = applySeverityFormatting(n);

        var timings = n.titleTimings().orElse(null);
        if (timings != null) {
            player.field_13987.method_14364(new class_5905(
                    timings.fadeInTicks(),
                    timings.stayTicks(),
                    timings.fadeOutTicks()
            ));
        }

        player.field_13987.method_14364(new class_5904(title));

        // optional: subtitle im selben Notification-Objekt
        if (n.subtitle().isPresent()) {
            player.field_13987.method_14364(new class_5903(toText(n.subtitle().get())));
        }
    }

    private void sendSubtitleInternal(class_3222 player, PlayerNotification n) {
        class_2561 subtitle = applySeverityFormatting(n);
        player.field_13987.method_14364(new class_5903(subtitle));
    }

    // ---------------- System ----------------

    private void sendSystemInternal(class_3222 player, PlayerNotification n) {
        player.method_7353(applySeverityFormatting(n), false);
    }

    // ---------------- Toast (Server-Fallback) ----------------

    private void sendToastInternal(class_3222 player, PlayerNotification n) {
        class_2561 base = toText(n.message());

        class_2561 prefixed = switch (n.severity()) {
            case SUCCESS -> class_2561.method_43470("✔ ").method_27692(class_124.field_1060).method_10852(base);
            case WARNING -> class_2561.method_43470("⚠ ").method_27692(class_124.field_1054).method_10852(base);
            case ERROR -> class_2561.method_43470("✖ ").method_27692(class_124.field_1061).method_10852(base);
            case INFO -> class_2561.method_43470("• ").method_27692(class_124.field_1080).method_10852(base);
        };

        player.method_7353(prefixed, false);
    }

    // ---------------- Styling ----------------

    private class_2561 applySeverityFormatting(PlayerNotification n) {
        class_2561 base = toText(n.message());

        return switch (n.severity()) {
            case SUCCESS -> base.method_27661().method_27692(class_124.field_1060);
            case WARNING -> base.method_27661().method_27692(class_124.field_1054);
            case ERROR -> base.method_27661().method_27692(class_124.field_1061);
            case INFO -> base.method_27661().method_27692(class_124.field_1080);
        };
    }

    private class_2561 toText(PlatformText t) {
        // Minimal-Mapper (ausbaubar: MiniMessage/JSON/i18n)
        if (t == null) return class_2561.method_43473();
        return class_2561.method_43470(t.plain());
    }
}
