package dev.huntertagog.coresystem.fabric.common.rct.rewards;

import dev.huntertagog.coresystem.common.rct.rewards.RedisRctRewardStore;
import dev.huntertagog.coresystem.common.rct.rewards.dto.RctRewardItemDto;
import dev.huntertagog.coresystem.common.rct.rewards.dto.RctRewardSpecDto;
import net.minecraft.class_3222;
import net.minecraft.class_7225;
import net.minecraft.server.MinecraftServer;

public final class RctRewardService {

    private final RedisRctRewardStore store = new RedisRctRewardStore();

    public void grantOnVictory(MinecraftServer server, class_3222 player, String trainerId) {
        class_7225.class_7874 registries = server.method_30611(); // passt zu deinem Setup

        RctRewardSpecDto spec = store.find(trainerId).orElse(RctRewardSpecDto.empty());
        if (spec == null) return;

        // Money (placeholder)
        if (spec.money() > 0) {
            // TODO Economy
        }

        // Items
        if (spec.items() != null) {
            for (RctRewardItemDto dto : spec.items()) {
                var stack = RctRewardItemCodec.fromDto(dto, registries);
                if (!stack.method_7960()) player.method_31548().method_7398(stack);
            }
        }

        // Commands
        if (spec.consoleCommands() != null) {
            var console = server.method_3739();
            for (String cmd : spec.consoleCommands()) {
                if (cmd == null || cmd.isBlank()) continue;
                server.method_3734().method_44252(console, cmd.replace("{player}", player.method_7334().getName()));
            }
        }

        // Permissions (optional)
        if (spec.permissionNodes() != null) {
            // TODO PermissionService grant
        }
    }

    public void seedDefaultsIfMissing() {
        store.seedDefaultsIfMissing();
    }
}
