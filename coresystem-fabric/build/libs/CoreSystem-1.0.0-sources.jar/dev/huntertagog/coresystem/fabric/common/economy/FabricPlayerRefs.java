package dev.huntertagog.coresystem.fabric.common.economy;

import dev.huntertagog.coresystem.platform.player.PlayerRef;
import net.minecraft.class_3222;

public final class FabricPlayerRefs {

    public static PlayerRef of(class_3222 player) {
        return new PlayerRef(player.method_5667());
    }
}
