package dev.huntertagog.coresystem.fabric.server.bridge;

import net.minecraft.class_2960;

public final class BridgeChannel {
    public static final class_2960 ID = class_2960.method_60655("coresystem", "bridge");

    private BridgeChannel() {
    }
}
