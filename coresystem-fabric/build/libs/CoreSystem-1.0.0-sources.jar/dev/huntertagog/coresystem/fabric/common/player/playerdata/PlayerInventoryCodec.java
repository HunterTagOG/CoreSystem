package dev.huntertagog.coresystem.fabric.common.player.playerdata;

import dev.huntertagog.coresystem.fabric.common.backpack.SbBackpacksSync;
import dev.huntertagog.coresystem.fabric.common.sync.EnderChestCodecUtil;
import dev.huntertagog.coresystem.fabric.common.sync.ExtraSlotsSyncUtil;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2505;
import net.minecraft.class_2507;
import net.minecraft.class_2520;
import net.minecraft.class_3222;
import net.minecraft.class_7225;
import net.minecraft.nbt.*;
import net.minecraft.server.MinecraftServer;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.zip.GZIPInputStream;

public final class PlayerInventoryCodec {

    private PlayerInventoryCodec() {
    }

    /**
     * Snapshot der Spieler-Inventar-Daten (ohne Position, ohne Health usw.).
     * - Main Inventory
     * - Armor
     * - Offhand
     * - Enderchest
     * - Extra-Slots (Travellers Backpack in Trinkets / Curios etc.)
     * - Sophisticated Backpacks
     */
    public static String encodeInventoryToBase64(MinecraftServer server, class_3222 player) throws IOException {
        class_2487 root = new class_2487();

        // Registry-Lookup für Enderchest / ItemStacks
        class_7225.class_7874 registries = server.method_30611();

        // 1) Vanilla Inventory
        class_2499 invList = new class_2499();
        player.method_31548().method_7384(invList);
        root.method_10566("inventory", invList);

        // 2) Enderchest
        root.method_10566(
                "enderChest",
                EnderChestCodecUtil.serializeEnderChest(player.method_7274(), registries)
        );

        // 3) Extra-Slots (Travellers Backpack in Trinkets / Curios etc.)
        ExtraSlotsSyncUtil.encodeExtraSlots(player, root);

        // 4) Sophisticated Backpacks
        SbBackpacksSync.enrichSnapshot(player, root);

        // 5) NBT -> gzip + Base64
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        class_2507.method_10634(root, baos);
        return Base64.getEncoder().encodeToString(baos.toByteArray());
    }

    public static void applyInventoryFromBase64(MinecraftServer server,
                                                class_3222 player,
                                                String base64Payload) throws IOException {
        if (base64Payload == null || base64Payload.isEmpty()) {
            return;
        }

        byte[] bytes = Base64.getDecoder().decode(base64Payload);

        // Registry-Lookup für Enderchest / ItemStacks
        class_7225.class_7874 registries = server.method_30611();

        class_2487 root;

        try (ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
             GZIPInputStream gis = new GZIPInputStream(bais);
             DataInputStream dis = new DataInputStream(gis)) {

            // In deinen Mappings: NbtIo.read(...) -> NbtElement
            class_2520 element = class_2507.method_52894(dis, class_2505.method_53898());
            if (!(element instanceof class_2487 compound)) {
                // sehr defensive Guard: falls jemand kein Compound gespeichert hat
                return;
            }
            root = compound;
        }

        // -------------------------------
        // Ab hier: dein bestehender Code
        // -------------------------------

        // 1) Vanilla Inventory
        if (root.method_10573("inventory", class_2520.field_33259)) {
            class_2499 invList = root.method_10554("inventory", class_2520.field_33260);
            player.method_31548().method_5448();
            player.method_31548().method_7397(invList);
            player.field_7498.method_7623();
        }

        // 2) Enderchest
        if (root.method_10573("enderChest", class_2520.field_33259)) {
            class_2499 ecList = root.method_10554("enderChest", class_2520.field_33260);
            EnderChestCodecUtil.deserializeEnderChest(
                    player.method_7274(),
                    ecList,
                    registries
            );
        }

        // 3) Extra-Slots (Travellers Backpack, Trinkets etc.)
        ExtraSlotsSyncUtil.applyExtraSlots(player, root);

        // 4) Sophisticated Backpacks wiederherstellen
        SbBackpacksSync.restoreFromSnapshot(player, root);
    }
}
