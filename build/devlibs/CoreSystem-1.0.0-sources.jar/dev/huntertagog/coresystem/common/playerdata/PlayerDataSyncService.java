package dev.huntertagog.coresystem.common.playerdata;

import dev.huntertagog.coresystem.common.provider.Service;
import net.minecraft.server.network.ServerPlayerEntity;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.UUID;

public interface PlayerDataSyncService extends Service {

    /**
     * Inventar-Snapshot für den gegebenen Kontext speichern.
     */
    void saveInventorySnapshot(@NotNull ServerPlayerEntity player,
                               @NotNull String context,
                               @Nullable String reason);

    /**
     * Snapshot laden (ohne direkt auf den Spieler anzuwenden).
     */
    @NotNull Optional<PlayerInventorySnapshot> findInventorySnapshot(@NotNull UUID uuid,
                                                                     @NotNull String context);

    /**
     * Snapshot auf den Spieler anwenden.
     *
     * @param clearAfter true → Snapshot nach erfolgreicher Anwendung löschen
     * @return true, wenn ein Snapshot gefunden und angewendet wurde
     */
    boolean applyInventorySnapshot(@NotNull ServerPlayerEntity player,
                                   @NotNull String context,
                                   boolean clearAfter);

    /**
     * Snapshot explizit löschen.
     */
    void deleteInventorySnapshot(@NotNull UUID uuid, @NotNull String context);
}
