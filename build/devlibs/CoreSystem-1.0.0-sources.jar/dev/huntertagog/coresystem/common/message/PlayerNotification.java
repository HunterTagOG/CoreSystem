package dev.huntertagog.coresystem.common.message;

import net.minecraft.text.Text;
import org.jetbrains.annotations.Nullable;

/**
 * @param message  bereits formatierter Klartext
 * @param debugKey optional: Key wie "player.welcome.firstJoin"
 */
public record PlayerNotification(MessageChannel channel, MessageSeverity severity, Text message,
                                 @Nullable Text debugKey) {

    // --- Chat-Shortcuts ---
    public static PlayerNotification chatInfo(Text message) {
        return new PlayerNotification(MessageChannel.CHAT, MessageSeverity.INFO, message, null);
    }

    public static PlayerNotification chatSuccess(Text message) {
        return new PlayerNotification(MessageChannel.CHAT, MessageSeverity.SUCCESS, message, null);
    }

    public static PlayerNotification chatWarn(Text message) {
        return new PlayerNotification(MessageChannel.CHAT, MessageSeverity.WARNING, message, null);
    }

    public static PlayerNotification chatError(Text message) {
        return new PlayerNotification(MessageChannel.CHAT, MessageSeverity.ERROR, message, null);
    }

    // --- ActionBar-Shortcuts ---
    public static PlayerNotification actionBarInfo(Text message) {
        return new PlayerNotification(MessageChannel.ACTION_BAR, MessageSeverity.INFO, message, null);
    }

    public static PlayerNotification actionBarSuccess(Text message) {
        return new PlayerNotification(MessageChannel.ACTION_BAR, MessageSeverity.SUCCESS, message, null);
    }

    public static PlayerNotification actionBarWarn(Text message) {
        return new PlayerNotification(MessageChannel.ACTION_BAR, MessageSeverity.WARNING, message, null);
    }

    public static PlayerNotification actionBarError(Text message) {
        return new PlayerNotification(MessageChannel.ACTION_BAR, MessageSeverity.ERROR, message, null);
    }

    // --- Toast-Shortcuts (Server-seitig nur semantisch, Implementation entscheidet) ---
    public static PlayerNotification toastInfo(Text message) {
        return new PlayerNotification(MessageChannel.TOAST, MessageSeverity.INFO, message, null);
    }

    public static PlayerNotification toastSuccess(Text message) {
        return new PlayerNotification(MessageChannel.TOAST, MessageSeverity.SUCCESS, message, null);
    }

    public static PlayerNotification toastWarn(Text message) {
        return new PlayerNotification(MessageChannel.TOAST, MessageSeverity.WARNING, message, null);
    }

    public static PlayerNotification toastError(Text message) {
        return new PlayerNotification(MessageChannel.TOAST, MessageSeverity.ERROR, message, null);
    }

    // -- -- Withers ---
    public PlayerNotification withDebugKey(Text debugKey) {
        return new PlayerNotification(this.channel, this.severity, this.message, debugKey);
    }
}
