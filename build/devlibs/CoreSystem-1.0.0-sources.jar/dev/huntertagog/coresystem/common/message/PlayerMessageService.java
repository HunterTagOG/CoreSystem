package dev.huntertagog.coresystem.common.message;

import dev.huntertagog.coresystem.common.provider.Service;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface PlayerMessageService extends Service {

    void send(@NotNull ServerPlayerEntity player, @NotNull PlayerNotification notification);

    // ---------------- Chat ----------------

    default void sendInfoChat(ServerPlayerEntity player, Text message) {
        send(player, PlayerNotification.chatInfo(message));
    }

    default void sendSuccessChat(ServerPlayerEntity player, Text message) {
        send(player, PlayerNotification.chatSuccess(message));
    }

    default void sendWarnChat(ServerPlayerEntity player, Text message) {
        send(player, PlayerNotification.chatWarn(message));
    }

    default void sendErrorChat(ServerPlayerEntity player, Text message) {
        send(player, PlayerNotification.chatError(message));
    }

    // ---------------- ActionBar ----------------

    default void sendInfoActionBar(ServerPlayerEntity player, Text message) {
        send(player, PlayerNotification.actionBarInfo(message));
    }

    default void sendSuccessActionBar(ServerPlayerEntity player, Text message) {
        send(player, PlayerNotification.actionBarSuccess(message));
    }

    default void sendWarnActionBar(ServerPlayerEntity player, Text message) {
        send(player, PlayerNotification.actionBarWarn(message));
    }

    default void sendErrorActionBar(ServerPlayerEntity player, Text message) {
        send(player, PlayerNotification.actionBarError(message));
    }

    // ---------------- Title / Subtitle ----------------
    //
    // Times in Ticks (20 = 1 Sekunde)

    default void sendTitle(ServerPlayerEntity player,
                           Text title,
                           @Nullable Text subtitle,
                           int fadeInTicks,
                           int stayTicks,
                           int fadeOutTicks) {
        // Basis-Impl. wird in DefaultPlayerMessageService überschrieben;
        // Fallback: wir mappen Titel+Subtitle in eine Chat-Nachricht

        Text combined = subtitle != null
                ? Text.empty().append(title).append(Text.literal(" - ")).append(subtitle)
                : title;

        sendInfoChat(player, combined);
    }

    default void sendTitleInfo(ServerPlayerEntity player,
                               Text title,
                               @Nullable Text subtitle,
                               int fadeInTicks,
                               int stayTicks,
                               int fadeOutTicks) {
        sendTitle(player, title, subtitle, fadeInTicks, stayTicks, fadeOutTicks);
    }

    // ---------------- Toasts ----------------
    //
    // Standard-Server hat keine echten Custom-Server-Toasts.
    // Implementierung entscheidet, wie TOAST-Channel dargestellt wird.

    default void sendToastInfo(ServerPlayerEntity player, Text title, @Nullable Text description) {
        send(player, PlayerNotification.toastInfo(buildToastMessage(title, description)));
    }

    default void sendToastSuccess(ServerPlayerEntity player, Text title, @Nullable Text description) {
        send(player, PlayerNotification.toastSuccess(buildToastMessage(title, description)));
    }

    default void sendToastWarn(ServerPlayerEntity player, Text title, @Nullable Text description) {
        send(player, PlayerNotification.toastWarn(buildToastMessage(title, description)));
    }

    default void sendToastError(ServerPlayerEntity player, Text title, @Nullable Text description) {
        send(player, PlayerNotification.toastError(buildToastMessage(title, description)));
    }

    private static Text buildToastMessage(Text title, @Nullable Text description) {
        if (description == null || description.getString().isBlank()) {
            return title;
        }

        // Text-API nutzen statt String-Concats:
        return Text.empty()
                .append(title)
                .append(Text.literal(" §7- "))
                .append(description);
    }
}
