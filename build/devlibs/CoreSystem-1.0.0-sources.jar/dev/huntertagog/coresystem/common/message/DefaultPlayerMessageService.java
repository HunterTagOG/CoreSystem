package dev.huntertagog.coresystem.common.message;

import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class DefaultPlayerMessageService implements PlayerMessageService {

    private static final Logger LOG = LoggerFactory.get("PlayerMessageService");

    @Override
    public void send(@NotNull ServerPlayerEntity player,
                     @NotNull PlayerNotification notification) {

        try {
            switch (notification.channel()) {
                case CHAT -> sendChatInternal(player, notification);
                case ACTION_BAR -> sendActionBarInternal(player, notification);
                case TITLE -> sendTitleInternal(player, notification);
                case SUBTITLE -> sendSubtitleInternal(player, notification);
                case SYSTEM -> sendSystemInternal(player, notification);
                case TOAST -> sendToastInternal(player, notification);
            }
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.PLAYER_MESSAGE_SEND_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to send player notification"
                    )
                    .withCause(e)
                    .withContextEntry("playerUuid", player.getUuidAsString())
                    .withContextEntry("channel", notification.channel().name())
                    .withContextEntry("severity", notification.severity().name())
                    .withContextEntry("message", notification.message().getString())
                    .log();

            LOG.warn("Failed to send notification '{}' to player {} ({})",
                    notification.message().getString(),
                    player.getGameProfile().getName(),
                    player.getUuidAsString());
        }
    }

    // ---------------- Chat ----------------

    private void sendChatInternal(ServerPlayerEntity player, PlayerNotification n) {
        player.sendMessage(applySeverityFormatting(n), false);
    }

    // ---------------- ActionBar ----------------

    private void sendActionBarInternal(ServerPlayerEntity player, PlayerNotification n) {
        player.sendMessage(applySeverityFormatting(n), true);
    }

    // ---------------- Title / Subtitle (simple Variante) ----------------

    private void sendTitleInternal(ServerPlayerEntity player, PlayerNotification n) {
        Text title = applySeverityFormatting(n);
        player.networkHandler.sendPacket(new TitleS2CPacket(title));
    }

    private void sendSubtitleInternal(ServerPlayerEntity player, PlayerNotification n) {
        Text subtitle = applySeverityFormatting(n);
        player.networkHandler.sendPacket(new SubtitleS2CPacket(subtitle));
    }

    @Override
    public void sendTitle(ServerPlayerEntity player,
                          Text title,
                          @Nullable Text subtitle,
                          int fadeInTicks,
                          int stayTicks,
                          int fadeOutTicks) {
        try {
            player.networkHandler.sendPacket(new TitleFadeS2CPacket(fadeInTicks, stayTicks, fadeOutTicks));
            player.networkHandler.sendPacket(new TitleS2CPacket(title));

            if (subtitle != null) {
                player.networkHandler.sendPacket(new SubtitleS2CPacket(subtitle));
            }
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.PLAYER_MESSAGE_SEND_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to send title to player"
                    )
                    .withCause(e)
                    .withContextEntry("playerUuid", player.getUuidAsString())
                    .withContextEntry("title", title.getString())
                    .withContextEntry("subtitle", subtitle != null ? subtitle.getString() : "null")
                    .log();
        }
    }

    // ---------------- System ----------------

    private void sendSystemInternal(ServerPlayerEntity player, PlayerNotification n) {
        player.sendMessage(applySeverityFormatting(n), false);
    }

    // ---------------- Toast (Server-Fallback) ----------------

    private void sendToastInternal(ServerPlayerEntity player, PlayerNotification n) {
        // Aktuell: Chat-Toast-Emulation
        Text base = n.message();

        Text prefixed = switch (n.severity()) {
            case SUCCESS -> Text.literal("✔ ").formatted(Formatting.GREEN).append(base);
            case WARNING -> Text.literal("⚠ ").formatted(Formatting.YELLOW).append(base);
            case ERROR -> Text.literal("✖ ").formatted(Formatting.RED).append(base);
            case INFO -> Text.literal("• ").formatted(Formatting.GRAY).append(base);
        };

        player.sendMessage(prefixed, false);
    }

    // ---------------- Styling ----------------

    private Text applySeverityFormatting(PlayerNotification n) {
        Text base = n.message();

        // Du kannst hier gerne feiner aufsplitten, ich halte es bewusst simpel:
        return switch (n.severity()) {
            case SUCCESS -> base.copy().formatted(Formatting.GREEN);
            case WARNING -> base.copy().formatted(Formatting.YELLOW);
            case ERROR -> base.copy().formatted(Formatting.RED);
            case INFO -> base.copy().formatted(Formatting.GRAY);
        };
    }
}
