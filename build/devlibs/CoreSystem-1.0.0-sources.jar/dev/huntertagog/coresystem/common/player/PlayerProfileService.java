package dev.huntertagog.coresystem.common.player;

import dev.huntertagog.coresystem.common.provider.Service;
import net.minecraft.server.network.ServerPlayerEntity;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.UUID;

public interface PlayerProfileService extends Service {

    @NotNull
    PlayerProfile getOrCreate(@NotNull UUID uniqueId, @Nullable String fallbackName);

    @NotNull
    default PlayerProfile getOrCreate(@NotNull ServerPlayerEntity player) {
        return getOrCreate(player.getUuid(), player.getGameProfile().getName());
    }

    @NotNull
    Optional<PlayerProfile> find(@NotNull UUID uniqueId);

    PlayerProfile updateOnJoin(@NotNull ServerPlayerEntity player, @NotNull String currentServerName, @Nullable String nodeId);

    Optional<PlayerProfile> updateOnQuit(@NotNull ServerPlayerEntity player, @NotNull String currentServerName, @Nullable String nodeId);
}
