package dev.huntertagog.coresystem.common.player.lifecycle;

import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.clans.ClanInvite;
import dev.huntertagog.coresystem.common.clans.ClanService;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.common.friends.FriendService;
import dev.huntertagog.coresystem.common.friends.OfflineFriendMessage;
import dev.huntertagog.coresystem.common.message.PlayerMessageService;
import dev.huntertagog.coresystem.common.player.PlayerContext;
import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import dev.huntertagog.coresystem.common.text.CoreMessage;
import dev.huntertagog.coresystem.common.text.Messages;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import org.jetbrains.annotations.Nullable;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Zentraler Entry-Point für Player-Join/Quit-Lifecycle im Core-System.
 * Kapselt das Wiring zur Fabric-API und delegiert an PlayerContext.
 */
public final class PlayerLifecycleListener {

    private static final Logger LOG = LoggerFactory.get("PlayerLifecycle");

    // Diese Werte idealerweise aus Config/ENV ziehen
    private static final String CURRENT_SERVER_NAME =
            System.getenv().getOrDefault("SERVER_NAME", "unknown-server");

    private static final @Nullable String NODE_ID =
            System.getenv("ISLAND_ID");

    private static final DateTimeFormatter TS =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")
                    .withZone(ZoneId.systemDefault());

    private PlayerLifecycleListener() {
        // static utility
    }

    /**
     * Wird aus dem Mod-Initializer aufgerufen, um die Fabric-Events zu registrieren.
     */
    public static void register() {
        // Join
        ServerPlayConnectionEvents.JOIN.register(PlayerLifecycleListener::onJoin);

        // Disconnect/Quit
        ServerPlayConnectionEvents.DISCONNECT.register(PlayerLifecycleListener::onQuit);
    }

    // Helper, um MessageService zu ziehen
    private static PlayerMessageService messages() {
        PlayerMessageService service = ServiceProvider.getService(PlayerMessageService.class);
        if (service == null) {
            CoreError.of(
                            CoreErrorCode.SERVICE_MISSING,
                            CoreErrorSeverity.CRITICAL,
                            "PlayerMessageService not registered in PlayerLifecycleListener"
                    )
                    .withContextEntry("service", "PlayerMessageService")
                    .log();
            throw new IllegalStateException("PlayerMessageService not registered");
        }
        return service;
    }

    // ------------------------------------------------------------------------
    // Intern: Join-Flow
    // ------------------------------------------------------------------------

    private static void onJoin(ServerPlayNetworkHandler handler,
                               PacketSender sender,
                               MinecraftServer server) {

        var player = handler.getPlayer();

        try {
            // PlayerContext initialisieren + Profil/Events über Redis-Layer aktualisieren
            PlayerContext ctx = PlayerContext.onJoin(player, CURRENT_SERVER_NAME, NODE_ID);

            // Beispielhafte Nutzung – hier kannst du deine Welcome-/Tutorial-Pipeline aufsetzen
            if (ctx.isFirstJoin()) {
                messages().sendInfoChat(
                        player,
                        Messages.t(CoreMessage.FIRST_JOIN_WELCOME_MESSAGE, ctx.name())
                );
                // z. B. später: Tutorial-Flag setzen, erste Rewards etc.
            } else {
                messages().sendInfoChat(
                        player,
                        Messages.t(CoreMessage.JOIN_WELCOME_BACK_MESSAGE, ctx.name())
                );
            }

            handleOfflineMessages(player);
            handleClanInvites(player);

            // Weitere Kontextdaten stehen zur Verfügung:
            // ctx.getLastServer(), ctx.getLastNodeId(), ctx.getTotalJoins(), ...

        } catch (Exception e) {
            // Hard-Fail im Context-Setup – wir loggen sauber und lassen den Spieler trotzdem joinen
            CoreError.of(CoreErrorCode.PLAYERCONTEXT_INIT_FAILED,
                            CoreErrorSeverity.ERROR,
                            "Failed to initialize PlayerContext on join. Player will continue without profile context.")
                    .withContextEntry("uuid", player.getUuidAsString())
                    .withContextEntry("server", CURRENT_SERVER_NAME)
                    .withContextEntry("nodeId", String.valueOf(NODE_ID))
                    .log();

            // Optional: knappe Info an den Spieler (bei Dev/Debug-Umgebung)
            // player.sendMessage(Text.literal("Es gab ein Problem beim Laden deines Profils. Bitte melde dich beim Support."), false);
        }
    }

    // ------------------------------------------------------------------------
    // Intern: Quit-Flow
    // ------------------------------------------------------------------------

    private static void onQuit(ServerPlayNetworkHandler handler,
                               MinecraftServer server) {

        var player = handler.getPlayer();

        try {
            // Fire-and-forget, Rückgabewert vom Context ist hier i. d. R. nicht nötig
            PlayerContext.onQuit(player, CURRENT_SERVER_NAME, NODE_ID);

        } catch (Exception e) {
            CoreError.of(CoreErrorCode.PLAYERCONTEXT_QUIT_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to handle PlayerContext on quit. Ignoring.")
                    .withContextEntry("uuid", player.getUuidAsString())
                    .withContextEntry("server", CURRENT_SERVER_NAME)
                    .withContextEntry("nodeId", String.valueOf(NODE_ID))
                    .log();
        }
    }

    // ---------------------------------------------------------------------
    // Offline Friend Messages
    // ---------------------------------------------------------------------

    private static void handleOfflineMessages(ServerPlayerEntity player) {
        FriendService friends = ServiceProvider.getService(FriendService.class);
        if (friends == null) {
            CoreError.of(
                            CoreErrorCode.SERVICE_MISSING,
                            CoreErrorSeverity.WARN,
                            "FriendService not available for offline message delivery"
                    )
                    .withContextEntry("playerUuid", player.getUuidAsString())
                    .log();
            return;
        }

        List<OfflineFriendMessage> messages = friends.pollOfflineMessages(player.getUuid());
        if (messages == null || messages.isEmpty()) {
            return;
        }

        PlayerMessageService pms = ServiceProvider.getService(PlayerMessageService.class);

        // Header über CoreMessages
        Text header = Messages.t(CoreMessage.FRIEND_OFFLINE_HEADER, messages.size());

        if (pms != null) {
            Text toastTitle = Messages.t(CoreMessage.FRIEND_OFFLINE_TOAST_TITLE);
            pms.sendToastInfo(player, toastTitle, header);
        } else {
            // Fallback auf prefix-basiertes Message-System
            Messages.send(player, CoreMessage.FRIEND_OFFLINE_HEADER, messages.size());
        }

        // Erste n Messages direkt in den Chat pushen (Rest nur summarisch)
        int limit = Math.min(5, messages.size());
        for (int i = 0; i < limit; i++) {
            OfflineFriendMessage msg = messages.get(i);
            String ts = TS.format(Instant.ofEpochMilli(msg.sentAtEpochMillis()));

            Text line = Messages.t(
                    CoreMessage.FRIEND_OFFLINE_LINE,
                    ts,
                    msg.senderName(),
                    msg.message()
            );

            if (pms != null) {
                pms.sendInfoChat(player, line);
            } else {
                // ohne Prefix: Player direkt
                player.sendMessage(line);
            }
        }

        if (messages.size() > limit) {
            int remaining = messages.size() - limit;
            Text more = Messages.t(CoreMessage.FRIEND_OFFLINE_MORE, remaining);

            if (pms != null) {
                pms.sendInfoChat(player, more);
            } else {
                player.sendMessage(more);
            }
        }

        LOG.info("Delivered {} offline friend messages to {}", messages.size(), player.getGameProfile().getName());
    }

    // ---------------------------------------------------------------------
    // Clan-Invites
    // ---------------------------------------------------------------------

    private static void handleClanInvites(ServerPlayerEntity player) {
        ClanService clans = ServiceProvider.getService(ClanService.class);
        if (clans == null) {
            CoreError.of(
                            CoreErrorCode.SERVICE_MISSING,
                            CoreErrorSeverity.WARN,
                            "ClanService not available for clan invite delivery"
                    )
                    .withContextEntry("playerUuid", player.getUuidAsString())
                    .log();
            return;
        }

        List<ClanInvite> invites = clans.pollPendingInvites(player.getUuid());
        if (invites == null || invites.isEmpty()) {
            return;
        }

        PlayerMessageService pms = ServiceProvider.getService(PlayerMessageService.class);

        Text header = Messages.t(CoreMessage.CLAN_INVITES_HEADER, invites.size());

        if (pms != null) {
            Text toastTitle = Messages.t(CoreMessage.CLAN_INVITES_TOAST_TITLE);
            pms.sendToastInfo(player, toastTitle, header);
        } else {
            Messages.send(player, CoreMessage.CLAN_INVITES_HEADER, invites.size());
        }

        int limit = Math.min(5, invites.size());
        for (int i = 0; i < limit; i++) {
            ClanInvite inv = invites.get(i);
            String ts = TS.format(Instant.ofEpochMilli(inv.getCreatedAtEpochMillis()));

            // Wir verwenden Clan-Namen als Command-Argument; bei Bedarf kannst du hier Tag/ID verwenden
            String clanName = inv.getClanName();

            Text line = Messages.t(
                    CoreMessage.CLAN_INVITES_LINE,
                    ts,
                    inv.getInviterName(),
                    clanName,
                    clanName,
                    clanName
            );

            if (pms != null) {
                pms.sendInfoChat(player, line);
            } else {
                player.sendMessage(line);
            }
        }

        if (invites.size() > limit) {
            Text more = Messages.t(CoreMessage.CLAN_INVITES_MORE);
            if (pms != null) {
                pms.sendInfoChat(player, more);
            } else {
                player.sendMessage(more);
            }
        }

        LOG.info("Delivered {} clan invites to {}", invites.size(), player.getGameProfile().getName());
    }
}
