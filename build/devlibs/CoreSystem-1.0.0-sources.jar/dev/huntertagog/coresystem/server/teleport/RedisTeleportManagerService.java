package dev.huntertagog.coresystem.server.teleport;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.common.playerdata.PlayerDataSyncService;
import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import dev.huntertagog.coresystem.common.teleport.TeleportManagerService;
import dev.huntertagog.coresystem.server.redis.RedisClient;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import redis.clients.jedis.Jedis;

import java.util.Optional;
import java.util.UUID;

public final class RedisTeleportManagerService implements TeleportManagerService {

    private static final Logger LOG = LoggerFactory.get("TeleportManager");
    private static final String KEY_PREFIX = "cs:teleport:pending:";

    private static final String DEFAULT_INVENTORY_CONTEXT = "network-global";

    private final Gson gson = new Gson();
    private final String serverName;

    public RedisTeleportManagerService() {
        this.serverName = System.getenv().getOrDefault("SERVER_NAME", "unknown");
    }

    @Override
    public void teleportPlayer(@NotNull ServerPlayerEntity player,
                               @NotNull String targetServer,
                               @Nullable String inventoryContext,
                               @Nullable String reason) {

        UUID uuid = player.getUuid();
        String context = inventoryContext != null ? inventoryContext : DEFAULT_INVENTORY_CONTEXT;

        // 1) Inventory snapshot persistieren
        PlayerDataSyncService dataSync = ServiceProvider.getService(PlayerDataSyncService.class);
        if (dataSync != null) {
            dataSync.saveInventorySnapshot(player, context, "teleport:" + (reason != null ? reason : "unknown"));
        } else {
            CoreError.of(
                            CoreErrorCode.SERVICE_MISSING,
                            CoreErrorSeverity.WARN,
                            "PlayerDataSyncService missing for teleport"
                    )
                    .withContextEntry("playerUuid", uuid.toString())
                    .withContextEntry("targetServer", targetServer)
                    .withContextEntry("context", context)
                    .log();
        }

        // 2) PendingTeleport in Redis ablegen
        PendingTeleport pending = new PendingTeleport(
                uuid,
                targetServer,
                context,
                System.currentTimeMillis(),
                reason
        );
        savePendingTeleport(pending);

        // 3) Proxy-Command ausführen
        executeProxyCommand(player, targetServer);
    }

    @Override
    public boolean handleJoinOnThisServer(@NotNull ServerPlayerEntity player) {
        UUID uuid = player.getUuid();

        Optional<PendingTeleport> opt = loadPendingTeleport(uuid);
        if (opt.isEmpty()) {
            return false;
        }

        PendingTeleport pending = opt.get();

        // Nur Zielserver verarbeitet den Eintrag
        if (!this.serverName.equalsIgnoreCase(pending.targetServer())) {
            // Defensive: Eintrag nicht löschen, falls Player auf falschem Server gelandet ist
            LOG.debug("PendingTeleport found for {} but targetServer={} != thisServer={}",
                    uuid, pending.targetServer(), this.serverName);
            return false;
        }

        PlayerDataSyncService dataSync = ServiceProvider.getService(PlayerDataSyncService.class);
        if (dataSync == null) {
            CoreError.of(
                            CoreErrorCode.SERVICE_MISSING,
                            CoreErrorSeverity.ERROR,
                            "PlayerDataSyncService missing on target server for teleport join"
                    )
                    .withContextEntry("playerUuid", uuid.toString())
                    .withContextEntry("targetServer", pending.targetServer())
                    .withContextEntry("context", pending.inventoryContext())
                    .log();

            // trotzdem Pending-Eintrag bereinigen, damit wir keine Leichen haben
            deletePendingTeleport(uuid);
            return false;
        }

        boolean applied = dataSync.applyInventorySnapshot(player, pending.inventoryContext(), true);
        if (!applied) {
            CoreError.of(
                            CoreErrorCode.PLAYERDATA_APPLY_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to apply inventory snapshot on teleport join"
                    )
                    .withContextEntry("playerUuid", uuid.toString())
                    .withContextEntry("targetServer", pending.targetServer())
                    .withContextEntry("context", pending.inventoryContext())
                    .log();
        }

        deletePendingTeleport(uuid);

        LOG.info("Handled PendingTeleport for {} on targetServer={} (context={})",
                uuid, pending.targetServer(), pending.inventoryContext());

        return applied;
    }

    // ----------------- Redis-Backend -----------------

    private void savePendingTeleport(PendingTeleport pending) {
        String key = KEY_PREFIX + pending.playerUuid();

        JsonObject json = new JsonObject();
        json.addProperty("playerUuid", pending.playerUuid().toString());
        json.addProperty("targetServer", pending.targetServer());
        json.addProperty("inventoryContext", pending.inventoryContext());
        json.addProperty("createdAt", pending.createdAt());
        if (pending.reason() != null) {
            json.addProperty("reason", pending.reason());
        }

        String value = gson.toJson(json);

        try (Jedis jedis = RedisClient.get().getResource()) {
            jedis.set(key, value);
            jedis.pexpire(key, 5 * 60 * 1000L); // 5 Minuten TTL, zur Sicherheit
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.TELEPORT_REDIS_SAVE_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to save PendingTeleport to Redis"
                    )
                    .withCause(e)
                    .withContextEntry("redisKey", key)
                    .withContextEntry("targetServer", pending.targetServer())
                    .withContextEntry("inventoryContext", pending.inventoryContext())
                    .log();
        }
    }

    private Optional<PendingTeleport> loadPendingTeleport(UUID uuid) {
        String key = KEY_PREFIX + uuid;

        String json;
        try (Jedis jedis = RedisClient.get().getResource()) {
            json = jedis.get(key);
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.TELEPORT_REDIS_LOAD_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to load PendingTeleport from Redis"
                    )
                    .withCause(e)
                    .withContextEntry("redisKey", key)
                    .withContextEntry("playerUuid", uuid.toString())
                    .log();
            return Optional.empty();
        }

        if (json == null || json.isEmpty()) {
            return Optional.empty();
        }

        try {
            JsonObject obj = gson.fromJson(json, JsonObject.class);

            String targetServer = obj.get("targetServer").getAsString();
            String context = obj.get("inventoryContext").getAsString();
            long createdAt = obj.has("createdAt") ? obj.get("createdAt").getAsLong() : 0L;
            String reason = obj.has("reason") ? obj.get("reason").getAsString() : null;

            PendingTeleport pending = new PendingTeleport(
                    uuid,
                    targetServer,
                    context,
                    createdAt,
                    reason
            );
            return Optional.of(pending);
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.TELEPORT_REDIS_PARSE_FAILED,
                            CoreErrorSeverity.ERROR,
                            "Failed to parse PendingTeleport JSON from Redis"
                    )
                    .withCause(e)
                    .withContextEntry("redisKey", key)
                    .withContextEntry("playerUuid", uuid.toString())
                    .log();
            return Optional.empty();
        }
    }

    private void deletePendingTeleport(UUID uuid) {
        String key = KEY_PREFIX + uuid;
        try (Jedis jedis = RedisClient.get().getResource()) {
            jedis.del(key);
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.TELEPORT_REDIS_DELETE_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to delete PendingTeleport from Redis"
                    )
                    .withCause(e)
                    .withContextEntry("redisKey", key)
                    .withContextEntry("playerUuid", uuid.toString())
                    .log();
        }
    }

    // ----------------- Proxy-Command -----------------

    private void executeProxyCommand(ServerPlayerEntity player, String targetServer) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }

        String template = "proxycommand \\\"server {target}\\";

        String cmd = template
                .replace("{target}", targetServer)
                .replace("{player}", player.getGameProfile().getName());

        ServerCommandSource source = player.getCommandSource();

        try {
            server.getCommandManager().executeWithPrefix(source.withSilent(), cmd);
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.TELEPORT_PROXY_COMMAND_FAILED,
                            CoreErrorSeverity.ERROR,
                            "Failed to execute proxy teleport command"
                    )
                    .withCause(e)
                    .withContextEntry("command", cmd)
                    .withContextEntry("playerUuid", player.getUuid().toString())
                    .withContextEntry("playerName", player.getGameProfile().getName())
                    .withContextEntry("targetServer", targetServer)
                    .log();
        }
    }
}
