package dev.huntertagog.coresystem.server.chat;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.chat.PlayerNicknameService;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.server.redis.RedisClient;
import net.minecraft.server.network.ServerPlayerEntity;
import org.jetbrains.annotations.Nullable;
import redis.clients.jedis.Jedis;

import java.time.Duration;
import java.util.Optional;
import java.util.UUID;

public final class RedisPlayerNicknameService implements PlayerNicknameService {

    private static final Logger LOG = LoggerFactory.get("PlayerNick");
    private static final String KEY_PREFIX = "cs:playernick:";
    private static final String INDEX_PREFIX = "cs:playernick:index:";

    private final Cache<UUID, Optional<String>> cache;

    public RedisPlayerNicknameService() {
        this.cache = Caffeine.newBuilder()
                .expireAfterAccess(Duration.ofMinutes(10))
                .maximumSize(50_000)
                .build();
    }

    private String redisKey(UUID uuid) {
        return KEY_PREFIX + uuid;
    }

    private String indexKey(String normalizedNick) {
        return INDEX_PREFIX + normalizedNick;
    }

    @Override
    public Optional<String> getNickname(UUID playerId) {
        Optional<String> cached = cache.getIfPresent(playerId);
        if (cached != null) {
            return cached;
        }

        String key = redisKey(playerId);

        try (Jedis jedis = RedisClient.get().getResource()) {
            String nick = jedis.hget(key, "nick");
            Optional<String> opt = (nick == null || nick.isBlank())
                    ? Optional.empty()
                    : Optional.of(nick);
            cache.put(playerId, opt);
            return opt;
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.PLAYER_NICK_REDIS_LOAD_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to load nickname from Redis"
                    )
                    .withCause(e)
                    .withContextEntry("playerUuid", playerId.toString())
                    .withContextEntry("redisKey", key)
                    .log();
            return Optional.empty();
        }
    }

    @Override
    public String getEffectiveName(ServerPlayerEntity player) {
        return getNickname(player.getUuid())
                .filter(n -> !n.isBlank())
                .orElse(player.getGameProfile().getName());
    }

    @Override
    public void setNickname(UUID playerId, @Nullable String nickname) {
        String key = redisKey(playerId);

        // alten Nick entfernen (für Index)
        Optional<String> existing = getNickname(playerId);
        existing.ifPresent(old -> removeIndex(old, playerId));

        if (nickname == null || nickname.isBlank()) {
            // löschen
            try (Jedis jedis = RedisClient.get().getResource()) {
                jedis.hdel(key, "nick");
            } catch (Exception e) {
                CoreError.of(
                                CoreErrorCode.PLAYER_NICK_REDIS_SAVE_FAILED,
                                CoreErrorSeverity.WARN,
                                "Failed to clear nickname in Redis"
                        )
                        .withCause(e)
                        .withContextEntry("playerUuid", playerId.toString())
                        .withContextEntry("redisKey", key)
                        .log();
            }
            cache.put(playerId, Optional.empty());
            return;
        }

        String trimmed = nickname.trim();
        String lower = trimmed.toLowerCase();

        try (Jedis jedis = RedisClient.get().getResource()) {
            jedis.hset(key, "nick", trimmed);
            // einfacher Index
            jedis.set(indexKey(lower), playerId.toString());
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.PLAYER_NICK_REDIS_SAVE_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to save nickname in Redis"
                    )
                    .withCause(e)
                    .withContextEntry("playerUuid", playerId.toString())
                    .withContextEntry("redisKey", key)
                    .withContextEntry("nick", trimmed)
                    .log();
        }

        cache.put(playerId, Optional.of(trimmed));
    }

    @Override
    public void clearNickname(UUID playerId) {
        setNickname(playerId, null);
    }

    @Override
    public Optional<UUID> findByNickname(String nickname) {
        if (nickname == null || nickname.isBlank()) {
            return Optional.empty();
        }
        String lower = nickname.toLowerCase();
        String idxKey = indexKey(lower);

        try (Jedis jedis = RedisClient.get().getResource()) {
            String val = jedis.get(idxKey);
            if (val == null || val.isBlank()) {
                return Optional.empty();
            }
            return Optional.of(UUID.fromString(val));
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.PLAYER_NICK_REDIS_INDEX_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to resolve nickname index in Redis"
                    )
                    .withCause(e)
                    .withContextEntry("nick", nickname)
                    .log();
            return Optional.empty();
        }
    }

    private void removeIndex(String oldNickname, UUID playerId) {
        String lower = oldNickname.toLowerCase();
        String idxKey = indexKey(lower);
        try (Jedis jedis = RedisClient.get().getResource()) {
            String current = jedis.get(idxKey);
            if (playerId.toString().equals(current)) {
                jedis.del(idxKey);
            }
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.PLAYER_NICK_REDIS_INDEX_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to remove nickname index"
                    )
                    .withCause(e)
                    .withContextEntry("nick", oldNickname)
                    .withContextEntry("playerUuid", playerId.toString())
                    .log();
        }
    }
}
