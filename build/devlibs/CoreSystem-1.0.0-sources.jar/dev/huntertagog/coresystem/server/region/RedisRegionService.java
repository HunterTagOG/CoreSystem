package dev.huntertagog.coresystem.server.region;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.common.region.RegionDefinitionDto;
import dev.huntertagog.coresystem.common.region.RegionFlag;
import dev.huntertagog.coresystem.common.region.RegionService;
import dev.huntertagog.coresystem.server.redis.RedisClient;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.NotNull;
import redis.clients.jedis.Jedis;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Redis-gestützter RegionService:
 * - hält In-Memory-Index (DefaultRegionService)
 * - persistiert Regionen in Redis
 */
public final class RedisRegionService implements RegionService {

    private static final Logger LOG = LoggerFactory.get("Regions-Redis");

    private static final String KEY_ALL_REGIONS = "cs:regions:all";
    private static final String KEY_REGION_PREFIX = "cs:region:";

    private final DefaultRegionService delegate = new DefaultRegionService();
    private final Gson gson = new Gson();

    public RedisRegionService() {
        loadAllFromRedis();
    }

    // ------------------------------------------------------------------------
    // RegionService-API
    // ------------------------------------------------------------------------

    @Override
    public void registerRegion(@NotNull RegionDefinition region) {
        // 1) In-Memory
        delegate.registerRegion(region);

        // 2) Redis
        persistRegion(region);
    }

    @Override
    public void removeRegion(@NotNull String id) {
        // 1) In-Memory
        delegate.removeRegion(id);

        // 2) Redis
        deleteRegionFromRedis(id);
    }

    @Override
    public Optional<RegionDefinition> findById(@NotNull String id) {
        return delegate.findById(id);
    }

    @Override
    public @NotNull List<RegionDefinition> findRegionsAt(@NotNull ServerWorld world, @NotNull BlockPos pos) {
        return delegate.findRegionsAt(world, pos);
    }

    @Override
    public boolean hasFlagAt(@NotNull ServerWorld world,
                             @NotNull BlockPos pos,
                             @NotNull RegionFlag flag) {
        return delegate.hasFlagAt(world, pos, flag);
    }

    @Override
    public List<RegionDefinition> getAllRegions() {
        return delegate.getAllRegions();
    }

    // ------------------------------------------------------------------------
    // Redis-Backend
    // ------------------------------------------------------------------------

    private void loadAllFromRedis() {
        try (Jedis jedis = RedisClient.get().getResource()) {
            Set<String> ids = jedis.smembers(KEY_ALL_REGIONS);
            if (ids == null || ids.isEmpty()) {
                LOG.info("No regions found in Redis (key={})", KEY_ALL_REGIONS);
                return;
            }

            List<RegionDefinition> loaded = new ArrayList<>();
            for (String id : ids) {
                String key = KEY_REGION_PREFIX + id;
                String json = jedis.get(key);
                if (json == null || json.isEmpty()) {
                    continue;
                }

                try {
                    RegionDefinitionDto dto = gson.fromJson(json, RegionDefinitionDto.class);
                    RegionDefinition region = RegionDefinitionMapper.fromDto(dto);
                    delegate.registerRegion(region);
                    loaded.add(region);
                } catch (JsonSyntaxException ex) {
                    CoreError.of(
                                    CoreErrorCode.REGION_JSON_PARSE_FAILED,
                                    CoreErrorSeverity.WARN,
                                    "Failed to parse RegionDefinition JSON from Redis"
                            )
                            .withCause(ex)
                            .withContextEntry("regionId", id)
                            .withContextEntry("redisKey", key)
                            .log();
                }
            }

            LOG.info("Loaded {} region(s) from Redis", loaded.size());
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.REGION_REDIS_LOAD_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to load regions from Redis"
                    )
                    .withCause(e)
                    .withContextEntry("redisKeyAll", KEY_ALL_REGIONS)
                    .log();
        }
    }

    private void persistRegion(RegionDefinition region) {
        String key = KEY_REGION_PREFIX + region.id();
        RegionDefinitionDto dto = RegionDefinitionMapper.toDto(region);
        String json = gson.toJson(dto);

        try (Jedis jedis = RedisClient.get().getResource()) {
            jedis.set(key, json);
            jedis.sadd(KEY_ALL_REGIONS, region.id());
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.REGION_REDIS_SAVE_FAILED,
                            CoreErrorSeverity.ERROR,
                            "Failed to save region to Redis"
                    )
                    .withCause(e)
                    .withContextEntry("regionId", region.id())
                    .withContextEntry("redisKey", key)
                    .log();
        }
    }

    private void deleteRegionFromRedis(String id) {
        String key = KEY_REGION_PREFIX + id;
        try (Jedis jedis = RedisClient.get().getResource()) {
            jedis.del(key);
            jedis.srem(KEY_ALL_REGIONS, id);
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.REGION_REDIS_DELETE_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to delete region from Redis"
                    )
                    .withCause(e)
                    .withContextEntry("regionId", id)
                    .withContextEntry("redisKey", key)
                    .log();
        }
    }
}
