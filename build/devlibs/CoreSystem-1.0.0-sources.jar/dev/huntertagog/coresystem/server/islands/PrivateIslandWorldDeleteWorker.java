package dev.huntertagog.coresystem.server.islands;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.server.redis.RedisClient;
import dev.huntertagog.coresystem.server.task.TaskScheduler;
import net.minecraft.server.MinecraftServer;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static dev.huntertagog.coresystem.server.command.impl.PrivateIslandCommand.deleteIslandForOwner;

public final class PrivateIslandWorldDeleteWorker {

    private static final Logger LOG = LoggerFactory.get("IslandDeleteWorker");

    private final MinecraftServer server;
    private final String nodeId;
    private final TaskScheduler scheduler;

    private volatile boolean running = false;

    public PrivateIslandWorldDeleteWorker(MinecraftServer server,
                                          String nodeId,
                                          TaskScheduler scheduler) {
        this.server = server;
        this.nodeId = nodeId;
        this.scheduler = scheduler;
    }

    /**
     * Startet den Worker asynchron über den CoreTaskScheduler.
     */
    public void start() {
        if (running) return;
        running = true;

        LOG.info("Starting IslandDeleteWorker for node '{}'.", nodeId);

        Thread t = new Thread(this::runLoop, "IslandDeleteSubscriber-" + nodeId);
        t.setDaemon(true);
        t.start();
    }

    /**
     * Markiert den Worker als gestoppt. Die Schleife beendet sich nach dem nächsten BRPOP-Timeout.
     */
    public void shutdown() {
        if (!running) {
            return;
        }
        LOG.info("Shutdown requested for IslandDeleteWorker on node '{}'.", nodeId);
        running = false;
    }

    // --------------------------------------------------------
    // Intern: Redis-Loop
    // --------------------------------------------------------

    private void runLoop() {
        String queueKey = "pi:island:delete:queue:" + nodeId;

        try (var jedis = RedisClient.get().getResource()) {
            while (running && !Thread.currentThread().isInterrupted()) {

                // blockierender Pop mit Timeout (5 Sekunden)
                List<String> result = jedis.brpop(5, queueKey);

                // nach Timeout oder Shutdown erneut prüfen
                if (!running) {
                    break;
                }

                if (result == null || result.size() < 2) {
                    continue;
                }

                String jobJson = result.get(1); // Value
                handleJob(jobJson);
            }
        } catch (Exception e) {
            if (running) {
                CoreError error = new CoreError(
                        CoreErrorCode.ISLAND_DELETE_WORKER_FATAL,
                        CoreErrorSeverity.CRITICAL,
                        "Fatal error in IslandDeleteWorker loop. Worker will stop.",
                        e,
                        Map.of(
                                "nodeId", nodeId,
                                "queueKey", queueKey
                        )
                );
                LOG.error(error.toLogString(), e);
            } else {
                LOG.info(
                        "[Island-DeleteWorker] Delete loop for node '{}' terminated after shutdown request.",
                        nodeId
                );
            }
        } finally {
            running = false;
            LOG.info("IslandDeleteWorker for node '{}' stopped.", nodeId);
        }
    }

    private void handleJob(String jobJson) {
        try {
            JsonObject obj = JsonParser.parseString(jobJson).getAsJsonObject();

            if (!obj.has("ownerId")) {
                CoreError error = new CoreError(
                        CoreErrorCode.ISLAND_DELETE_JOB_FAILED,
                        CoreErrorSeverity.ERROR,
                        "Delete job payload is missing 'ownerId'.",
                        null,
                        Map.of("jobJson", jobJson)
                );
                LOG.error(error.toLogString());
                return;
            }

            UUID ownerId = UUID.fromString(obj.get("ownerId").getAsString());

            LOG.info("[Island-DeleteWorker] Received delete request for owner '{}'", ownerId);

            // Löschung sauber im Server-Thread ausführen
            server.execute(() -> deleteIslandForOwner(server, ownerId, server.getCommandSource()));

        } catch (Exception e) {
            CoreError error = new CoreError(
                    CoreErrorCode.ISLAND_DELETE_JOB_FAILED,
                    CoreErrorSeverity.ERROR,
                    "Failed to handle island delete job.",
                    e,
                    Map.of("jobJson", jobJson)
            );
            LOG.error(error.toLogString(), e);
        }
    }
}
