package dev.huntertagog.coresystem;

import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.audit.AuditLogService;
import dev.huntertagog.coresystem.common.chat.ChatFilterService;
import dev.huntertagog.coresystem.common.chat.DefaultNamePrefixResolver;
import dev.huntertagog.coresystem.common.chat.NamePrefixResolver;
import dev.huntertagog.coresystem.common.chat.PlayerNicknameService;
import dev.huntertagog.coresystem.common.clans.ClanService;
import dev.huntertagog.coresystem.common.config.*;
import dev.huntertagog.coresystem.common.dev.DefaultDevToolsService;
import dev.huntertagog.coresystem.common.dev.DevToolsService;
import dev.huntertagog.coresystem.common.economy.DefaultPlayerWalletService;
import dev.huntertagog.coresystem.common.economy.EconomyService;
import dev.huntertagog.coresystem.common.economy.PlayerWalletService;
import dev.huntertagog.coresystem.common.feature.FeatureToggleService;
import dev.huntertagog.coresystem.common.friends.FriendService;
import dev.huntertagog.coresystem.common.friends.gui.FriendGuiServerNet;
import dev.huntertagog.coresystem.common.metrics.MetricsService;
import dev.huntertagog.coresystem.common.module.CoreModule;
import dev.huntertagog.coresystem.common.module.DefaultModuleRegistryService;
import dev.huntertagog.coresystem.common.module.ModuleRegistryService;
import dev.huntertagog.coresystem.common.net.CoresystemNetworking;
import dev.huntertagog.coresystem.common.permission.PermissionService;
import dev.huntertagog.coresystem.common.player.PlayerProfileService;
import dev.huntertagog.coresystem.common.player.lifecycle.PlayerLifecycleListener;
import dev.huntertagog.coresystem.common.playerdata.PlayerDataSyncService;
import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import dev.huntertagog.coresystem.common.ratelimit.InMemoryRateLimitService;
import dev.huntertagog.coresystem.common.ratelimit.RateLimitService;
import dev.huntertagog.coresystem.common.region.RegionService;
import dev.huntertagog.coresystem.common.region.visual.RegionOutlineService;
import dev.huntertagog.coresystem.common.settings.PlayerSettingsService;
import dev.huntertagog.coresystem.common.teleport.TeleportManagerService;
import dev.huntertagog.coresystem.server.audit.RedisAuditLogService;
import dev.huntertagog.coresystem.server.cache.IslandOwnerSuggestionCache;
import dev.huntertagog.coresystem.server.chat.RedisChatFilterService;
import dev.huntertagog.coresystem.server.chat.RedisPlayerNicknameService;
import dev.huntertagog.coresystem.server.clans.RedisClanService;
import dev.huntertagog.coresystem.server.command.CommandsProvider;
import dev.huntertagog.coresystem.server.economy.RedisEconomyService;
import dev.huntertagog.coresystem.server.event.DomainEventBus;
import dev.huntertagog.coresystem.server.event.SimpleDomainEventBus;
import dev.huntertagog.coresystem.server.feature.RedisFeatureToggleService;
import dev.huntertagog.coresystem.server.friends.RedisFriendService;
import dev.huntertagog.coresystem.server.health.*;
import dev.huntertagog.coresystem.server.islands.*;
import dev.huntertagog.coresystem.server.metrics.MetricsEventListener;
import dev.huntertagog.coresystem.server.metrics.RedisMetricsService;
import dev.huntertagog.coresystem.server.net.RegionImageNetServer;
import dev.huntertagog.coresystem.server.permission.LuckPermsPermissionService;
import dev.huntertagog.coresystem.server.permission.PermissionCache;
import dev.huntertagog.coresystem.server.player.RedisPlayerProfileService;
import dev.huntertagog.coresystem.server.playerdata.RedisPlayerDataSyncService;
import dev.huntertagog.coresystem.server.protection.WorldProtectionBootstrap;
import dev.huntertagog.coresystem.server.protection.WorldProtectionService;
import dev.huntertagog.coresystem.server.redis.RedisClient;
import dev.huntertagog.coresystem.server.region.RedisRegionService;
import dev.huntertagog.coresystem.server.region.RegionGuardHooks;
import dev.huntertagog.coresystem.server.region.RegionPlayerTracker;
import dev.huntertagog.coresystem.server.region.visual.NetworkRegionOutlineService;
import dev.huntertagog.coresystem.server.settings.RedisPlayerSettingsService;
import dev.huntertagog.coresystem.server.task.CoreTaskScheduler;
import dev.huntertagog.coresystem.server.task.TaskScheduler;
import dev.huntertagog.coresystem.server.teleport.RedisTeleportManagerService;
import dev.huntertagog.coresystem.server.teleport.TeleportArrivalListener;
import dev.huntertagog.coresystem.server.world.structures.StructureSpawnService;
import net.fabricmc.api.DedicatedServerModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.network.ServerPlayerEntity;

import java.io.File;
import java.util.List;
import java.util.Objects;

/**
 * Läuft NUR auf Dedicated Server.
 * Hier darf Redis / LuckPerms / ServerLifecycle / Workers / ServerPlayConnectionEvents rein.
 */
public final class CoresystemServer implements DedicatedServerModInitializer {

    private static final Logger LOG = LoggerFactory.get("CoreSystem");

    // Island-Komponenten werden pro Server-Instanz gesetzt
    public static PrivateIslandWorldManager ISLAND_MANAGER;
    private static PrivateIslandWorldPrepareWorker ISLAND_PREPARE_WORKER;
    private static PrivateIslandWorldDeleteWorker ISLAND_DELETE_WORKER;
    private static TaskScheduler TASK_SCHEDULER;

    @Override
    public void onInitializeServer() {
        // Basis: Konfig-Verzeichnis (server-side)
        File configDir = new File(
                FabricLoader.getInstance().getConfigDir().toFile(),
                "coresystem"
        );

        // Player Lifecycle Listener (Profile Loading/Saving) -> Server only
        PlayerLifecycleListener.register();

        // Permissions
        ServiceProvider.registerService(PermissionService.class, new LuckPermsPermissionService());

        // Redis-backed Services (server only)
        MetricsService metricsService = new RedisMetricsService();
        ServiceProvider.registerService(MetricsService.class, metricsService);

        // Commands registrieren (Server)
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            CommandsProvider provider = ServiceProvider.getService(CommandsProvider.class);
            if (provider == null) {
                LOG.error("CommandsProvider not available during command registration.");
                return;
            }
            provider.registerAll(dispatcher, registryAccess, environment);
        });

        // Server STARTED: per-Server wiring
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            LOG.info("CoreSystem SERVER_STARTED initialisation...");

            if (!configDir.exists()) configDir.mkdirs();
            File mainConfig = new File(configDir, "config.json");

            ConfigService configService = new CompositeConfigService(List.of(
                    new FileConfigSource(mainConfig),
                    new SystemPropertyConfigSource(),
                    new EnvConfigSource("")
            ));
            ServiceProvider.registerService(ConfigService.class, configService);

            // Payload Codecs (C2S + S2C) – kann auch common sein, aber hier safe
            CoresystemNetworking.registerCommonPayloads();

            // Server Receiver
            FriendGuiServerNet.register();

            RegionImageNetServer.register();

            EconomyService economyService = new RedisEconomyService();
            ServiceProvider.registerService(EconomyService.class, economyService);
            ServiceProvider.registerService(PlayerWalletService.class, new DefaultPlayerWalletService(economyService));

            // Scheduler + EventBus
            TASK_SCHEDULER = new CoreTaskScheduler(server);
            ServiceProvider.registerService(TaskScheduler.class, TASK_SCHEDULER);
            ServiceProvider.registerService(DomainEventBus.class, new SimpleDomainEventBus(TASK_SCHEDULER));

            IslandOwnerSuggestionCache.refreshAsync(TASK_SCHEDULER);

            bootstrapModules(); // enthält RedisFeatureToggleService
            bootstrapHealth();  // enthält RedisHealthCheck
            bootstrapMetrics(); // listener wiring

            // Strukturen / Filesystem
            ServiceProvider.registerService(StructureSpawnService.class, new StructureSpawnService(configDir));

            // PlayerProfile
            ServiceProvider.registerService(PlayerProfileService.class, new RedisPlayerProfileService());
            ServiceProvider.registerService(PlayerDataSyncService.class, new RedisPlayerDataSyncService());

            // Audit
            ServiceProvider.registerService(AuditLogService.class, new RedisAuditLogService());

            // DevTools
            ServiceProvider.registerService(DevToolsService.class, new DefaultDevToolsService());

            // Teleport
            ServiceProvider.registerService(TeleportManagerService.class, new RedisTeleportManagerService());

            // RateLimiter
            ServiceProvider.registerService(RateLimitService.class, new InMemoryRateLimitService());

            // Settings
            ServiceProvider.registerService(PlayerSettingsService.class, new RedisPlayerSettingsService());

            // Nickname / Prefix / Filter
            ServiceProvider.registerService(PlayerNicknameService.class, new RedisPlayerNicknameService());
            ServiceProvider.registerService(NamePrefixResolver.class, new DefaultNamePrefixResolver());

            ServiceProvider.registerService(ChatFilterService.class, new RedisChatFilterService());
            ((RedisChatFilterService) Objects.requireNonNull(ServiceProvider.getService(ChatFilterService.class)))
                    .bootstrapDefaultBadWords();

            // Protection + Teleport Listener
            ServiceProvider.registerService(WorldProtectionService.class, new WorldProtectionService(server));
            WorldProtectionBootstrap.register(server);
            TeleportArrivalListener.register();

            // Regions
            ServiceProvider.registerService(RegionService.class, new RedisRegionService());
            RegionGuardHooks.register();
            RegionPlayerTracker.register(server);
            ServiceProvider.registerService(RegionOutlineService.class, new NetworkRegionOutlineService());

            // Social
            ServiceProvider.registerService(FriendService.class, new RedisFriendService());
            ServiceProvider.registerService(ClanService.class, new RedisClanService());

            // Islands
            int maxIslandsPerNode = configService.get(CoreConfigKeys.ISLANDS_MAX_PER_NODE);
            int maxPlayersPerIsland = configService.get(CoreConfigKeys.ISLANDS_MAX_PLAYERS_PER_ISLAND);

            PrivateIslandWorldService.get(server);

            PrivateIslandWorldManager.Config cfg = new PrivateIslandWorldManager.Config(
                    maxIslandsPerNode,
                    maxPlayersPerIsland
            );

            PrivateIslandWorldManager.init(server, cfg);
            ISLAND_MANAGER = PrivateIslandWorldManager.get(server);

            PrivateIslandWorldHeartbeatBootstrap.register(
                    server,
                    PrivateIslandWorldNodeConfig.SERVER_ID,
                    PrivateIslandWorldNodeConfig.SERVER_NAME,
                    cfg.maxIslandsPerNode(),
                    cfg.maxPlayersPerIsland()
            );
            PrivateIslandWorldCounterBootstrap.register();

            if (PrivateIslandWorldNodeConfig.IS_ISLAND_SERVER) {
                String nodeId = PrivateIslandWorldNodeConfig.SERVER_ID;

                var deleteWorker = new PrivateIslandWorldDeleteWorker(server, nodeId, TASK_SCHEDULER);
                var prepareWorker = new PrivateIslandWorldPrepareWorker(server, nodeId, TASK_SCHEDULER);

                ISLAND_DELETE_WORKER = deleteWorker;
                ISLAND_PREPARE_WORKER = prepareWorker;

                TASK_SCHEDULER.runSyncDelayed(deleteWorker::start, 1);
                TASK_SCHEDULER.runSyncDelayed(prepareWorker::start, 1);

                LOG.info("Island workers started on node '{}', maxIslands={}, maxPlayersPerIsland={}",
                        nodeId, cfg.maxIslandsPerNode(), cfg.maxPlayersPerIsland());
            } else {
                LOG.info("Node is not configured as Island-Server; island workers not started.");
            }
        });

        // Server STOPPING
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            LOG.info("CoreSystem SERVER_STOPPING – shutting down workers and scheduler...");

            if (ISLAND_PREPARE_WORKER != null) {
                LOG.info("Shutting down IslandPrepareWorker on node '{}'.", PrivateIslandWorldNodeConfig.SERVER_ID);
                ISLAND_PREPARE_WORKER.shutdown();
                ISLAND_PREPARE_WORKER = null;
            }

            if (ISLAND_DELETE_WORKER != null) {
                LOG.info("Shutting down IslandDeleteWorker on node '{}'.", PrivateIslandWorldNodeConfig.SERVER_ID);
                ISLAND_DELETE_WORKER.shutdown();
                ISLAND_DELETE_WORKER = null;
            }

            RedisClient.get().shutdown();

            TaskScheduler scheduler = ServiceProvider.getService(TaskScheduler.class);
            if (scheduler != null) scheduler.shutdown();
        });

        // DISCONNECT
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            PermissionCache.invalidate(handler.player);

            PlayerProfileService profileService = ServiceProvider.getService(PlayerProfileService.class);
            ConfigService cfg = ServiceProvider.getService(ConfigService.class);

            boolean profilesEnabled = cfg == null || cfg.get(CoreConfigKeys.PLAYER_PROFILE_ENABLED);

            if (profilesEnabled && profileService != null) {
                String currentServerName = server.getServerMotd();
                String nodeId = PrivateIslandWorldNodeConfig.SERVER_ID;

                if (currentServerName == null || currentServerName.isEmpty()) currentServerName = "unknown";
                profileService.updateOnQuit(handler.player, currentServerName, nodeId);
            }
        });

        // JOIN
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity player = handler.getPlayer();

            PlayerProfileService profileService = ServiceProvider.getService(PlayerProfileService.class);
            ConfigService cfg = ServiceProvider.getService(ConfigService.class);
            boolean profilesEnabled = cfg == null || cfg.get(CoreConfigKeys.PLAYER_PROFILE_ENABLED);

            if (profilesEnabled && profileService != null) {
                String currentServerName = server.getServerMotd();
                String nodeId = PrivateIslandWorldNodeConfig.SERVER_ID;

                if (currentServerName == null || currentServerName.isEmpty()) currentServerName = "unknown";
                profileService.updateOnJoin(player, currentServerName, nodeId);
            }

            if (!PrivateIslandWorldNodeConfig.IS_ISLAND_SERVER) return;

            TaskScheduler scheduler = ServiceProvider.getService(TaskScheduler.class);
            if (scheduler == null) {
                LOG.warn("TaskScheduler not available on player join; skipping auto-island teleport.");
                return;
            }

            PrivateIslandWorldManager manager = PrivateIslandWorldManager.get(server);

            var ownerId = player.getUuid();

            var targetKey = manager.islandWorldKey(ownerId);

            if (player.getWorld().getRegistryKey().equals(targetKey)) {
                // Already where we want to be → kein Teleport, kein Chunk-Stress
                return;
            }

            scheduler.runSyncDelayed(() -> {
                ServerPlayerEntity current = server.getPlayerManager().getPlayer(ownerId);
                if (current == null) return;

                // 1) Dedupe: nur einmal pro Session
                if (current.getCommandTags().contains("coresystem:island:autoJoined")) return;
                current.addCommandTag("coresystem:island:autoJoined");

                manager.getOrCreateIslandWorld(ownerId).whenComplete((islandWorld, throwable) -> {
                    if (throwable != null || islandWorld == null) {
                        LOG.warn("Failed to resolve island world for {} on join: {}",
                                ownerId, throwable != null ? throwable.getMessage() : "null world");
                        return;
                    }

                    scheduler.runSync(() -> {
                        // 2) Already in correct world → skip
                        if (current.getWorld().getRegistryKey().equals(islandWorld.getRegistryKey())) return;

                        manager.teleportPlayerToIslandWorld(current, islandWorld);
                    });
                });
            }, 20);
        });
    }

    // ------------------------------------------------------------------------
    // Health Monitor Bootstrap (server)
    // ------------------------------------------------------------------------
    private void bootstrapHealth() {
        HealthMonitorService monitor = new HealthMonitorService();
        ServiceProvider.registerService(HealthMonitorService.class, monitor);

        monitor.register(new RedisHealthCheck());
        monitor.register(new PlayerProfileHealthCheck());
        monitor.register(new EconomyHealthCheck());
        monitor.register(new ServiceRegistryHealthCheck());

        var results = monitor.runAll();
        var overall = monitor.aggregateStatus(results);

        LOG.info("Core health on startup: {}", overall);
        for (var r : results) {
            LOG.info("Health [{}]: status={} message={} details={}",
                    r.name(), r.status(), r.message(), r.details());
        }
    }

    // ------------------------------------------------------------------------
    // Metrics Event Listener Bootstrap (server)
    // ------------------------------------------------------------------------
    private void bootstrapMetrics() {
        MetricsService metrics = ServiceProvider.getService(MetricsService.class);
        if (metrics == null) {
            LOG.warn("MetricsService not available, skipping MetricsEventListener wiring.");
            return;
        }

        MetricsEventListener listener = new MetricsEventListener(metrics);
        listener.registerOnBus();
    }

    // ------------------------------------------------------------------------
    // Module Registry & Feature-Toggles (server)
    // ------------------------------------------------------------------------
    private void bootstrapModules() {
        DefaultModuleRegistryService moduleRegistry = new DefaultModuleRegistryService();
        ServiceProvider.registerService(ModuleRegistryService.class, moduleRegistry);

        moduleRegistry.registerModule(CoreModule.PLAYER_PROFILE, true, null);
        moduleRegistry.registerModule(CoreModule.ECONOMY, true, null);
        moduleRegistry.registerModule(CoreModule.ISLANDS, true, null);
        moduleRegistry.registerModule(CoreModule.MESSAGING, true, null);
        moduleRegistry.registerModule(CoreModule.METRICS, true, null);
        moduleRegistry.registerModule(CoreModule.AUDIT, true, null);
        moduleRegistry.registerModule(CoreModule.HEALTH, true, null);
        moduleRegistry.registerModule(CoreModule.DEVTOOLS, false, "Disabled by default");

        FeatureToggleService featureService = new RedisFeatureToggleService();
        ServiceProvider.registerService(FeatureToggleService.class, featureService);
    }
}
