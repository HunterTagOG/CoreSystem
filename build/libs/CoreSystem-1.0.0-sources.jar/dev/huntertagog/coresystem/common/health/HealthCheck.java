package dev.huntertagog.coresystem.common.health;

import dev.huntertagog.coresystem.common.provider.Service;
import dev.huntertagog.coresystem.server.health.HealthCheckResult;

public interface HealthCheck extends Service {

    /**
     * Eindeutige Kennung, z. B. "redis", "economy", "playerProfile".
     */
    String name();

    /**
     * Führt die Prüfung synchron durch.
     * Exceptions werden NICHT nach außen propagiert, sondern im Ergebnis abgebildet.
     */
    HealthCheckResult check();
}
