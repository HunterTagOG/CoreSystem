package dev.huntertagog.coresystem.common.health;

public enum HealthStatus {
    UP,         // alles ok
    DEGRADED,   // eingeschränkt funktionsfähig
    DOWN        // nicht nutzbar
}
