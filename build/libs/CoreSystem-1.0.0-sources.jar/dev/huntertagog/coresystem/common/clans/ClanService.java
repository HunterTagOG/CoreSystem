package dev.huntertagog.coresystem.common.clans;

import dev.huntertagog.coresystem.common.provider.Service;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface ClanService extends Service {

    Optional<Clan> findById(@NotNull UUID clanId);

    Optional<Clan> findByMember(@NotNull UUID playerId);

    Optional<Clan> findByTag(@NotNull String tag);

    Clan createClan(@NotNull UUID ownerId,
                    @NotNull String tag,
                    @NotNull String name);

    boolean disbandClan(@NotNull UUID clanId, @NotNull UUID requester);

    boolean inviteMember(@NotNull UUID clanId,
                         @NotNull UUID inviter,
                         @NotNull UUID target);

    boolean acceptInvite(@NotNull UUID clanId,
                         @NotNull UUID playerId);

    boolean kickMember(@NotNull UUID clanId,
                       @NotNull UUID requester,
                       @NotNull UUID target);

    boolean setRole(@NotNull UUID clanId,
                    @NotNull UUID requester,
                    @NotNull UUID target,
                    @NotNull ClanRole role);

    List<UUID> getMembers(@NotNull UUID clanId);

    /**
     * Für Island-/Region-Integration: darf Player "Management"-Aktionen für den Clan ausführen?
     */
    boolean canManageIsland(@NotNull UUID clanId, @NotNull UUID playerId);

    /**
     * Holt alle offenen Einladungen für den Spieler
     * und markiert sie als "zugestellt" / entfernt sie (je nach Design).
     */
    List<ClanInvite> pollPendingInvites(UUID memberId);
}
