package dev.huntertagog.coresystem.common.clans;

public enum ClanRole {
    OWNER,
    OFFICER,
    ADMIN,
    MEMBER
}
