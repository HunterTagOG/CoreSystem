package dev.huntertagog.coresystem.common.clans;

import java.util.UUID;

public record ClanMember(
        UUID playerId,
        dev.huntertagog.coresystem.common.clans.ClanRole role,
        long joinedAt
) {
}
