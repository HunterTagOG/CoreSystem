package dev.huntertagog.coresystem.common.clans.chat;

import dev.huntertagog.coresystem.common.provider.Service;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

public interface ClanChatService extends Service {

    boolean isClanChatEnabled(@NotNull UUID playerId);

    void setClanChatEnabled(@NotNull UUID playerId, boolean enabled);

    default boolean toggle(@NotNull UUID playerId) {
        boolean now = !isClanChatEnabled(playerId);
        setClanChatEnabled(playerId, now);
        return now;
    }
}
