package dev.huntertagog.coresystem.common.clans;

import lombok.Getter;
import lombok.Setter;

import java.util.UUID;

@Getter
@Setter
public class ClanInvite {

    public UUID clanId;
    public String clanName;
    public String clanTag;
    public UUID invitedPlayerId;
    public UUID inviterId;
    public String inviterName;
    public long createdAtEpochMillis;

    public ClanInvite(UUID clanId, String tag, String name) {
        this.clanId = clanId;
        this.clanName = name;
        this.clanTag = tag;
    }
}
