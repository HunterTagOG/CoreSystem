package dev.huntertagog.coresystem.common.error;

import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2561;

public final class CoreErrorUtil {

    private static final Logger LOG = LoggerFactory.get("CoreError");

    private CoreErrorUtil() {
    }

    /**
     * Sendet CoreError an Server/Spieler und loggt ihn sauber.
     */
    public static void notify(class_2168 src, CoreError error) {
        // 1) Logging auf Server-Seite
        if (error.cause() != null) {
            LOG.error(error.toLogString(), error.cause());
        } else {
            LOG.error(error.toLogString());
        }

        // 2) Spieler-Feedback
        // → technische Message NICHT ungefiltert zeigen
        // → aber ADMINS können optional zusätzliche Details sehen
        src.method_9213(
                class_2561.method_43470("[" + error.code() + "] ")
                        .method_27693(error.technicalMessage())
                        .method_27692(class_124.field_1061)
        );

        // Optional: Admin bekommt zusätzliche Debug-Infos
        if (Permissions.check(src, "coresystem.debug.error", false)) {
            src.method_9226(
                    () -> class_2561.method_43470("Context: " + error.context()).method_27692(class_124.field_1063),
                    false
            );
        }
    }

    public static void notifyServiceMissing(class_2168 src, String clanService, String clanCreate) {
        src.method_9213(
                class_2561.method_43470("Der Dienst \"" + clanService + "\" ist nicht verfügbar. " +
                                "Die Aktion \"" + clanCreate + "\" kann daher nicht ausgeführt werden.")
                        .method_27692(class_124.field_1061)
        );
    }
}
