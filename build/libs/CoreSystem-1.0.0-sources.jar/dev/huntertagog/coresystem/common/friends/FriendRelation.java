package dev.huntertagog.coresystem.common.friends;

import java.util.UUID;

public record FriendRelation(
        UUID self,
        UUID other,
        FriendRelationStatus status
) {
}
