package dev.huntertagog.coresystem.common.friends;

import dev.huntertagog.coresystem.common.provider.Service;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.UUID;

public interface FriendService extends Service {

    // Basis-Beziehung
    FriendRelation getRelation(@NotNull UUID self, @NotNull UUID other);

    List<UUID> getFriends(@NotNull UUID self);

    List<UUID> getIncomingRequests(@NotNull UUID self);

    List<UUID> getOutgoingRequests(@NotNull UUID self);

    boolean areFriends(@NotNull UUID a, @NotNull UUID b);

    // Requests
    boolean sendRequest(@NotNull UUID from, @NotNull UUID to);

    boolean acceptRequest(@NotNull UUID target, @NotNull UUID from);

    boolean denyRequest(@NotNull UUID target, @NotNull UUID from);

    boolean removeFriend(@NotNull UUID a, @NotNull UUID b);

    // Offline Messages
    void sendOfflineMessage(@NotNull OfflineFriendMessage message);

    /**
     * Holt alle ausstehenden Nachrichten und löscht sie aus der Queue.
     */
    List<OfflineFriendMessage> pollOfflineMessages(@NotNull UUID target);
}
