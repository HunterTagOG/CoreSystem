package dev.huntertagog.coresystem.common.region;

import net.minecraft.class_238;
import net.minecraft.class_2960;

public record RegionImageDef(
        String regionId,
        class_2960 worldId,

        class_238 bounds,                 // Weltkoordinaten
        RegionImageMode mode,       // WALL / FLOOR
        RegionImageFacing facing,   // NORTH/SOUTH/EAST/WEST
        int baseY,

        String textureId        // Client-Texture (NativeImageBackedTexture)
) {
}
