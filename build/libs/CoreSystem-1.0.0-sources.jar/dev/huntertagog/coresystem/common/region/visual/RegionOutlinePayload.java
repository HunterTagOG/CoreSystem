package dev.huntertagog.coresystem.common.region.visual;

import dev.huntertagog.coresystem.CoresystemCommon;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record RegionOutlinePayload(
        class_2960 worldId,
        class_2338 min,
        class_2338 max,
        int color,
        int durationTicks
) implements class_8710 {

    public static final class_9154<RegionOutlinePayload> TYPE =
            new class_9154<>(class_2960.method_60655(CoresystemCommon.MOD_ID, "region_outline"));

    // Codec beschreibt, wie der Payload kodiert/decodiert wird.
    public static final class_9139<class_9129, RegionOutlinePayload> CODEC =
            class_9139.method_56438(
                    (payload, buf) -> {
                        buf.method_10812(payload.worldId);
                        buf.method_10807(payload.min);
                        buf.method_10807(payload.max);
                        buf.method_53002(payload.color);
                        buf.method_10804(payload.durationTicks);
                    },
                    buf -> new RegionOutlinePayload(
                            buf.method_10810(),
                            buf.method_10811(),
                            buf.method_10811(),
                            buf.readInt(),
                            buf.method_10816()
                    )
            );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
