package dev.huntertagog.coresystem.common.region.visual;

import dev.huntertagog.coresystem.common.provider.Service;
import dev.huntertagog.coresystem.server.region.RegionDefinition;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public interface RegionOutlineService extends Service {

    void showSelection(class_3222 player,
                       class_2960 worldId,
                       class_2338 min,
                       class_2338 max,
                       int ticks);

    void showRegion(class_3222 player,
                    RegionDefinition region,
                    int ticks);

    /**
     * Bei der Netzwerk-Lösung no-op, aber fürs Interface konsistent.
     */
    void tick(class_3218 world);
}
