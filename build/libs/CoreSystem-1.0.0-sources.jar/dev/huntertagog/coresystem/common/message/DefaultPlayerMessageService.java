package dev.huntertagog.coresystem.common.message;

import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_5905;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class DefaultPlayerMessageService implements PlayerMessageService {

    private static final Logger LOG = LoggerFactory.get("PlayerMessageService");

    @Override
    public void send(@NotNull class_3222 player,
                     @NotNull PlayerNotification notification) {

        try {
            switch (notification.channel()) {
                case CHAT -> sendChatInternal(player, notification);
                case ACTION_BAR -> sendActionBarInternal(player, notification);
                case TITLE -> sendTitleInternal(player, notification);
                case SUBTITLE -> sendSubtitleInternal(player, notification);
                case SYSTEM -> sendSystemInternal(player, notification);
                case TOAST -> sendToastInternal(player, notification);
            }
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.PLAYER_MESSAGE_SEND_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to send player notification"
                    )
                    .withCause(e)
                    .withContextEntry("playerUuid", player.method_5845())
                    .withContextEntry("channel", notification.channel().name())
                    .withContextEntry("severity", notification.severity().name())
                    .withContextEntry("message", notification.message().getString())
                    .log();

            LOG.warn("Failed to send notification '{}' to player {} ({})",
                    notification.message().getString(),
                    player.method_7334().getName(),
                    player.method_5845());
        }
    }

    // ---------------- Chat ----------------

    private void sendChatInternal(class_3222 player, PlayerNotification n) {
        player.method_7353(applySeverityFormatting(n), false);
    }

    // ---------------- ActionBar ----------------

    private void sendActionBarInternal(class_3222 player, PlayerNotification n) {
        player.method_7353(applySeverityFormatting(n), true);
    }

    // ---------------- Title / Subtitle (simple Variante) ----------------

    private void sendTitleInternal(class_3222 player, PlayerNotification n) {
        class_2561 title = applySeverityFormatting(n);
        player.field_13987.method_14364(new class_5904(title));
    }

    private void sendSubtitleInternal(class_3222 player, PlayerNotification n) {
        class_2561 subtitle = applySeverityFormatting(n);
        player.field_13987.method_14364(new class_5903(subtitle));
    }

    @Override
    public void sendTitle(class_3222 player,
                          class_2561 title,
                          @Nullable class_2561 subtitle,
                          int fadeInTicks,
                          int stayTicks,
                          int fadeOutTicks) {
        try {
            player.field_13987.method_14364(new class_5905(fadeInTicks, stayTicks, fadeOutTicks));
            player.field_13987.method_14364(new class_5904(title));

            if (subtitle != null) {
                player.field_13987.method_14364(new class_5903(subtitle));
            }
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.PLAYER_MESSAGE_SEND_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to send title to player"
                    )
                    .withCause(e)
                    .withContextEntry("playerUuid", player.method_5845())
                    .withContextEntry("title", title.getString())
                    .withContextEntry("subtitle", subtitle != null ? subtitle.getString() : "null")
                    .log();
        }
    }

    // ---------------- System ----------------

    private void sendSystemInternal(class_3222 player, PlayerNotification n) {
        player.method_7353(applySeverityFormatting(n), false);
    }

    // ---------------- Toast (Server-Fallback) ----------------

    private void sendToastInternal(class_3222 player, PlayerNotification n) {
        // Aktuell: Chat-Toast-Emulation
        class_2561 base = n.message();

        class_2561 prefixed = switch (n.severity()) {
            case SUCCESS -> class_2561.method_43470("✔ ").method_27692(class_124.field_1060).method_10852(base);
            case WARNING -> class_2561.method_43470("⚠ ").method_27692(class_124.field_1054).method_10852(base);
            case ERROR -> class_2561.method_43470("✖ ").method_27692(class_124.field_1061).method_10852(base);
            case INFO -> class_2561.method_43470("• ").method_27692(class_124.field_1080).method_10852(base);
        };

        player.method_7353(prefixed, false);
    }

    // ---------------- Styling ----------------

    private class_2561 applySeverityFormatting(PlayerNotification n) {
        class_2561 base = n.message();

        // Du kannst hier gerne feiner aufsplitten, ich halte es bewusst simpel:
        return switch (n.severity()) {
            case SUCCESS -> base.method_27661().method_27692(class_124.field_1060);
            case WARNING -> base.method_27661().method_27692(class_124.field_1054);
            case ERROR -> base.method_27661().method_27692(class_124.field_1061);
            case INFO -> base.method_27661().method_27692(class_124.field_1080);
        };
    }
}
