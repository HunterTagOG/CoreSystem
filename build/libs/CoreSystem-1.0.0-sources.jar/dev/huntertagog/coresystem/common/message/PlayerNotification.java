package dev.huntertagog.coresystem.common.message;

import net.minecraft.class_2561;
import org.jetbrains.annotations.Nullable;

/**
 * @param message  bereits formatierter Klartext
 * @param debugKey optional: Key wie "player.welcome.firstJoin"
 */
public record PlayerNotification(MessageChannel channel, MessageSeverity severity, class_2561 message,
                                 @Nullable class_2561 debugKey) {

    // --- Chat-Shortcuts ---
    public static PlayerNotification chatInfo(class_2561 message) {
        return new PlayerNotification(MessageChannel.CHAT, MessageSeverity.INFO, message, null);
    }

    public static PlayerNotification chatSuccess(class_2561 message) {
        return new PlayerNotification(MessageChannel.CHAT, MessageSeverity.SUCCESS, message, null);
    }

    public static PlayerNotification chatWarn(class_2561 message) {
        return new PlayerNotification(MessageChannel.CHAT, MessageSeverity.WARNING, message, null);
    }

    public static PlayerNotification chatError(class_2561 message) {
        return new PlayerNotification(MessageChannel.CHAT, MessageSeverity.ERROR, message, null);
    }

    // --- ActionBar-Shortcuts ---
    public static PlayerNotification actionBarInfo(class_2561 message) {
        return new PlayerNotification(MessageChannel.ACTION_BAR, MessageSeverity.INFO, message, null);
    }

    public static PlayerNotification actionBarSuccess(class_2561 message) {
        return new PlayerNotification(MessageChannel.ACTION_BAR, MessageSeverity.SUCCESS, message, null);
    }

    public static PlayerNotification actionBarWarn(class_2561 message) {
        return new PlayerNotification(MessageChannel.ACTION_BAR, MessageSeverity.WARNING, message, null);
    }

    public static PlayerNotification actionBarError(class_2561 message) {
        return new PlayerNotification(MessageChannel.ACTION_BAR, MessageSeverity.ERROR, message, null);
    }

    // --- Toast-Shortcuts (Server-seitig nur semantisch, Implementation entscheidet) ---
    public static PlayerNotification toastInfo(class_2561 message) {
        return new PlayerNotification(MessageChannel.TOAST, MessageSeverity.INFO, message, null);
    }

    public static PlayerNotification toastSuccess(class_2561 message) {
        return new PlayerNotification(MessageChannel.TOAST, MessageSeverity.SUCCESS, message, null);
    }

    public static PlayerNotification toastWarn(class_2561 message) {
        return new PlayerNotification(MessageChannel.TOAST, MessageSeverity.WARNING, message, null);
    }

    public static PlayerNotification toastError(class_2561 message) {
        return new PlayerNotification(MessageChannel.TOAST, MessageSeverity.ERROR, message, null);
    }

    // -- -- Withers ---
    public PlayerNotification withDebugKey(class_2561 debugKey) {
        return new PlayerNotification(this.channel, this.severity, this.message, debugKey);
    }
}
