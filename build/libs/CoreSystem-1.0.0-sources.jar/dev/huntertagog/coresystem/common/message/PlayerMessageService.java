package dev.huntertagog.coresystem.common.message;

import dev.huntertagog.coresystem.common.provider.Service;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface PlayerMessageService extends Service {

    void send(@NotNull class_3222 player, @NotNull PlayerNotification notification);

    // ---------------- Chat ----------------

    default void sendInfoChat(class_3222 player, class_2561 message) {
        send(player, PlayerNotification.chatInfo(message));
    }

    default void sendSuccessChat(class_3222 player, class_2561 message) {
        send(player, PlayerNotification.chatSuccess(message));
    }

    default void sendWarnChat(class_3222 player, class_2561 message) {
        send(player, PlayerNotification.chatWarn(message));
    }

    default void sendErrorChat(class_3222 player, class_2561 message) {
        send(player, PlayerNotification.chatError(message));
    }

    // ---------------- ActionBar ----------------

    default void sendInfoActionBar(class_3222 player, class_2561 message) {
        send(player, PlayerNotification.actionBarInfo(message));
    }

    default void sendSuccessActionBar(class_3222 player, class_2561 message) {
        send(player, PlayerNotification.actionBarSuccess(message));
    }

    default void sendWarnActionBar(class_3222 player, class_2561 message) {
        send(player, PlayerNotification.actionBarWarn(message));
    }

    default void sendErrorActionBar(class_3222 player, class_2561 message) {
        send(player, PlayerNotification.actionBarError(message));
    }

    // ---------------- Title / Subtitle ----------------
    //
    // Times in Ticks (20 = 1 Sekunde)

    default void sendTitle(class_3222 player,
                           class_2561 title,
                           @Nullable class_2561 subtitle,
                           int fadeInTicks,
                           int stayTicks,
                           int fadeOutTicks) {
        // Basis-Impl. wird in DefaultPlayerMessageService überschrieben;
        // Fallback: wir mappen Titel+Subtitle in eine Chat-Nachricht

        class_2561 combined = subtitle != null
                ? class_2561.method_43473().method_10852(title).method_10852(class_2561.method_43470(" - ")).method_10852(subtitle)
                : title;

        sendInfoChat(player, combined);
    }

    default void sendTitleInfo(class_3222 player,
                               class_2561 title,
                               @Nullable class_2561 subtitle,
                               int fadeInTicks,
                               int stayTicks,
                               int fadeOutTicks) {
        sendTitle(player, title, subtitle, fadeInTicks, stayTicks, fadeOutTicks);
    }

    // ---------------- Toasts ----------------
    //
    // Standard-Server hat keine echten Custom-Server-Toasts.
    // Implementierung entscheidet, wie TOAST-Channel dargestellt wird.

    default void sendToastInfo(class_3222 player, class_2561 title, @Nullable class_2561 description) {
        send(player, PlayerNotification.toastInfo(buildToastMessage(title, description)));
    }

    default void sendToastSuccess(class_3222 player, class_2561 title, @Nullable class_2561 description) {
        send(player, PlayerNotification.toastSuccess(buildToastMessage(title, description)));
    }

    default void sendToastWarn(class_3222 player, class_2561 title, @Nullable class_2561 description) {
        send(player, PlayerNotification.toastWarn(buildToastMessage(title, description)));
    }

    default void sendToastError(class_3222 player, class_2561 title, @Nullable class_2561 description) {
        send(player, PlayerNotification.toastError(buildToastMessage(title, description)));
    }

    private static class_2561 buildToastMessage(class_2561 title, @Nullable class_2561 description) {
        if (description == null || description.getString().isBlank()) {
            return title;
        }

        // Text-API nutzen statt String-Concats:
        return class_2561.method_43473()
                .method_10852(title)
                .method_10852(class_2561.method_43470(" §7- "))
                .method_10852(description);
    }
}
