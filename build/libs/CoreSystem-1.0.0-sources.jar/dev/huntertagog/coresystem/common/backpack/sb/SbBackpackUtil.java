package dev.huntertagog.coresystem.common.backpack.sb;

import net.minecraft.class_1799;
import net.minecraft.class_3222;
import net.p3pp3rf1y.sophisticatedbackpacks.backpack.wrapper.BackpackWrapper;
import net.p3pp3rf1y.sophisticatedbackpacks.backpack.wrapper.IBackpackWrapper;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class SbBackpackUtil {

    private SbBackpackUtil() {
    }

    public static List<UUID> getCarriedBackpackUUIDs(class_3222 player) {
        List<class_1799> stacks = new ArrayList<>();
        stacks.addAll(player.method_31548().field_7547);
        stacks.addAll(player.method_31548().field_7548);
        stacks.addAll(player.method_31548().field_7544);

        List<UUID> out = new ArrayList<>();
        for (class_1799 stack : stacks) {
            if (stack == null || stack.method_7960()) {
                continue;
            }

            IBackpackWrapper wrapper = BackpackWrapper.fromStack(stack);
            if (wrapper == null) {
                continue;
            }

            // TODO: Implementiere hier deine Uuid.getFromWrapper(wrapper)-Logik
            // aus deinem FastSwitch-Plugin (Reflection / Accessor).
            SbBackpackUuidUtil.getFromWrapper(wrapper).ifPresent(out::add);
        }
        return out;
    }
}
