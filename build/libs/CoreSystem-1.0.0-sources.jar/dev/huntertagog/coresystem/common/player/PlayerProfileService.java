package dev.huntertagog.coresystem.common.player;

import dev.huntertagog.coresystem.common.provider.Service;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_3222;

public interface PlayerProfileService extends Service {

    @NotNull
    PlayerProfile getOrCreate(@NotNull UUID uniqueId, @Nullable String fallbackName);

    @NotNull
    default PlayerProfile getOrCreate(@NotNull class_3222 player) {
        return getOrCreate(player.method_5667(), player.method_7334().getName());
    }

    @NotNull
    Optional<PlayerProfile> find(@NotNull UUID uniqueId);

    PlayerProfile updateOnJoin(@NotNull class_3222 player, @NotNull String currentServerName, @Nullable String nodeId);

    Optional<PlayerProfile> updateOnQuit(@NotNull class_3222 player, @NotNull String currentServerName, @Nullable String nodeId);
}
