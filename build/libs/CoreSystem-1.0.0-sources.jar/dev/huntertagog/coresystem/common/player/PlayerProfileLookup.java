package dev.huntertagog.coresystem.common.player;

import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.UUID;

public final class PlayerProfileLookup {

    private PlayerProfileLookup() {
    }

    public record LastLocation(@NotNull String lastServer,
                               @Nullable String lastNodeId) {
    }

    public static Optional<LastLocation> lastLocation(@NotNull UUID playerId) {
        PlayerProfileService svc = ServiceProvider.getService(PlayerProfileService.class);
        if (svc == null) return Optional.empty();

        return svc.find(playerId)
                .map(p -> new LastLocation(
                        p.getLastServer() != null ? p.getLastServer() : "unknown",
                        p.getLastNodeId()
                ));
    }
}
