package dev.huntertagog.coresystem.common.player;

import lombok.Getter;
import lombok.Setter;

import java.util.UUID;

@Getter
@Setter
public class PlayerProfile {

    public UUID uniqueId;
    public String name;
    public long firstSeenAt;   // epoch millis
    public long lastSeenAt;    // epoch millis
    public int totalJoins;
    public String lastServer;  // z.B. "lobby", "islands-1"
    public String lastNodeId;

    public PlayerProfile(UUID uniqueId, String name, long firstSeenAt, long lastSeenAt, int totalJoins, String lastServer, String lastNodeId) {
        this.uniqueId = uniqueId;
        this.name = name;
        this.firstSeenAt = firstSeenAt;
        this.lastSeenAt = lastSeenAt;
        this.totalJoins = totalJoins;
        this.lastServer = lastServer;
        this.lastNodeId = lastNodeId;
    }

    public static PlayerProfile newEphemeral(UUID uniqueId, String safeName, long now) {
        return new PlayerProfile(
                uniqueId,
                safeName,
                now,
                now,
                0,
                "unknown",
                "unknown"
        );
    }

    public PlayerProfile withUpdatedOnJoin(String newName, String serverName, String nodeId, long nowMillis) {
        int updatedJoins = totalJoins <= 0 ? 1 : totalJoins + 1;

        long firstSeen = firstSeenAt > 0 ? firstSeenAt : nowMillis;

        return new PlayerProfile(
                uniqueId,
                newName,
                firstSeen,
                nowMillis,
                updatedJoins,
                serverName,
                nodeId
        );
    }

    public PlayerProfile withUpdatedLastSeen(long nowMillis, String serverName, String nodeId) {
        return new PlayerProfile(
                uniqueId,
                name,
                firstSeenAt > 0 ? firstSeenAt : nowMillis,
                nowMillis,
                totalJoins,
                serverName,
                nodeId
        );
    }
}

