package dev.huntertagog.coresystem.common.player.gui;

import dev.huntertagog.coresystem.common.gui.GuiBuilder;
import dev.huntertagog.coresystem.common.gui.GuiItem;
import dev.huntertagog.coresystem.common.item.ItemBuilder;
import dev.huntertagog.coresystem.common.player.PlayerContext;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public final class PlayerProfileMenuFactory {

    private static final DateTimeFormatter DATE_TIME_FORMATTER =
            DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss")
                    .withZone(ZoneId.systemDefault());

    private PlayerProfileMenuFactory() {
    }

    public static void openProfile(class_3222 player, PlayerContext ctx) {
        var profile = ctx.profile();

        class_2561 title = class_2561.method_43470("Dein Profil");

        // Kopf-Item mit Basisdaten
        var headItem = ItemBuilder.of(class_1802.field_8575)
                .name(class_2561.method_43470("§a" + profile.getName()))
                .loreLine(class_2561.method_43470("§7UUID: §f" + profile.getUniqueId()))
                .loreLine(class_2561.method_43470("§7Erster Login: §f" + formatTimestamp(profile.getFirstSeenAt())))
                .loreLine(class_2561.method_43470("§7Letzter Login: §f" + formatTimestamp(profile.getLastSeenAt())))
                .loreLine(class_2561.method_43470("§7Joins gesamt: §f" + profile.getTotalJoins()))
                .loreLine(class_2561.method_43470("§7Letzter Server: §f" + profile.getLastServer()))
                .loreLine(class_2561.method_43470("§7Letzter Node: §f" + String.valueOf(profile.getLastNodeId())))
                .build();

        // Placeholder-Glass
        var filler = GuiItem.of(
                ItemBuilder.of(class_1802.field_8871)
                        .name(class_2561.method_43470(" "))
                        .build()
        );

        GuiBuilder builder = GuiBuilder.chestRows(3)
                .title(title)
                .fillAll(filler)
                .item(13, GuiItem.of(headItem)); // mittlerer Slot (3x9 -> Index 13)

        builder.open(player);
    }

    private static String formatTimestamp(long millis) {
        if (millis <= 0L) return "-";
        return DATE_TIME_FORMATTER.format(Instant.ofEpochMilli(millis));
    }
}
