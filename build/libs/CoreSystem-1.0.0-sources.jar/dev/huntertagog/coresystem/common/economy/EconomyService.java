package dev.huntertagog.coresystem.common.economy;

import dev.huntertagog.coresystem.common.provider.Service;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * Zentrale Schnittstelle für Account-basierte Währungen im Netzwerk.
 * Backend (Redis, SQL, Mongo, ...) ist austauschbar.
 */
public interface EconomyService extends Service {

    /**
     * Liefert den aktuellen Kontostand für Account + Currency.
     * Bei technischen Fehlern sollte ein Fallback (z. B. 0) zurückkommen und
     * der Fehler über CoreError telemetriert werden.
     */
    @NotNull
    Money getBalance(@NotNull UUID accountId, @NotNull CurrencyId currencyId);

    /**
     * Schneller Check, ob Account >= amount hat.
     * Default-Impl. kann auf getBalance basieren.
     */
    default boolean hasBalance(@NotNull UUID accountId,
                               @NotNull Money amount) {
        Money current = getBalance(accountId, amount.currency());
        return current.gte(amount);
    }

    /**
     * Erhöht Guthaben um delta (delta > 0).
     * Gibt neuen Kontostand zurück.
     */
    @NotNull
    Money deposit(@NotNull UUID accountId, @NotNull Money delta, @Nullable String reason);

    /**
     * Verringert Guthaben um delta (delta > 0).
     * Gibt neuen Kontostand zurück.
     * Wirft oder signalisiert Fehler, wenn nicht genügend Guthaben vorhanden ist.
     */
    @NotNull
    EconomyTransactionResult withdraw(@NotNull UUID accountId, @NotNull Money delta, @Nullable String reason);

    /**
     * Transfer von einem Account auf einen anderen (atomar per Backend).
     */
    @NotNull
    EconomyTransactionResult transfer(@NotNull UUID sourceAccountId,
                                      @NotNull UUID targetAccountId,
                                      @NotNull Money delta,
                                      @Nullable String reason);
}
