package dev.huntertagog.coresystem.common.economy;

import org.jetbrains.annotations.NotNull;

import java.util.UUID;

public record DefaultPlayerWalletService(EconomyService delegate) implements PlayerWalletService {

    @Override
    public @NotNull Money getBalance(@NotNull UUID playerId) {
        return delegate.getBalance(playerId, DEFAULT_CURRENCY);
    }

    @Override
    public boolean hasAtLeast(@NotNull UUID playerId, long amount) {
        return delegate.hasBalance(playerId, Money.of(DEFAULT_CURRENCY, amount));
    }

    @Override
    public @NotNull Money deposit(@NotNull UUID playerId, long amount, String reason) {
        return delegate.deposit(playerId, Money.of(DEFAULT_CURRENCY, amount), reason);
    }

    @Override
    public @NotNull EconomyTransactionResult withdraw(@NotNull UUID playerId, long amount, String reason) {
        return delegate.withdraw(playerId, Money.of(DEFAULT_CURRENCY, amount), reason);
    }
}
