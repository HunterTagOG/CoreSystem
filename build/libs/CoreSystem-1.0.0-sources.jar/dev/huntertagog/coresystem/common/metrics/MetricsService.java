package dev.huntertagog.coresystem.common.metrics;

import dev.huntertagog.coresystem.common.provider.Service;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Map;

public interface MetricsService extends Service {

    /**
     * Erhöht einen Counter atomar um delta (default 1).
     */
    default void incrementCounter(@NotNull String name) {
        incrementCounter(name, 1L, null);
    }

    void incrementCounter(@NotNull String name, long delta, @Nullable Map<String, String> tags);

    /**
     * Setzt einen Gauge (z. B. aktuelle Player-Anzahl, TPS-Snapshot).
     */
    void setGauge(@NotNull String name, long value, @Nullable Map<String, String> tags);

    /**
     * Timer-Metrik – Laufzeit in Millisekunden.
     * Kann optional auf Durchschnitt / P50 / P95 etc. aggregiert werden (später).
     */
    void recordTimer(@NotNull String name, long durationMillis, @Nullable Map<String, String> tags);
}
