package dev.huntertagog.coresystem.common.config;

import org.jetbrains.annotations.NotNull;

public final class ConfigKey<T> {

    private final String path;          // z.B. "islands.max_islands_per_node"
    private final ConfigValueType type; // STRING, INT, BOOLEAN, ...
    private final T defaultValue;

    private ConfigKey(String path, ConfigValueType type, T defaultValue) {
        this.path = path;
        this.type = type;
        this.defaultValue = defaultValue;
    }

    public static ConfigKey<String> string(@NotNull String path, String defaultValue) {
        return new ConfigKey<>(path, ConfigValueType.STRING, defaultValue);
    }

    public static ConfigKey<Integer> integer(@NotNull String path, int defaultValue) {
        return new ConfigKey<>(path, ConfigValueType.INT, defaultValue);
    }

    public static ConfigKey<Boolean> bool(@NotNull String path, boolean defaultValue) {
        return new ConfigKey<>(path, ConfigValueType.BOOLEAN, defaultValue);
    }

    public static ConfigKey<Long> longKey(@NotNull String path, long defaultValue) {
        return new ConfigKey<>(path, ConfigValueType.LONG, defaultValue);
    }

    public String path() {
        return path;
    }

    public ConfigValueType type() {
        return type;
    }

    public T defaultValue() {
        return defaultValue;
    }
}

