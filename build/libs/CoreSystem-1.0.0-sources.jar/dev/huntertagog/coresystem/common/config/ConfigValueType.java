package dev.huntertagog.coresystem.common.config;

public enum ConfigValueType {
    STRING,
    INT,
    LONG,
    BOOLEAN,
    DOUBLE
}

