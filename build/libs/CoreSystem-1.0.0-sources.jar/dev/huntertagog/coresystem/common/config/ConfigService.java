package dev.huntertagog.coresystem.common.config;

import dev.huntertagog.coresystem.common.provider.Service;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public interface ConfigService extends Service {

    <T> @NotNull T get(@NotNull ConfigKey<T> key);

    <T> @Nullable T getOrNull(@NotNull ConfigKey<T> key);

    <T> @NotNull Optional<T> getOptional(@NotNull ConfigKey<T> key);
}

