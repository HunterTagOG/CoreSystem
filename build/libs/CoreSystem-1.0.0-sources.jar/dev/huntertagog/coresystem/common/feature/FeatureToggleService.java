package dev.huntertagog.coresystem.common.feature;

import dev.huntertagog.coresystem.common.provider.Service;
import org.jetbrains.annotations.NotNull;

public interface FeatureToggleService extends Service {

    /**
     * Prüft, ob ein Feature aktiv ist.
     */
    boolean isEnabled(@NotNull FeatureToggleKey key);

    /**
     * Optional: lokale Override-API (z. B. Admin-Tools später).
     */
    void setOverride(@NotNull FeatureToggleKey key, Boolean enabled);
}
