package dev.huntertagog.coresystem.common.audit;

import dev.huntertagog.coresystem.common.provider.Service;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.UUID;
import net.minecraft.class_2168;
import net.minecraft.class_3222;

public interface AuditLogService extends Service {

    void log(@NotNull AuditLogEntry entry);

    // Convenience: Command-Logging
    default void logCommand(@NotNull class_2168 source,
                            @NotNull String action,
                            @Nullable Map<String, String> details) {

        AuditLogEntry.ActorType actorType;
        UUID actorUuid = null;
        String actorName;

        if (source.method_9228() instanceof class_3222 player) {
            actorType = AuditLogEntry.ActorType.PLAYER;
            actorUuid = player.method_5667();
            actorName = player.method_7334().getName();
        } else if (source.method_9214().equalsIgnoreCase("Server")) {
            actorType = AuditLogEntry.ActorType.CONSOLE;
            actorName = "CONSOLE";
        } else {
            actorType = AuditLogEntry.ActorType.SYSTEM;
            actorName = source.method_9214();
        }

        String serverName = source.method_9211().method_3818(); // oder ENV / Config
        String nodeId = System.getenv().getOrDefault("CORESYSTEM_NODE_ID", "unknown-node");

        AuditLogEntry entry = new AuditLogEntry(
                java.util.UUID.randomUUID().toString(),
                System.currentTimeMillis(),
                actorType,
                actorUuid,
                actorName,
                AuditActionType.COMMAND_EXECUTED,
                action,
                AuditLogEntry.TargetType.SERVER,
                serverName,
                serverName,
                nodeId,
                details != null ? details : Map.of()
        );

        log(entry);
    }

    // Convenience: Economy-Transaction
    default void logEconomyTransaction(@NotNull UUID accountId,
                                       @Nullable String playerName,
                                       @NotNull String operation,
                                       @NotNull String currency,
                                       long amount,
                                       @NotNull String status,
                                       @Nullable String reason,
                                       @Nullable Map<String, String> extraDetails) {

        String serverName = System.getenv().getOrDefault("SERVER_NAME", "unknown");
        String nodeId = System.getenv().getOrDefault("SERVER_ID", "unknown-node");

        AuditLogEntry.ActorType actorType = AuditLogEntry.ActorType.PLAYER;

        Map<String, String> details = new java.util.HashMap<>();
        details.put("currency", currency);
        details.put("amount", String.valueOf(amount));
        details.put("status", status);
        if (reason != null) {
            details.put("reason", reason);
        }
        if (extraDetails != null) {
            details.putAll(extraDetails);
        }

        AuditLogEntry entry = new AuditLogEntry(
                java.util.UUID.randomUUID().toString(),
                System.currentTimeMillis(),
                actorType,
                accountId,
                playerName,
                AuditActionType.ECONOMY_TRANSACTION,
                operation,
                AuditLogEntry.TargetType.ECONOMY_ACCOUNT,
                accountId.toString(),
                serverName,
                nodeId,
                details
        );

        log(entry);
    }
}
