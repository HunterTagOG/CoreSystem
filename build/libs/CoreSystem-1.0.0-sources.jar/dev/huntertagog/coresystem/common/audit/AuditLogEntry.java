package dev.huntertagog.coresystem.common.audit;

import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.Map;
import java.util.UUID;

public final class AuditLogEntry {

    public enum ActorType {
        PLAYER,
        CONSOLE,
        SYSTEM
    }

    public enum TargetType {
        PLAYER,
        ISLAND,
        SERVER,
        NODE,
        ECONOMY_ACCOUNT,
        OTHER
    }

    private final String id;                // UUID als String
    private final long timestamp;          // epoch millis

    private final ActorType actorType;
    private final @Nullable UUID actorUuid;
    private final @Nullable String actorName;

    private final AuditActionType actionType;
    private final String action;           // z.B. "cs structures reload", "economy.withdraw"

    private final TargetType targetType;
    private final @Nullable String targetId;   // z.B. Player-UUID, Island-ID, Account-ID

    private final String serverName;
    private final String nodeId;

    private final Map<String, String> details; // zusätzliche Schlüssel/Werte

    public AuditLogEntry(String id,
                         long timestamp,
                         ActorType actorType,
                         @Nullable UUID actorUuid,
                         @Nullable String actorName,
                         AuditActionType actionType,
                         String action,
                         TargetType targetType,
                         @Nullable String targetId,
                         String serverName,
                         String nodeId,
                         Map<String, String> details) {
        this.id = id;
        this.timestamp = timestamp;
        this.actorType = actorType;
        this.actorUuid = actorUuid;
        this.actorName = actorName;
        this.actionType = actionType;
        this.action = action;
        this.targetType = targetType;
        this.targetId = targetId;
        this.serverName = serverName;
        this.nodeId = nodeId;
        this.details = details != null ? Collections.unmodifiableMap(details) : Collections.emptyMap();
    }

    public String id() {
        return id;
    }

    public long timestamp() {
        return timestamp;
    }

    public ActorType actorType() {
        return actorType;
    }

    public @Nullable UUID actorUuid() {
        return actorUuid;
    }

    public @Nullable String actorName() {
        return actorName;
    }

    public AuditActionType actionType() {
        return actionType;
    }

    public String action() {
        return action;
    }

    public TargetType targetType() {
        return targetType;
    }

    public @Nullable String targetId() {
        return targetId;
    }

    public String serverName() {
        return serverName;
    }

    public String nodeId() {
        return nodeId;
    }

    public Map<String, String> details() {
        return details;
    }
}
