package dev.huntertagog.coresystem.common.audit;

public enum AuditActionType {
    COMMAND_EXECUTED,
    ECONOMY_TRANSACTION,
    PERMISSION_CHANGED,
    PLAYER_PUNISHMENT,
    ISLAND_OPERATION,
    SYSTEM_MAINTENANCE,
    OTHER
}
