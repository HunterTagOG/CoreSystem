package dev.huntertagog.coresystem.common.gui;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1277;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_3917;

public final class GuiBuilder {

    private final int rows; // 1–6
    private class_2561 title;
    private final Map<Integer, GuiItem> items = new HashMap<>();

    private GuiBuilder(int rows) {
        if (rows < 1 || rows > 6) {
            throw new IllegalArgumentException("Rows must be between 1 and 6");
        }
        this.rows = rows;
        this.title = class_2561.method_43470("Menu");
    }

    public static GuiBuilder chestRows(int rows) {
        return new GuiBuilder(rows);
    }

    public GuiBuilder title(class_2561 title) {
        this.title = title;
        return this;
    }

    public GuiBuilder item(int slot, GuiItem guiItem) {
        if (slot < 0 || slot >= rows * 9) {
            throw new IllegalArgumentException("Slot out of bounds for " + rows + " rows: " + slot);
        }
        this.items.put(slot, guiItem);
        return this;
    }

    public GuiBuilder fillRow(int rowIndex, GuiItem guiItem) {
        if (rowIndex < 0 || rowIndex >= rows) {
            throw new IllegalArgumentException("Row index out of bounds: " + rowIndex);
        }
        int start = rowIndex * 9;
        for (int i = 0; i < 9; i++) {
            this.items.put(start + i, guiItem);
        }
        return this;
    }

    public GuiBuilder fillAll(GuiItem guiItem) {
        int size = rows * 9;
        for (int i = 0; i < size; i++) {
            this.items.put(i, guiItem);
        }
        return this;
    }

    public void open(class_3222 player) {
        int size = rows * 9;
        class_1277 inventory = new class_1277(size);

        // Items eintragen
        this.items.forEach((slot, guiItem) -> {
            if (slot >= 0 && slot < size) {
                inventory.method_5447(slot, guiItem.itemStack().method_7972());
            }
        });

        class_3908 factory = new class_3908() {

            @Override
            public class_2561 method_5476() {
                return title;
            }

            @Override
            public class_1703 createMenu(int syncId,
                                            class_1661 playerInventory,
                                            net.minecraft.class_1657 playerEntity) {

                class_3917<class_1707> type = switch (rows) {
                    case 1 -> class_3917.field_18664;
                    case 2 -> class_3917.field_18665;
                    case 3 -> class_3917.field_17326;
                    case 4 -> class_3917.field_18666;
                    case 5 -> class_3917.field_18667;
                    case 6 -> class_3917.field_17327;
                    default -> throw new IllegalStateException("Unexpected rows: " + rows);
                };

                return new class_1707(type, syncId, playerInventory, inventory, rows);
            }
        };

        player.method_17355(factory);
    }
}
