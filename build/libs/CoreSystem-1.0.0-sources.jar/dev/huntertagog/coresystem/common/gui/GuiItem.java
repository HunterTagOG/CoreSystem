package dev.huntertagog.coresystem.common.gui;

import net.minecraft.class_1799;

public final class GuiItem {

    private final class_1799 itemStack;

    public GuiItem(class_1799 itemStack) {
        this.itemStack = itemStack;
    }

    public class_1799 itemStack() {
        return itemStack;
    }

    public static GuiItem of(class_1799 stack) {
        return new GuiItem(stack);
    }
}
