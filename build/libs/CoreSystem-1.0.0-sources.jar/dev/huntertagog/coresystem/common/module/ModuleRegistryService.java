package dev.huntertagog.coresystem.common.module;

import dev.huntertagog.coresystem.common.provider.Service;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;

public interface ModuleRegistryService extends Service {

    /**
     * Registriert ein Modul mit einem Default-Enabled-Status.
     * Environment Overrides werden direkt berücksichtigt.
     */
    void registerModule(@NotNull CoreModule module, boolean enabledByDefault, @Nullable String reasonIfDisabled);

    /**
     * Setzt Status explizit (Server-Local).
     */
    void setModuleEnabled(@NotNull CoreModule module, boolean enabled, @Nullable String reason);

    /**
     * Liest aktuellen Status.
     */
    @NotNull ModuleState getState(@NotNull CoreModule module);

    /**
     * Shortcut.
     */
    default boolean isEnabled(@NotNull CoreModule module) {
        return getState(module).enabled();
    }

    /**
     * Alle registrierten Module.
     */
    @NotNull Collection<ModuleState> getAllStates();
}
