package dev.huntertagog.coresystem.common.module;

import org.jetbrains.annotations.Nullable;

/**
 * Zustand eines Moduls – ob es aktiv ist und warum (optional).
 */
public final class ModuleState {

    private final CoreModule module;
    private final boolean enabled;
    private final @Nullable String reason;

    public ModuleState(CoreModule module, boolean enabled, @Nullable String reason) {
        this.module = module;
        this.enabled = enabled;
        this.reason = reason;
    }

    public CoreModule module() {
        return module;
    }

    public boolean enabled() {
        return enabled;
    }

    public @Nullable String reason() {
        return reason;
    }

    public ModuleState withEnabled(boolean enabled, @Nullable String reason) {
        return new ModuleState(this.module, enabled, reason);
    }
}
