package dev.huntertagog.coresystem.common.chat;

import dev.huntertagog.coresystem.common.provider.Service;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Nullable;

public interface NamePrefixResolver extends Service {

    /**
     * Liefert einen Prefix-Text (z. B. "[Admin] ") oder null, wenn kein Prefix angezeigt werden soll.
     */
    @Nullable
    class_2561 resolvePrefix(class_3222 player);
}
