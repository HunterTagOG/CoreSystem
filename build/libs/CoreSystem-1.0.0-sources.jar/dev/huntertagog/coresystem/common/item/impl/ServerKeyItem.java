package dev.huntertagog.coresystem.common.item.impl;

import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.common.model.ServerTarget;
import dev.huntertagog.coresystem.common.model.ServerTargets;
import dev.huntertagog.coresystem.server.net.ServerSwitcherNetworking;
import dev.huntertagog.coresystem.server.permission.PermissionCache;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.SingletonGeoAnimatable;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class ServerKeyItem extends class_1792 implements GeoItem {

    private static final Logger LOG = LoggerFactory.get("ServerKeyItem");

    private static final RawAnimation IDLE =
            RawAnimation.begin().thenLoop("animation.model.crystal");

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public ServerKeyItem(class_1793 settings) {
        super(settings);
        // sorgt für serverseitiges Syncing der Animationen
        SingletonGeoAnimatable.registerSyncedAnimatable(this);
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 type) {
        tooltip.add(class_2561.method_43471("item.coresystem.server_key.lore_1"));
        tooltip.add(class_2561.method_43471("item.coresystem.server_key.lore_2"));
        super.method_7851(stack, context, tooltip, type);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(
                this,
                "Idle",
                0,
                state -> {
                    state.setAnimation(IDLE);
                    return PlayState.CONTINUE;
                }
        ));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

    // ---- Rechtsklick-Logik (Use) ----
    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);

        if (!world.field_9236 && user instanceof class_3222 player) {
            try {
                var level = PermissionCache.getLevel(player);
                List<ServerTarget> visibleTargets = ServerTargets.baseTargets(level);
                boolean adminMode = PermissionCache.isAdmin(player);

                // hier wie gehabt das GUI öffnen
                ServerSwitcherNetworking.sendOpenMenu(player, visibleTargets, adminMode);

            } catch (Exception e) {
                CoreError error = CoreError.of(
                                CoreErrorCode.SERVER_SWITCHER_OPEN_FAILED,
                                CoreErrorSeverity.ERROR,
                                "Failed to open server switcher menu from ServerKeyItem."
                        )
                        .withCause(e)
                        .withContextEntry("player", user.method_5477().getString());

                LOG.error(error.toLogString(), e);
            }
        }

        return class_1271.method_29237(stack, world.method_8608());
    }
}
