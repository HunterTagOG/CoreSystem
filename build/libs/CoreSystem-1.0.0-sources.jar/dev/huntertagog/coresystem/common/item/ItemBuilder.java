package dev.huntertagog.coresystem.common.item;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2561;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

public final class ItemBuilder {

    private final class_1792 baseItem;
    private int count = 1;
    private class_2561 displayName;
    private final List<class_2561> loreLines = new ArrayList<>();

    private ItemBuilder(class_1792 baseItem) {
        this.baseItem = baseItem;
    }

    public static ItemBuilder of(class_1935 convertible) {
        return new ItemBuilder(convertible.method_8389());
    }

    public ItemBuilder count(int count) {
        this.count = Math.max(1, count);
        return this;
    }

    public ItemBuilder name(class_2561 displayName) {
        this.displayName = displayName;
        return this;
    }

    public ItemBuilder loreLine(class_2561 line) {
        this.loreLines.add(line);
        return this;
    }

    public ItemBuilder lore(List<class_2561> lines) {
        this.loreLines.clear();
        this.loreLines.addAll(lines);
        return this;
    }

    public class_1799 build() {
        class_1799 stack = new class_1799(baseItem, count);

        if (displayName != null) {
            // 1.20.5+ Data Components: ITEM_NAME
            stack.method_57379(class_9334.field_50239, displayName);
        }

        if (!loreLines.isEmpty()) {
            // LoreComponent arbeitet in Mojang/Yarn mit Text-Liste
            stack.method_57379(class_9334.field_49632, new class_9290(loreLines));
        }

        // Unbreakable / CustomModelData / Flags kannst du später via weiteren
        // Data Components ergänzen (UNBREAKABLE, CUSTOM_MODEL_DATA, etc.)

        return stack;
    }
}
