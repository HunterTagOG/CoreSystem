package dev.huntertagog.coresystem.common.item;

import dev.huntertagog.coresystem.common.text.CoreMessage;
import dev.huntertagog.coresystem.common.text.Messages;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;

public final class ModItemGroups {

    public static final class_5321<class_1761> CORE_TAB_KEY =
            class_5321.method_29179(class_7923.field_44687.method_30517(), class_2960.method_60655("coresystem", "core_tab"));

    public static final class_1761 CORE_TAB = class_2378.method_39197(
            class_7923.field_44687,
            CORE_TAB_KEY,
            FabricItemGroup.builder()
                    // nutzt nun den standardisierten Stack aus ModItems
                    .method_47320(ModItems::serverKeyStack)
                    .method_47321(Messages.t(CoreMessage.ITEMGROUP_CORE_TAB))
                    .method_47324()
    );

    public static void init() {
        // nur damit die Klasse geladen wird
    }
}
