package dev.huntertagog.coresystem.common.net.payload;

import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record PrivateIslandListPayload(@NotNull List<UUID> uuids)
        implements class_8710 {

    private static final Logger LOG = LoggerFactory.get("PrivateIslandListPayload");

    public static final class_2960 ID_Private_Island_List =
            class_2960.method_60655("coresystem", "serverswitch/private_island_list");
    public static final class_8710.class_9154<PrivateIslandListPayload> ID =
            new class_8710.class_9154<>(ID_Private_Island_List);

    public static final class_9139<class_9129, PrivateIslandListPayload> CODEC =
            class_8710.method_56484(
                    PrivateIslandListPayload::encode,
                    PrivateIslandListPayload::decode
            );

    private static void encode(
            @NotNull PrivateIslandListPayload payload,
            @NotNull class_9129 buf
    ) {
        List<UUID> source = payload.uuids();
        if (source == null) {
            CoreError error = CoreError.of(
                    CoreErrorCode.NETWORK_PAYLOAD_ENCODE_FAILED,
                    CoreErrorSeverity.WARN,
                    "PrivateIslandListPayload.uuids is null; encoding as empty list."
            );
            LOG.warn(error.toLogString());
            source = Collections.emptyList();
        }

        // Defensiv: null-Entries überspringen
        List<UUID> effective = new ArrayList<>(source.size());
        for (UUID uuid : source) {
            if (uuid == null) {
                CoreError error = CoreError.of(
                        CoreErrorCode.NETWORK_PAYLOAD_ENCODE_FAILED,
                        CoreErrorSeverity.WARN,
                        "Null UUID entry in PrivateIslandListPayload; skipping."
                );
                LOG.warn(error.toLogString());
                continue;
            }
            effective.add(uuid);
        }

        buf.method_10804(effective.size());
        for (UUID uuid : effective) {
            buf.method_10797(uuid);
        }
    }

    @NotNull
    private static PrivateIslandListPayload decode(
            @NotNull class_9129 buf
    ) {
        try {
            int size = buf.method_10816();
            if (size < 0) {
                CoreError error = CoreError.of(
                        CoreErrorCode.NETWORK_PAYLOAD_DECODE_FAILED,
                        CoreErrorSeverity.ERROR,
                        "Negative uuid list size in PrivateIslandListPayload."
                ).withContextEntry("size", size);

                LOG.error(error.toLogString());
                throw new IllegalStateException(error.toLogString());
            }

            List<UUID> list = new ArrayList<>(size);
            for (int i = 0; i < size; i++) {
                list.add(buf.method_10790());
            }

            return new PrivateIslandListPayload(List.copyOf(list));
        } catch (Exception e) {
            CoreError error = CoreError.of(
                    CoreErrorCode.NETWORK_PAYLOAD_DECODE_FAILED,
                    CoreErrorSeverity.ERROR,
                    "Failed to decode PrivateIslandListPayload."
            ).withCause(e);

            LOG.error(error.toLogString(), e);
            throw new IllegalStateException(error.toLogString(), e);
        }
    }

    @Override
    public class_9154<PrivateIslandListPayload> method_56479() {
        return ID;
    }
}
