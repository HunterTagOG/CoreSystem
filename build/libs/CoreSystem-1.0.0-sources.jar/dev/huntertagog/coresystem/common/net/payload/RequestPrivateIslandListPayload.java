package dev.huntertagog.coresystem.common.net.payload;

import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * Leerer Anfrage-Payload:
 * client → server : "Bitte sende mir die Liste der privaten Inseln"
 * <p>
 * Wird serverseitig beantwortet mit {@link PrivateIslandListPayload}.
 */
public record RequestPrivateIslandListPayload() implements class_8710 {

    private static final Logger LOG = LoggerFactory.get("ReqPrivateIslandList");

    public static final class_9154<RequestPrivateIslandListPayload> ID =
            new class_9154<>(class_2960.method_60655("coresystem", "serverswitch/request_private_island_list"));

    public static final class_9139<class_9129, RequestPrivateIslandListPayload> CODEC =
            class_8710.method_56484(
                    RequestPrivateIslandListPayload::encode,
                    RequestPrivateIslandListPayload::decode
            );

    // ---------------------------------------------------------------------
    // ENCODE
    // ---------------------------------------------------------------------
    private static void encode(RequestPrivateIslandListPayload payload, class_9129 buf) {
        try {
            // Payload ist leer → noop
        } catch (Exception e) {
            CoreError error = CoreError.of(
                    CoreErrorCode.NETWORK_PAYLOAD_ENCODE_FAILED,
                    CoreErrorSeverity.ERROR,
                    "Failed to encode RequestPrivateIslandListPayload."
            ).withCause(e);

            LOG.error(error.toLogString(), e);
            throw new IllegalStateException(error.toLogString(), e);
        }
    }

    // ---------------------------------------------------------------------
    // DECODE
    // ---------------------------------------------------------------------
    private static RequestPrivateIslandListPayload decode(class_9129 buf) {
        try {
            // keine Daten → Direkt neue Instanz
            return new RequestPrivateIslandListPayload();

        } catch (Exception e) {
            CoreError error = CoreError.of(
                    CoreErrorCode.NETWORK_PAYLOAD_DECODE_FAILED,
                    CoreErrorSeverity.ERROR,
                    "Failed to decode RequestPrivateIslandListPayload."
            ).withCause(e);

            LOG.error(error.toLogString(), e);
            throw new IllegalStateException(error.toLogString(), e);
        }
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
