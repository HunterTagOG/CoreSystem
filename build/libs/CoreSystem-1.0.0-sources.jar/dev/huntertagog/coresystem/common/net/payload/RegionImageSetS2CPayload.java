package dev.huntertagog.coresystem.common.net.payload;

import dev.huntertagog.coresystem.common.region.RegionImageDef;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record RegionImageSetS2CPayload(
        String regionId,
        class_2960 worldId,
        double minX, double minY, double minZ,
        double maxX, double maxY, double maxZ,
        String mode,
        String facing,
        int baseY,
        String textureId
) implements class_8710 {

    public static final class_9154<RegionImageSetS2CPayload> ID =
            new class_9154<>(class_2960.method_60655("coresystem", "region_image_set_s2c"));

    public static final class_9139<class_2540, RegionImageSetS2CPayload> CODEC =
            class_9139.method_56438(RegionImageSetS2CPayload::encode, RegionImageSetS2CPayload::decode);

    // ✅ Encoder: (value, buf)
    private static void encode(RegionImageSetS2CPayload p, class_2540 buf) {
        buf.method_10814(p.regionId());
        buf.method_10812(p.worldId());

        buf.method_52940(p.minX());
        buf.method_52940(p.minY());
        buf.method_52940(p.minZ());
        buf.method_52940(p.maxX());
        buf.method_52940(p.maxY());
        buf.method_52940(p.maxZ());

        buf.method_10814(p.mode());
        buf.method_10814(p.facing() == null ? "" : p.facing());
        buf.method_53002(p.baseY());

        buf.method_10814(p.textureId());
    }

    // ✅ Decoder: (buf) -> value
    private static RegionImageSetS2CPayload decode(class_2540 buf) {
        String regionId = buf.method_19772();
        class_2960 worldId = buf.method_10810();

        double minX = buf.readDouble(), minY = buf.readDouble(), minZ = buf.readDouble();
        double maxX = buf.readDouble(), maxY = buf.readDouble(), maxZ = buf.readDouble();

        String mode = buf.method_19772();
        String facing = buf.method_19772();
        int baseY = buf.readInt();

        String textureId = buf.method_19772();

        return new RegionImageSetS2CPayload(
                regionId, worldId,
                minX, minY, minZ, maxX, maxY, maxZ,
                mode, facing, baseY, textureId
        );
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }

    public static RegionImageSetS2CPayload fromDef(RegionImageDef def) {
        return new RegionImageSetS2CPayload(
                def.regionId(),
                def.worldId(),
                def.bounds().field_1323,
                def.bounds().field_1322,
                def.bounds().field_1321,
                def.bounds().field_1320,
                def.bounds().field_1325,
                def.bounds().field_1324,
                def.mode().name(),
                def.facing().name(),
                def.baseY(),
                def.textureId()
        );
    }
}
