package dev.huntertagog.coresystem.common.net.payload;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record RegionImageRemoveS2CPayload(String regionId, class_2960 worldId) implements class_8710 {

    public static final class_9154<RegionImageRemoveS2CPayload> ID =
            new class_9154<>(class_2960.method_60655("coresystem", "region_image_remove_s2c"));

    public static final class_9139<class_2540, RegionImageRemoveS2CPayload> CODEC =
            class_9139.method_56438(RegionImageRemoveS2CPayload::encode, RegionImageRemoveS2CPayload::decode);

    private static void encode(RegionImageRemoveS2CPayload p, class_2540 buf) {
        buf.method_10814(p.regionId());
        buf.method_10812(p.worldId());
    }

    private static RegionImageRemoveS2CPayload decode(class_2540 buf) {
        return new RegionImageRemoveS2CPayload(buf.method_19772(), buf.method_10810());
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
