package dev.huntertagog.coresystem.common.net.payload;

import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record SelectServerPayload(String target) implements class_8710 {

    private static final Logger LOG = LoggerFactory.get("SelectServerPayload");

    public static final class_2960 ID_SELECT_SERVER =
            class_2960.method_60655("coresystem", "serverswitch/select");
    public static final class_8710.class_9154<SelectServerPayload> ID =
            new class_8710.class_9154<>(ID_SELECT_SERVER);

    public static final class_9139<class_9129, SelectServerPayload> CODEC =
            class_8710.method_56484(
                    SelectServerPayload::encode,
                    SelectServerPayload::decode
            );

    // ---------------------------------------------------------------------
    // ENCODE
    // ---------------------------------------------------------------------
    private static void encode(SelectServerPayload payload, class_9129 buf) {
        try {
            buf.method_10814(payload.target());
        } catch (Exception e) {
            CoreError error = CoreError.of(
                            CoreErrorCode.NETWORK_PAYLOAD_ENCODE_FAILED,
                            CoreErrorSeverity.ERROR,
                            "Failed to encode SelectServerPayload."
                    )
                    .withContextEntry("target", String.valueOf(payload.target()))
                    .withCause(e);

            LOG.error(error.toLogString(), e);
            throw new IllegalStateException(error.toLogString(), e);
        }
    }

    // ---------------------------------------------------------------------
    // DECODE
    // ---------------------------------------------------------------------
    private static SelectServerPayload decode(class_9129 buf) {
        try {
            String target = buf.method_19772();
            return new SelectServerPayload(target);
        } catch (Exception e) {
            CoreError error = CoreError.of(
                    CoreErrorCode.NETWORK_PAYLOAD_DECODE_FAILED,
                    CoreErrorSeverity.ERROR,
                    "Failed to decode SelectServerPayload."
            ).withCause(e);

            LOG.error(error.toLogString(), e);
            throw new IllegalStateException(error.toLogString(), e);
        }
    }

    @Override
    public class_9154<SelectServerPayload> method_56479() {
        return ID;
    }
}
