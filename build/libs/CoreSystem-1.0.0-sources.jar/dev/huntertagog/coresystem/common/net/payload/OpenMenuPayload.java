package dev.huntertagog.coresystem.common.net.payload;

import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.common.model.ServerTarget;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record OpenMenuPayload(
        boolean adminMode,
        List<ServerTarget> targets
) implements class_8710 {

    private static final Logger LOG = LoggerFactory.get("OpenMenuPayload");

    public static final class_2960 ID_OPEN_MENU =
            class_2960.method_60655("coresystem", "serverswitch/open_menu");
    public static final class_8710.class_9154<OpenMenuPayload> ID =
            new class_8710.class_9154<>(ID_OPEN_MENU);

    // B = RegistryByteBuf, T = OpenMenuPayload
    public static final class_9139<class_9129, OpenMenuPayload> CODEC =
            class_8710.method_56484(
                    OpenMenuPayload::encode,
                    OpenMenuPayload::decode
            );

    // >>> value first: (T value, B buf) – so wie du es aktuell nutzt
    private static void encode(OpenMenuPayload payload, class_9129 buf) {
        List<ServerTarget> list = payload.targets();

        if (list == null) {
            CoreError error = CoreError.of(
                    CoreErrorCode.NETWORK_PAYLOAD_ENCODE_FAILED,
                    CoreErrorSeverity.WARN,
                    "OpenMenuPayload.targets is null; encoding as empty list."
            ).withContextEntry("payloadAdminMode", payload.adminMode());

            LOG.warn(error.toLogString());
            list = Collections.emptyList();
        }

        buf.method_52964(payload.adminMode());
        buf.method_10804(list.size());

        for (ServerTarget t : list) {
            if (t == null) {
                CoreError error = CoreError.of(
                        CoreErrorCode.NETWORK_PAYLOAD_ENCODE_FAILED,
                        CoreErrorSeverity.WARN,
                        "Null ServerTarget entry in OpenMenuPayload; skipping."
                );
                LOG.warn(error.toLogString());
                continue;
            }

            buf.method_10814(t.id());
            buf.method_10814(t.displayName());
            buf.method_10814(t.commandTarget());
            buf.method_10817(t.category());
        }
    }

    // decoder: (buf) -> T
    private static OpenMenuPayload decode(class_9129 buf) {
        try {
            boolean admin = buf.readBoolean();
            int size = buf.method_10816();

            if (size < 0) {
                CoreError error = CoreError.of(
                        CoreErrorCode.NETWORK_PAYLOAD_DECODE_FAILED,
                        CoreErrorSeverity.ERROR,
                        "Negative targets size in OpenMenuPayload."
                ).withContextEntry("size", size);

                LOG.error(error.toLogString());
                throw new IllegalStateException(error.toLogString());
            }

            List<ServerTarget> list = new ArrayList<>(size);

            for (int i = 0; i < size; i++) {
                String id = buf.method_19772();
                String displayName = buf.method_19772();
                String commandTarget = buf.method_19772();
                ServerTarget.Category category =
                        buf.method_10818(ServerTarget.Category.class);

                list.add(new ServerTarget(id, displayName, commandTarget, category));
            }

            // Immutability nach außen
            return new OpenMenuPayload(admin, List.copyOf(list));
        } catch (Exception e) {
            CoreError error = CoreError.of(
                    CoreErrorCode.NETWORK_PAYLOAD_DECODE_FAILED,
                    CoreErrorSeverity.ERROR,
                    "Failed to decode OpenMenuPayload."
            ).withCause(e);

            LOG.error(error.toLogString(), e);
            // Hart abbrechen, damit die Connection sauber gefailt wird
            throw new IllegalStateException(error.toLogString(), e);
        }
    }

    @Override
    public class_9154<OpenMenuPayload> method_56479() {
        return ID;
    }
}
