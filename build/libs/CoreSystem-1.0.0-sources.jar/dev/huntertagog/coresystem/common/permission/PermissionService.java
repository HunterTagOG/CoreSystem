package dev.huntertagog.coresystem.common.permission;

import dev.huntertagog.coresystem.common.provider.Service;
import net.minecraft.class_2168;
import net.minecraft.class_3222;

public interface PermissionService extends Service {

    /**
     * Permission-Check über CorePermission-Enum.
     */
    boolean has(class_2168 source, CorePermission perm);

    /**
     * Permission-Check über reinen Node-String.
     */
    boolean has(class_2168 source, String permissionNode);

    // ---------------------------------------------------------------------
    // Convenience-Overloads für direkte Player-Nutzung
    // ---------------------------------------------------------------------

    default boolean has(class_3222 player, CorePermission perm) {
        if (player == null) {
            return false;
        }
        return has(player.method_5671(), perm);
    }

    default boolean has(class_3222 player, String permissionNode) {
        if (player == null) {
            return false;
        }
        return has(player.method_5671(), permissionNode);
    }
}
