package dev.huntertagog.coresystem.common.ratelimit;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongList;
import org.jetbrains.annotations.NotNull;

import java.time.Duration;

public final class InMemoryRateLimitService implements RateLimitService {

    private final Cache<@NotNull String, LongList> buckets;

    public InMemoryRateLimitService() {
        this.buckets = Caffeine.newBuilder()
                .expireAfterAccess(Duration.ofMinutes(5))
                .maximumSize(50_000)
                .build();
    }

    private String bucketKey(String key, RateLimitRule rule) {
        return rule.id() + "|" + key;
    }

    @Override
    public boolean tryAcquire(@NotNull String key, @NotNull RateLimitRule rule) {
        long now = System.currentTimeMillis();
        String bucketKey = bucketKey(key, rule);

        LongList list = buckets.getIfPresent(bucketKey);
        if (list == null) {
            list = new LongArrayList();
            buckets.put(bucketKey, list);
        }

        // altes Fenster aufräumen
        prune(list, now, rule.intervalMillis());

        if (list.size() >= rule.maxActions()) {
            // blockiert
            return false;
        }

        list.add(now);
        return true;
    }

    @Override
    public long getRetryAfterMillis(@NotNull String key, @NotNull RateLimitRule rule) {
        long now = System.currentTimeMillis();
        String bucketKey = bucketKey(key, rule);

        LongList list = buckets.getIfPresent(bucketKey);
        if (list == null || list.isEmpty()) {
            return 0L;
        }

        prune(list, now, rule.intervalMillis());
        if (list.size() < rule.maxActions()) {
            return 0L;
        }

        long oldest = list.getLong(0);
        long allowedAt = oldest + rule.intervalMillis();
        long diff = allowedAt - now;
        return Math.max(diff, 0L);
    }

    private void prune(LongList list, long now, long intervalMillis) {
        long cutoff = now - intervalMillis;
        int idx = 0;
        int size = list.size();
        while (idx < size && list.getLong(idx) < cutoff) {
            idx++;
        }
        if (idx > 0) {
            list.removeElements(0, idx);
        }
    }
}
