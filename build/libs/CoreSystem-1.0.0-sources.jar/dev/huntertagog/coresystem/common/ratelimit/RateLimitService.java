package dev.huntertagog.coresystem.common.ratelimit;

import dev.huntertagog.coresystem.common.provider.Service;
import org.jetbrains.annotations.NotNull;

public interface RateLimitService extends Service {

    /**
     * Versucht, eine Aktion für "key" nach Regel "rule" zu registrieren.
     *
     * @return true, wenn erlaubt; false, wenn Rate-Limit greift.
     */
    boolean tryAcquire(@NotNull String key, @NotNull RateLimitRule rule);

    /**
     * Liefert (geschätzt) die verbleibende Wartezeit in ms, bis wieder
     * eine Aktion für "key" nach "rule" erlaubt wäre.
     * 0 oder <0 bedeutet: sofort wieder erlaubt.
     */
    long getRetryAfterMillis(@NotNull String key, @NotNull RateLimitRule rule);
}
