package dev.huntertagog.coresystem.common.islands;

import org.jetbrains.annotations.Nullable;

import java.util.Collection;

public interface PrivateIslandNodeRepository {

    void saveStatus(PrivateIslandWorldNodeStatus status);

    @Nullable
    PrivateIslandWorldNodeStatus getStatus(String nodeId);

    Collection<PrivateIslandWorldNodeStatus> getAllStatuses();
}
