package dev.huntertagog.coresystem.common.rct;

import dev.huntertagog.coresystem.server.redis.RedisClient;
import org.jetbrains.annotations.NotNull;
import redis.clients.jedis.Jedis;

public final class RctRegionSpawnStore {

    private static final String KEY_PREFIX = "cs:rct:region_spawned:";

    private RctRegionSpawnStore() {
    }

    public static boolean isSpawned(@NotNull String worldId, @NotNull String regionId) {
        try (Jedis jedis = RedisClient.get().getResource()) {
            return jedis.exists(KEY_PREFIX + worldId + ":" + regionId);
        }
    }

    public static void markSpawned(@NotNull String worldId, @NotNull String regionId) {
        try (Jedis jedis = RedisClient.get().getResource()) {
            jedis.set(KEY_PREFIX + worldId + ":" + regionId, "1");
        }
    }
}
