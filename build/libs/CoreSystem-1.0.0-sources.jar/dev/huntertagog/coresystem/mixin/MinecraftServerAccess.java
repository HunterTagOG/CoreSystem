package dev.huntertagog.coresystem.mixin;

import net.minecraft.class_1937;
import net.minecraft.class_32;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;

@Mixin(MinecraftServer.class)
public interface MinecraftServerAccess {

    @Accessor
    Map<class_5321<class_1937>, class_3218> getWorlds();

    @Accessor
    class_32.class_5143 getSession();

}

