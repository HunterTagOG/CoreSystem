package dev.huntertagog.coresystem.mixin;

import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import dev.huntertagog.coresystem.common.text.CoreMessage;
import dev.huntertagog.coresystem.common.text.Messages;
import dev.huntertagog.coresystem.server.protection.WorldProtectionService;
import net.minecraft.class_1297;
import net.minecraft.class_1541;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1541.class)
public class TntEntityMixin {

    /**
     * Intercept TNT explosion BEFORE it happens.
     */
    @Inject(method = "explode", at = @At("HEAD"), cancellable = true)
    private void onExplode(CallbackInfo ci) {
        class_1541 self = (class_1541) (Object) this;
        class_1937 world = self.method_37908();

        WorldProtectionService protection = ServiceProvider.getService(WorldProtectionService.class);
        if (protection == null || !protection.isTntBlocked(world)) {
            return; // Explosion normal erlauben
        }

        // Wer hat es gezündet? -> Owner vom TNT
        class_1297 owner = self.method_6970();
        if (owner instanceof class_1657 player) {
            // Sound für Spieler abspielen
            player.method_5783(
                    class_3417.field_15008,
                    1.0f,
                    1.0f
            );
            player.method_7353(Messages.t(CoreMessage.PROTECT_TNT_BLOCKED), false);
        }

        // Explosion canceln – kein Schaden, keine Blöcke ändern
        ci.cancel();
    }
}
