package dev.huntertagog.coresystem.server.islands;

import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.server.redis.RedisClient;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPubSub;

import java.util.UUID;
import java.util.concurrent.*;

public final class PrivateIslandPrepareResponseBus {

    private static final Logger LOG = LoggerFactory.get("IslandPrepareBus");
    private static final PrivateIslandPrepareResponseBus INSTANCE = new PrivateIslandPrepareResponseBus();

    private final ConcurrentMap<UUID, CompletableFuture<Boolean>> pending = new ConcurrentHashMap<>();
    private final ScheduledExecutorService timeouts =
            Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "IslandPrepareBus-Timeouts");
                t.setDaemon(true);
                return t;
            });

    private volatile boolean started = false;

    private PrivateIslandPrepareResponseBus() {
    }

    public static PrivateIslandPrepareResponseBus get() {
        return INSTANCE;
    }

    public synchronized void startIfNeeded() {
        if (started) return;
        started = true;

        Thread t = new Thread(this::runSubscriber, "IslandPrepareBus-Subscriber");
        t.setDaemon(true);
        t.start();

        LOG.info("PrepareResponseBus started (psubscribe={})", PrivateIslandWorldRedisProtocol.responseChannelPattern());
    }

    public CompletableFuture<Boolean> register(UUID requestId, long timeoutMillis) {
        CompletableFuture<Boolean> future = new CompletableFuture<>();
        pending.put(requestId, future);

        timeouts.schedule(() -> {
            CompletableFuture<Boolean> f = pending.remove(requestId);
            if (f != null && !f.isDone()) {
                f.completeExceptionally(new TimeoutException("Timeout waiting for island preparation"));
            }
        }, timeoutMillis, TimeUnit.MILLISECONDS);

        return future;
    }

    private void runSubscriber() {
        JedisPubSub sub = new JedisPubSub() {
            @Override
            public void onPMessage(String pattern, String channel, String message) {
                // message: OK;requestId;ownerId  oder ERR;requestId;ownerId;error
                try {
                    String[] parts = message.split(";", 4);
                    if (parts.length < 3) return;

                    String type = parts[0];
                    UUID reqId = UUID.fromString(parts[1]);

                    CompletableFuture<Boolean> f = pending.remove(reqId);
                    if (f == null) return; // schon timeout/abgeschlossen

                    if ("OK".equals(type)) {
                        f.complete(true);
                    } else {
                        String err = parts.length >= 4 ? parts[3] : "unknown";
                        f.completeExceptionally(new IllegalStateException(err));
                    }
                } catch (Exception e) {
                    LOG.warn("Failed to handle prepare response: channel={} msg={}", channel, message, e);
                }
            }
        };

        while (started) {
            try (Jedis jedis = RedisClient.get().getResource()) {
                jedis.psubscribe(sub, PrivateIslandWorldRedisProtocol.responseChannelPattern());
            } catch (Exception e) {
                LOG.warn("PrepareResponseBus subscriber failed, retrying...", e);
                try {
                    Thread.sleep(500);
                } catch (InterruptedException ignored) {
                }
            }
        }
    }
}
