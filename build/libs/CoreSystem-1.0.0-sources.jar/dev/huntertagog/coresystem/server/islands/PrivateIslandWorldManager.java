package dev.huntertagog.coresystem.server.islands;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import dev.huntertagog.coresystem.CoresystemCommon;
import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.common.islands.PrivateIslandWorldNodeStatus;
import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import dev.huntertagog.coresystem.common.ratelimit.RateLimitRules;
import dev.huntertagog.coresystem.common.ratelimit.RateLimitUtil;
import dev.huntertagog.coresystem.common.teleport.TeleportManagerService;
import dev.huntertagog.coresystem.common.text.CoreMessage;
import dev.huntertagog.coresystem.common.text.Messages;
import dev.huntertagog.coresystem.mixin.MinecraftServerAccess;
import dev.huntertagog.coresystem.server.task.TaskScheduler;
import dev.huntertagog.coresystem.server.world.gen.OceanIslandChunkGenerator;
import dev.huntertagog.coresystem.server.world.island.*;
import dev.huntertagog.coresystem.server.world.runtime.RuntimeWorldConfig;
import dev.huntertagog.coresystem.server.world.runtime.RuntimeWorldHandle;
import lombok.Getter;
import net.minecraft.class_1267;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2794;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7134;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.time.Duration;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicInteger;

import static dev.huntertagog.coresystem.server.islands.PrivateIslandWorldNodeConfig.IS_ISLAND_SERVER;

public final class PrivateIslandWorldManager {

    private static final Logger LOG = LoggerFactory.get("PrivateIslands");

    private static volatile PrivateIslandWorldManager instance;

    private final MinecraftServer server;
    @Getter
    private final Config config;

    private final Cache<@NotNull UUID, class_5321<class_1937>> islandKeyCache;
    private final Cache<@NotNull UUID, class_3218> islandWorldCache;

    private final AtomicInteger islandWorldCount = new AtomicInteger(0);
    private String targetServerName;

    // ------------------------------------------------------------------------
    // Konstruktion / Lifecycle
    // ------------------------------------------------------------------------

    private PrivateIslandWorldManager(MinecraftServer server, Config config) {
        this.server = Objects.requireNonNull(server, "server");
        this.config = Objects.requireNonNull(config, "config");

        this.islandKeyCache = Caffeine.newBuilder()
                .maximumSize(10_000)
                .expireAfterAccess(Duration.ofMinutes(30))
                .build();

        this.islandWorldCache = Caffeine.newBuilder()
                .maximumSize(10_000)
                .expireAfterAccess(Duration.ofMinutes(15))
                .build();
    }

    public static void init(MinecraftServer server, Config config) {
        PrivateIslandWorldManager manager = new PrivateIslandWorldManager(server, config);
        manager.initializeIslandWorldCount();
        instance = manager;
        LOG.info("PrivateIslandWorldManager initialisiert mit maxIslandsPerNode={} maxPlayersPerIsland={}",
                config.maxIslandsPerNode(), config.maxPlayersPerIsland());
    }

    public static PrivateIslandWorldManager get(MinecraftServer server) {
        if (instance == null) {
            throw new IllegalStateException("PrivateIslandWorldManager not initialized. Call init(server, config) first.");
        }
        if (instance.server != server) {
            throw new IllegalStateException("PrivateIslandWorldManager accessed with different MinecraftServer instance.");
        }
        return instance;
    }

    @Nullable
    public static PrivateIslandWorldManager getInstance() {
        return instance;
    }

    public Object getDeletionQueue() {
        return PrivateIslandWorldService.get(this.server).getDeletionQueue();
    }

    public record Config(
            int maxIslandsPerNode,
            int maxPlayersPerIsland
    ) {
    }

    // ------------------------------------------------------------------------
    // Live-Counter-API
    // ------------------------------------------------------------------------

    void incrementIslandWorldCount() {
        int value = islandWorldCount.incrementAndGet();
        LOG.debug("Island world count incremented: {}", value);
    }

    void decrementIslandWorldCount() {
        int value = islandWorldCount.decrementAndGet();
        if (value < 0) {
            islandWorldCount.set(0);
            LOG.warn("Island world count went below 0, resetting to 0.");
        } else {
            LOG.debug("Island world count decremented: {}", value);
        }
    }

    public int countIslandWorlds() {
        return islandWorldCount.get();
    }

    private void initializeIslandWorldCount() {
        int count = 0;
        for (class_3218 world : server.method_3738()) {
            if (isIslandWorld(world)) {
                count++;
            }
        }
        islandWorldCount.set(count);
        LOG.info("Initialized island world count to {} on startup.", count);
    }

    // ------------------------------------------------------------------------
    // Teleport-Logik
    // ------------------------------------------------------------------------

    public void teleportPlayerToIslandWorld(class_3222 player, class_3218 islandWorld) {
        class_2338 spawn = islandWorld.method_43126();
        if (spawn == null || spawn.method_10264() <= islandWorld.method_31607()) {
            int y = Math.max(
                    islandWorld.method_8615() + 3,
                    islandWorld.method_31607() + 64
            );
            spawn = new class_2338(0, y, 0);
            LOG.warn("[IslandSpawn] World spawn invalid in {}, using fallback spawn {}",
                    islandWorld.method_27983().method_29177(), spawn);
        }

        LOG.info("Teleporting player {} to island world {} at {}",
                player.method_7334().getName(),
                islandWorld.method_27983().method_29177(),
                spawn);

        player.method_26284(
                islandWorld.method_27983(),
                spawn,
                0.0F,
                true,
                false
        );

        player.method_14251(
                islandWorld,
                spawn.method_10263() + 0.5,
                spawn.method_10264(),
                spawn.method_10260() + 0.5,
                player.method_36454(),
                player.method_36455()
        );
    }

    public void teleportPlayerToOwnIsland(class_3222 player) {
        UUID ownerId = player.method_5667();

        getOrCreateIslandWorld(ownerId).whenComplete((islandWorld, throwable) -> {
            if (throwable != null || islandWorld == null) {
                CoreError error = CoreError.of(
                                CoreErrorCode.PRIVATE_ISLAND_WORLD_RESOLVE_FAILED,
                                CoreErrorSeverity.ERROR,
                                "[PrivateIslands] Failed to create/load island world for player."
                        )
                        .withContextEntry("ownerId", ownerId)
                        .withCause(throwable);

                error.log();
                player.method_7353(
                        Messages.t(CoreMessage.ISLAND_NO_WORLD_AVAILABLE),
                        false
                );
                return;
            }

            class_2338 spawn = resolveIslandSpawn(islandWorld, ownerId);

            player.method_26284(
                    player.method_51469().method_27983(),
                    spawn,
                    0.0F,
                    true,
                    false
            );

            player.method_14251(
                    islandWorld,
                    spawn.method_10263() + 0.5,
                    spawn.method_10264(),
                    spawn.method_10260() + 0.5,
                    player.method_36454(),
                    player.method_36455()
            );
        });
    }

    private class_2338 resolveIslandSpawn(class_3218 islandWorld, UUID ownerId) {
        class_2338 worldSpawn = islandWorld.method_43126();

        if (worldSpawn == null || worldSpawn.method_10264() <= islandWorld.method_31607()) {
            int y = Math.max(
                    islandWorld.method_8615() + 3,
                    islandWorld.method_31607() + 64
            );
            worldSpawn = new class_2338(0, y, 0);
            LOG.warn("[IslandSpawn] World spawn invalid in {}, using fallback {}",
                    islandWorld.method_27983().method_29177(), worldSpawn);
        }

        return worldSpawn;
    }

    // ------------------------------------------------------------------------
    // World-Resolution / Lifecycle
    // ------------------------------------------------------------------------

    public CompletableFuture<class_3218> getOrCreateIslandWorld(@NotNull UUID ownerId) {
        if (!IS_ISLAND_SERVER) {
            CoreError error = CoreError.of(
                            CoreErrorCode.PRIVATE_ISLAND_CALL_ON_NON_ISLAND_NODE,
                            CoreErrorSeverity.ERROR,
                            "[PrivateIslands] getOrCreateIslandWorld() called on non-island server."
                    )
                    .withContextEntry("ownerId", ownerId)
                    .withContextEntry("serverId", server.method_3818());

            error.log();
            return CompletableFuture.failedFuture(
                    new IllegalStateException(error.toLogString())
            );
        }

        class_5321<class_1937> worldKey = islandWorldKey(ownerId);

        class_3218 cached = islandWorldCache.getIfPresent(ownerId);
        if (cached != null && cached.method_8503() == server) {
            LOG.debug("[PrivateIslands] World already exists for owner {} (cache-hit).", ownerId);
            return CompletableFuture.completedFuture(cached);
        }

        class_3218 existing = server.method_3847(worldKey);
        if (existing != null) {
            islandWorldCache.put(ownerId, existing);
            LOG.debug("[PrivateIslands] World already exists for owner {} (server world list).", ownerId);
            return CompletableFuture.completedFuture(existing);
        }

        if (countIslandWorlds() >= config.maxIslandsPerNode()) {
            CoreError error = CoreError.of(
                            CoreErrorCode.PRIVATE_ISLAND_MAX_WORLDS_REACHED,
                            CoreErrorSeverity.WARN,
                            "[PrivateIslands] Max worlds on this node reached."
                    )
                    .withContextEntry("maxIslandsPerNode", config.maxIslandsPerNode())
                    .withContextEntry("currentIslands", countIslandWorlds());

            error.log();
            return CompletableFuture.failedFuture(
                    new IllegalStateException(error.toLogString())
            );
        }
        boolean existsOnDisk = worldDirExists(worldKey);

        return createIslandWorldAsync(worldKey, ownerId, existsOnDisk)
                .thenApply(world -> {
                    LOG.debug("[PrivateIslands] Created island world for owner {}.", ownerId);
                    islandWorldCache.put(ownerId, world);
                    return world;
                });
    }

    public boolean isIslandWorld(class_3218 world) {
        class_2960 id = world.method_27983().method_29177();
        return id.method_12836().equals(CoresystemCommon.MOD_ID)
                && id.method_12832().startsWith("island/");
    }

    public void deleteIslandWorld(class_3218 world, UUID ownerId) {
        if (world != null) {
            world.method_18456().forEach(player -> {
                sendToFallbackServer(server, player);
                player.method_7353(
                        Messages.t(CoreMessage.ISLAND_DELETE_KICK),
                        true
                );
            });

            PrivateIslandWorldService.get(server).enqueueWorldDeletion(world);
            islandKeyCache.invalidate(ownerId);
            islandWorldCache.invalidate(ownerId);
            decrementIslandWorldCount();
            var ownerRepo = PrivateIslandWorldOwnerRepositoryRedis.get();
            ownerRepo.unassignOwner(ownerId);
            PrivateIslandInitState init = world.method_17983()
                    .method_17924(PrivateIslandInitState.TYPE, PrivateIslandInitState.KEY);
            init.setUninitialized();
            LOG.info("Enqueued deletion of island world {} for owner {}.",
                    world.method_27983().method_29177(), ownerId);
        }
    }

    public static void sendToFallbackServer(MinecraftServer server, class_3222 player) {
        TeleportManagerService teleport = ServiceProvider.getService(TeleportManagerService.class);
        if (teleport != null) {
            // Ziel-Server aus ENV, sonst "lobby"
            String fallbackServer = System.getenv().getOrDefault(
                    "CORESYSTEM_ISLAND_FALLBACK_SERVER",
                    "lobby"
            );

            // Inventory-Kontext: globales Netzwerk-Inventar
            teleport.teleportPlayer(
                    player,
                    fallbackServer,
                    "network-global",
                    "island-delete-fallback"
            );
            return;
        }

        // Legacy-Fallback: ursprünglicher Proxycommand
        String cmd = "proxycommand \"server lobby\"";
        server.method_3734().method_44252(player.method_5671().method_9217(), cmd);
    }

    public class_5321<class_1937> islandWorldKey(UUID ownerId) {
        class_5321<class_1937> cached = islandKeyCache.getIfPresent(ownerId);
        if (cached != null) {
            return cached;
        }

        class_2960 id = class_2960.method_60655(
                CoresystemCommon.MOD_ID,
                "island/" + ownerId.toString().toLowerCase()
        );
        class_5321<class_1937> key = class_5321.method_29179(class_7924.field_41223, id);
        islandKeyCache.put(ownerId, key);
        return key;
    }

    // ------------------------------------------------------------------------
    // Welt-Erstellung (async)
    // ------------------------------------------------------------------------

    private CompletableFuture<class_3218> createIslandWorldAsync(class_5321<class_1937> worldKey, UUID ownerId, boolean existsOnDisk) {
        class_3218 overworld = server.method_30002();


        if (overworld == null) {
            CoreError error = CoreError.of(
                            CoreErrorCode.PRIVATE_ISLAND_OVERWORLD_MISSING,
                            CoreErrorSeverity.ERROR,
                            "[PrivateIslands] Overworld not available – cannot create island world."
                    )
                    .withContextEntry("ownerId", ownerId)
                    .withContextEntry("worldKey", worldKey.method_29177().toString());

            error.log();
            return CompletableFuture.failedFuture(
                    new IllegalStateException(error.toLogString())
            );
        }

        class_2960 persistentId = worldKey.method_29177();
        long islandSeed = ThreadLocalRandom.current().nextLong();

        int islandRadiusChunks = PrivateIslandWorldEnv.ISLAND_RADIUS;
        int oceanRadiusChunks = PrivateIslandWorldEnv.OCEAN_RADIUS;
        int islandRadiusBlocks = islandRadiusChunks * 16;

        int seaLevel = overworld.method_8615();
        int baseHeight = seaLevel - 2;

        LOG.info("Creating island world '{}' for owner '{}' (island={} chunks, ocean={} chunks, seed={})",
                persistentId,
                ownerId,
                islandRadiusChunks,
                oceanRadiusChunks,
                islandSeed
        );

        var preset = IslandGenerationSelector.selectPreset(islandSeed, ownerId);

        final IslandHeightmap heightmap;

        switch (preset) {
            case REALISTIC_SINGLE -> heightmap = IslandHeightmap.createRealisticSingle(
                    islandRadiusBlocks,
                    baseHeight,
                    seaLevel,
                    islandSeed ^ ownerId.getMostSignificantBits()
            );
            case REALISTIC_MULTI_PEAKS -> heightmap = IslandHeightmap.createRealisticMultiPeak(
                    islandRadiusBlocks,
                    baseHeight,
                    seaLevel,
                    islandSeed ^ ownerId.getLeastSignificantBits()
            );
            case CLUSTER -> {
                int clusterCount = 3 + Math.floorMod(islandSeed, 3);
                heightmap = IslandHeightmap.createCluster(
                        islandRadiusBlocks,
                        baseHeight,
                        seaLevel,
                        islandSeed ^ 0x1337L,
                        clusterCount
                );
            }
            case CLUSTER_LAGOONS -> {
                int clusterCount = 3 + Math.floorMod(islandSeed >>> 1, 3);
                heightmap = IslandHeightmap.createClusterWithLagoons(
                        islandRadiusBlocks,
                        baseHeight,
                        seaLevel,
                        islandSeed ^ 0xBADC0DEL,
                        clusterCount
                );
            }
            default -> throw new IllegalStateException("Unexpected preset: " + preset);
        }

        class_2794 vanilla = overworld.method_14178().method_12129();

        class_2794 generator = new OceanIslandChunkGenerator(
                vanilla,
                overworld,
                heightmap
        );

        RuntimeWorldConfig cfg = new RuntimeWorldConfig()
                .setDimensionType(class_7134.field_37666)
                .setGenerator(generator)
                .setDifficulty(class_1267.field_5802)
                .setGameRule(class_1928.field_28357, 20)
                .setSeed(islandSeed);

        return loadPersistentWorldAsync(server, persistentId, cfg)
                .thenCompose(world -> {
                    CompletableFuture<class_3218> future = new CompletableFuture<>();

                    server.execute(() -> {
                        try {
                            PrivateIslandInitState init = world.method_17983()
                                    .method_17924(PrivateIslandInitState.TYPE, PrivateIslandInitState.KEY);

                            // Wenn Disk sagt “existiert”, aber init fehlt: NICHT dekorieren, um Builds zu schützen
                            if (existsOnDisk && init.isInitialized()) {
                                LOG.warn("Island {} exists on disk but init flag missing. Skipping decoration to avoid overwrites.", persistentId);
                                future.complete(world);
                                return;
                            }

                            // ---- FIRST CREATE ONLY ----
                            configureIslandWorldBorder(world, islandRadiusChunks, oceanRadiusChunks);

                            int rChunks = islandRadiusChunks + 2;
                            for (int cx = -rChunks; cx <= rChunks; cx++) {
                                for (int cz = -rChunks; cz <= rChunks; cz++) {
                                    world.method_8497(cx, cz);
                                }
                            }

                            IslandStyle style = IslandStyleSelector.selectFor(world, ownerId, islandSeed);
                            IslandHeightmap.applyGroundProfile(world, heightmap, style, seaLevel);

                            IslandDecorator.decorateOceanIsland(world, heightmap, islandRadiusBlocks, seaLevel, style, islandSeed);

                            TeleportSafeZoneUtil.createTeleportSafeZone(world, heightmap, style, seaLevel);

                            world.method_8497(0, 0);

                            PrivateIslandWorldSchematicLoader.placeRandomStarterIsland(world);

                            init.markInitialized();

                            LOG.info("Island {} created & initialized (decoration applied).", persistentId);
                            future.complete(world);

                        } catch (Exception e) {
                            CoreError error = CoreError.of(
                                            CoreErrorCode.PRIVATE_ISLAND_WORLD_CREATION_FAILED,
                                            CoreErrorSeverity.ERROR,
                                            "[PrivateIslands] Failed to create/decorate island world."
                                    )
                                    .withContextEntry("ownerId", ownerId)
                                    .withContextEntry("worldKey", worldKey.method_29177().toString())
                                    .withCause(e);

                            error.log();
                            future.completeExceptionally(
                                    new IllegalStateException(error.toLogString(), e)
                            );
                        }
                    });

                    return future;
                });
    }

    private void configureIslandWorldBorder(class_3218 world,
                                            int islandRadiusChunks,
                                            int oceanRadiusChunks) {
        int borderRadiusBlocks = PrivateIslandWorldEnv.BORDER_RADIUS * 16;

        LOG.info("Configuring island world border radius {} blocks (island={} chunks, ocean={} chunks) for world '{}'",
                borderRadiusBlocks,
                islandRadiusChunks,
                oceanRadiusChunks,
                world.method_27983().method_29177());

        try {
            server.method_3734().method_44252(
                    server.method_3739().method_9206(4),
                    "chunky border add " + world.method_27983().method_29177() + " circle 0.5 0.5 " + borderRadiusBlocks * 2
            );

            LOG.info("Configured border for '{}' -> radius {} blocks (island={} chunks, ocean={} chunks)",
                    world.method_27983().method_29177(),
                    borderRadiusBlocks,
                    islandRadiusChunks,
                    oceanRadiusChunks);
        } catch (Exception e) {
            CoreError error = CoreError.of(
                            CoreErrorCode.PRIVATE_ISLAND_BORDER_CONFIG_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to configure island world border via Chunky command."
                    )
                    .withContextEntry("worldKey", world.method_27983().method_29177().toString())
                    .withContextEntry("borderRadiusBlocks", borderRadiusBlocks)
                    .withContextEntry("islandRadiusChunks", islandRadiusChunks)
                    .withContextEntry("oceanRadiusChunks", oceanRadiusChunks)
                    .withCause(e);

            error.log();
        }
    }

    private CompletableFuture<class_3218> loadPersistentWorldAsync(MinecraftServer server,
                                                                    class_2960 id,
                                                                    RuntimeWorldConfig config) {
        PrivateIslandWorldService piws = PrivateIslandWorldService.get(server);
        return piws.getOrOpenPersistentWorld(id, config)
                .thenApply(RuntimeWorldHandle::asWorld);
    }

    private boolean worldDirExists(class_5321<class_1937> worldKey) {
        var session = ((MinecraftServerAccess) server).getSession();
        File dir = session.method_27424(worldKey).toFile();
        return dir.exists() && dir.isDirectory();
    }

    // ------------------------------------------------------------------------
    // Command-Entry / Node-Routing
    // ------------------------------------------------------------------------

    public void handleIslandCommand(class_3222 player) {
        var src = player.method_5671();
        if (!RateLimitUtil.checkPlayerRateLimit(src, player, RateLimitRules.ISLAND_TELEPORT, "island:command")) return;

        if (PrivateIslandWorldNodeConfig.IS_ISLAND_SERVER) {
            teleportPlayerToOwnIsland(player);
            return;
        }

        TaskScheduler scheduler = ServiceProvider.getService(TaskScheduler.class);
        if (scheduler == null) {
            player.method_7353(Messages.t(CoreMessage.ISLAND_NODE_INTERNAL_ERROR), false);
            return;
        }

        UUID ownerId = player.method_5667();
        player.method_7353(Messages.t(CoreMessage.ISLAND_PREPARE_START), false);

        // Alles Redis/IO async
        scheduler.runAsync(() -> {
            try {
                var ownerRepo = PrivateIslandWorldOwnerRepositoryRedis.get();

                String nodeId = selectBestIslandNodeId(ownerId);   // darf Redis machen
                if (nodeId == null) {
                    scheduler.runSync(() -> player.method_7353(Messages.t(CoreMessage.ISLAND_NO_NODE_CAPACITY), false));
                    return;
                }

                ownerRepo.assignOwnerToNode(ownerId, nodeId); // Redis write

                PrivateIslandWorldNodeStatus status = PrivateIslandWorldRepositoryRedis.get().getStatus(nodeId); // Redis read
                if (status == null) {
                    scheduler.runSync(() -> player.method_7353(Messages.t(CoreMessage.ISLAND_NODE_INTERNAL_ERROR), false));
                    return;
                }

                String targetServerName = status.serverName();

                // Back to main thread: teleport/proxy
                scheduler.runSync(() -> {
                    if (!player.field_13987.method_48106()) return;

                    PrivateIslandWorldPrepareClient.handleIslandCommandOnNonIslandServer(
                            server, player, nodeId, targetServerName
                    );
                });

            } catch (Exception e) {
                scheduler.runSync(() -> player.method_7353(Messages.t(CoreMessage.ISLAND_NODE_INTERNAL_ERROR), false));
            }
        });
    }

    @Nullable
    private String selectBestIslandNodeId(UUID ownerId) {
        var repo = PrivateIslandWorldRepositoryRedis.get();
        var all = repo.getAllStatuses();
        long heartbeatIntervalMs = 5_000; // oder aus Config ableiten
        return PrivateIslandWorldNodeSelector
                .selectBestIslandNode(all, heartbeatIntervalMs, ownerId)
                .map(PrivateIslandWorldNodeStatus::nodeId)
                .orElse(null);
    }
}
