package dev.huntertagog.coresystem.server.islands;

import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import dev.huntertagog.coresystem.common.text.CoreMessage;
import dev.huntertagog.coresystem.common.text.Messages;
import dev.huntertagog.coresystem.server.redis.RedisClient;
import dev.huntertagog.coresystem.server.task.TaskScheduler;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import redis.clients.jedis.Jedis;

import java.time.Duration;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public final class PrivateIslandWorldPrepareClient {

    private static final Logger LOG = LoggerFactory.get("IslandPrepareClient");

    // z. B. 30 Sekunden Timeout
    private static final Duration PREPARE_TIMEOUT = Duration.ofSeconds(90);

    private PrivateIslandWorldPrepareClient() {
    }

    /**
     * End-to-end:
     * - sendet Prepare-Request an Island-Node
     * - wartet auf OK (Redis Pub/Sub)
     * - wechselt danach per Proxy auf den Zielserver
     */
    public static void handleIslandCommandOnNonIslandServer(MinecraftServer server,
                                                            class_3222 player,
                                                            String targetNodeId,
                                                            String targetServerName) {
        TaskScheduler scheduler = ServiceProvider.getService(TaskScheduler.class);
        if (scheduler == null) {
            UUID ownerId = player.method_5667();

            CoreError error = CoreError.of(
                            CoreErrorCode.ISLAND_PREPARE_SCHEDULER_MISSING, // an deine Enum anpassen
                            CoreErrorSeverity.ERROR,
                            "TaskScheduler not available – cannot handle island command."
                    )
                    .withContextEntry("playerName", player.method_7334().getName())
                    .withContextEntry("ownerId", ownerId.toString())
                    .withContextEntry("targetNodeId", targetNodeId)
                    .withContextEntry("targetServerName", targetServerName);
            error.log();

            player.method_7353(
                    Messages.t(CoreMessage.ISLAND_NO_WORLD_AVAILABLE),
                    false
            );
            return;
        }

        UUID ownerId = player.method_5667();
        UUID requestId = UUID.randomUUID();

        player.method_7353(Messages.t(CoreMessage.ISLAND_PREPARE_START), false);
        LOG.info("Sending island prepare request for owner '{}' to node '{}'", ownerId, targetNodeId);

        prepareIsland(ownerId, targetNodeId, requestId, scheduler).whenComplete((success, throwable) -> {
            // Zurück auf den Server-Thread
            scheduler.runSync(() -> {
                if (!player.field_13987.method_48106()) {
                    LOG.warn("Player '{}' disconnected before island was ready.",
                            player.method_7334().getName());
                    return;
                }

                if (throwable != null || !Boolean.TRUE.equals(success)) {
                    String err = throwable != null ? throwable.getMessage() : "unknown error";

                    CoreError error = CoreError.of(
                                    CoreErrorCode.ISLAND_PREPARE_FAILED, // an deine Enum anpassen
                                    CoreErrorSeverity.WARN,
                                    "Island preparation failed."
                            )
                            .withContextEntry("ownerId", ownerId.toString())
                            .withContextEntry("targetNodeId", targetNodeId)
                            .withContextEntry("targetServerName", targetServerName)
                            .withContextEntry("requestId", requestId.toString());
                    error.log();

                    player.method_7353(
                            Messages.t(CoreMessage.ISLAND_PREPARE_FAILED, err),
                            false
                    );
                    return;
                }

                LOG.info("Island prepared, sending player '{}' to server '{}' via proxycommand",
                        player.method_7334().getName(), targetServerName);

                PrivateIslandWorldService.sendToServer(server, player, targetServerName);
            });
        });
    }

    /**
     * Sendet einen Prepare-Request und wartet via Redis Pub/Sub auf die Antwort.
     * Läuft komplett über den TaskScheduler (async + Timeout).
     */
    public static CompletableFuture<Boolean> prepareIsland(UUID ownerId, String nodeId, UUID requestId, TaskScheduler scheduler) {
        PrivateIslandPrepareResponseBus.get().startIfNeeded();

        String requestChannel = PrivateIslandWorldRedisProtocol.requestChannel(nodeId);
        String payload = PrivateIslandWorldRedisProtocol.formatRequest(requestId, ownerId);

        CompletableFuture<Boolean> future =
                PrivateIslandPrepareResponseBus.get().register(requestId, PREPARE_TIMEOUT.toMillis());

        scheduler.runAsync(() -> {
            try (Jedis pub = RedisClient.get().getResource()) {
                long receivers = pub.publish(requestChannel, payload);
                LOG.info("Prepare published (receivers={}) reqId={} owner={} node={}", receivers, requestId, ownerId, nodeId);
            } catch (Exception e) {
                if (!future.isDone()) future.completeExceptionally(e);
            }
        });

        return future;
    }
}
