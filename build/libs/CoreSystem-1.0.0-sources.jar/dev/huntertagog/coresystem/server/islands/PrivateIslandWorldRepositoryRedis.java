package dev.huntertagog.coresystem.server.islands;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.common.islands.PrivateIslandNodeRepository;
import dev.huntertagog.coresystem.common.islands.PrivateIslandWorldNodeStatus;
import dev.huntertagog.coresystem.server.redis.RedisClient;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.Pipeline;
import redis.clients.jedis.Response;
import redis.clients.jedis.params.ScanParams;
import redis.clients.jedis.resps.ScanResult;

import java.time.Duration;
import java.util.*;

public final class PrivateIslandWorldRepositoryRedis implements PrivateIslandNodeRepository {

    private static final Logger LOG = LoggerFactory.get("IslandNodeRepo");
    private static final PrivateIslandWorldRepositoryRedis INSTANCE = new PrivateIslandWorldRepositoryRedis();

    // Redis Keys
    private static final String NODE_PREFIX = "coresystem:islands:node:";
    private static final String NODES_SET = "coresystem:islands:nodes";

    // TTL: Node gilt nach X Sekunden ohne Heartbeat als stale (Hash läuft ab)
    private static final int STATUS_TTL_SECONDS = 15;

    // NodeId -> Status (lokaler Read-Cache)
    private final Cache<@NotNull String, PrivateIslandWorldNodeStatus> nodeCache = Caffeine.newBuilder()
            .maximumSize(256)
            .expireAfterWrite(Duration.ofSeconds(2))
            .build();

    // "all" -> Liste aller Nodes (lokaler Read-Cache)
    private final Cache<@NotNull String, Collection<PrivateIslandWorldNodeStatus>> allNodesCache = Caffeine.newBuilder()
            .maximumSize(1)
            .expireAfterWrite(Duration.ofSeconds(2))
            .build();

    private PrivateIslandWorldRepositoryRedis() {
    }

    public static PrivateIslandWorldRepositoryRedis get() {
        return INSTANCE;
    }

    private String nodeKey(String nodeId) {
        return NODE_PREFIX + nodeId;
    }

    @Override
    public void saveStatus(PrivateIslandWorldNodeStatus status) {
        String key = nodeKey(status.nodeId());

        // Alles in EINEM Map schreiben + Pipeline (1 RTT)
        Map<String, String> fields = new HashMap<>(16);
        fields.put("nodeId", status.nodeId());
        fields.put("serverName", status.serverName());
        fields.put("islandServer", Boolean.toString(status.islandServer()));
        fields.put("currentIslands", Integer.toString(status.currentIslands()));
        fields.put("maxIslands", Integer.toString(status.maxIslands()));
        fields.put("currentPlayers", Integer.toString(status.currentPlayers()));
        fields.put("maxPlayers", Integer.toString(status.maxPlayers()));
        fields.put("lastHeartbeatMillis", Long.toString(status.lastHeartbeatMillis()));

        try (Jedis jedis = RedisClient.get().getResource()) {
            Pipeline p = jedis.pipelined();
            p.hset(key, fields);
            p.expire(key, STATUS_TTL_SECONDS);
            p.sadd(NODES_SET, status.nodeId());
            p.sync();
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.ISLAND_NODE_SAVE_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to save IslandNodeStatus to Redis."
                    )
                    .withCause(e)
                    .withContextEntry("nodeId", status.nodeId())
                    .withContextEntry("serverName", status.serverName())
                    .log();
        }

        // Lokale Caches
        nodeCache.put(status.nodeId(), status);
        allNodesCache.invalidateAll();
    }

    @Override
    public @Nullable PrivateIslandWorldNodeStatus getStatus(String nodeId) {
        PrivateIslandWorldNodeStatus cached = nodeCache.getIfPresent(nodeId);
        if (cached != null) return cached;

        try (Jedis jedis = RedisClient.get().getResource()) {
            Map<String, String> map = jedis.hgetAll(nodeKey(nodeId));
            if (map == null || map.isEmpty()) return null;

            PrivateIslandWorldNodeStatus status = mapToStatus(map);
            nodeCache.put(nodeId, status);
            return status;
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.ISLAND_NODE_LOAD_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to load IslandNodeStatus from Redis."
                    )
                    .withCause(e)
                    .withContextEntry("nodeId", nodeId)
                    .log();
            return null;
        }
    }

    @Override
    public Collection<PrivateIslandWorldNodeStatus> getAllStatuses() {
        return allNodesCache.get("all", __ -> loadAllFromRedisScan(200));
    }

    /**
     * SSCAN statt SMEMBERS: nicht-blockierend, limitierbar.
     * limit = max NodeIds die wir pro Read verarbeiten.
     */
    private Collection<PrivateIslandWorldNodeStatus> loadAllFromRedisScan(int limit) {
        if (limit <= 0) return List.of();

        List<String> nodeIds = new ArrayList<>(Math.min(limit, 256));

        try (Jedis jedis = RedisClient.get().getResource()) {
            String cursor = ScanParams.SCAN_POINTER_START;
            ScanParams params = new ScanParams().count(Math.min(limit, 200));

            do {
                ScanResult<String> res = jedis.sscan(NODES_SET, cursor, params);
                cursor = res.getCursor();

                for (String id : res.getResult()) {
                    if (id == null || id.isBlank()) continue;
                    nodeIds.add(id);
                    if (nodeIds.size() >= limit) break;
                }
            } while (!"0".equals(cursor) && nodeIds.size() < limit);

            // Pipelined HGETALL: 1 RTT + Antworten
            Pipeline p = jedis.pipelined();
            List<Response<Map<String, String>>> responses = new ArrayList<>(nodeIds.size());
            for (String nodeId : nodeIds) {
                responses.add(p.hgetAll(nodeKey(nodeId)));
            }
            p.sync();

            List<PrivateIslandWorldNodeStatus> out = new ArrayList<>(nodeIds.size());

            for (int i = 0; i < nodeIds.size(); i++) {
                String nodeId = nodeIds.get(i);
                Map<String, String> map = responses.get(i).get();
                if (map == null || map.isEmpty()) {
                    // Hash ist abgelaufen => Node ist stale -> aus Index entfernen (best effort)
                    try {
                        jedis.srem(NODES_SET, nodeId);
                    } catch (Exception ignored) {
                    }
                    continue;
                }

                PrivateIslandWorldNodeStatus status = mapToStatus(map);
                nodeCache.put(nodeId, status);
                out.add(status);
            }

            return out;
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.ISLAND_NODE_LOAD_ALL_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to load all IslandNodeStatus entries from Redis (SSCAN+pipelined)."
                    )
                    .withCause(e)
                    .log();
            return List.of();
        }
    }

    private PrivateIslandWorldNodeStatus mapToStatus(Map<String, String> map) {
        try {
            String nodeId = map.getOrDefault("nodeId", "unknown");
            String serverName = map.getOrDefault("serverName", nodeId);
            boolean islandServer = Boolean.parseBoolean(map.getOrDefault("islandServer", "false"));
            int currentIslands = Integer.parseInt(map.getOrDefault("currentIslands", "0"));
            int maxIslands = Integer.parseInt(map.getOrDefault("maxIslands", "0"));
            int currentPlayers = Integer.parseInt(map.getOrDefault("currentPlayers", "0"));
            int maxPlayers = Integer.parseInt(map.getOrDefault("maxPlayers", "0"));
            long lastHeartbeat = Long.parseLong(map.getOrDefault("lastHeartbeatMillis", "0"));

            return new PrivateIslandWorldNodeStatus(
                    nodeId, serverName, islandServer,
                    currentIslands, maxIslands, currentPlayers, maxPlayers,
                    lastHeartbeat
            );
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.ISLAND_NODE_STATUS_PARSE_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to map Redis hash to IslandNodeStatus."
                    )
                    .withCause(e)
                    .withContextEntry("rawMap", map.toString())
                    .log();

            String nodeId = map.getOrDefault("nodeId", "unknown");
            String serverName = map.getOrDefault("serverName", nodeId);
            return new PrivateIslandWorldNodeStatus(nodeId, serverName, false, 0, 0, 0, 0, 0L);
        }
    }
}
