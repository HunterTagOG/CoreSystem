package dev.huntertagog.coresystem.server.islands;

import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.server.redis.RedisClient;
import dev.huntertagog.coresystem.server.task.TaskScheduler;
import net.minecraft.server.MinecraftServer;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPubSub;

import java.util.UUID;

public final class PrivateIslandWorldPrepareWorker {

    private static final Logger LOG = LoggerFactory.get("IslandPrepareWorker");

    private final MinecraftServer server;
    private final String nodeId;
    private final TaskScheduler scheduler;

    private volatile boolean running = false;
    private volatile JedisPubSub subscriber;
    private volatile Jedis jedis;

    public PrivateIslandWorldPrepareWorker(MinecraftServer server,
                                           String nodeId,
                                           TaskScheduler scheduler) {
        this.server = server;
        this.nodeId = nodeId;
        this.scheduler = scheduler;
    }

    /**
     * Startet den Worker asynchron über den CoreTaskScheduler.
     */
    public void start() {
        if (running) return;
        running = true;

        LOG.info("Starting IslandPrepareWorker for node '{}'.", nodeId);

        Thread t = new Thread(this::runSubscriber, "IslandPrepareSubscriber-" + nodeId);
        t.setDaemon(true);
        t.start();
    }

    /**
     * Stoppt den Worker. Beendet Subscription und schließt die Redis-Connection.
     */
    public void shutdown() {
        if (!running) {
            return;
        }

        LOG.info("Shutdown requested for IslandPrepareWorker on node '{}'.", nodeId);
        running = false;

        JedisPubSub localSub = this.subscriber;
        Jedis localJedis = this.jedis;

        // 1) Redis-Subscription beenden
        if (localSub != null) {
            try {
                localSub.unsubscribe();
            } catch (Exception e) {
                CoreError.of(
                                CoreErrorCode.ISLAND_PREPARE_WORKER_UNSUBSCRIBE_FAILED, // anpassen
                                CoreErrorSeverity.WARN,
                                "Error while unsubscribing IslandPrepareWorker."
                        )
                        .withCause(e)
                        .withContextEntry("nodeId", nodeId)
                        .log();
            }
        }

        // 2) Jedis-Connection explizit schließen (falls noch offen)
        if (localJedis != null) {
            try {
                localJedis.close();
            } catch (Exception e) {
                CoreError.of(
                                CoreErrorCode.ISLAND_PREPARE_WORKER_CLOSE_JEDIS_FAILED, // anpassen
                                CoreErrorSeverity.WARN,
                                "Error while closing Jedis in IslandPrepareWorker."
                        )
                        .withCause(e)
                        .withContextEntry("nodeId", nodeId)
                        .log();
            }
        }
    }

    // --------------------------------------------------------
    // Intern: Redis-Subscriber-Loop
    // --------------------------------------------------------

    private void runSubscriber() {
        String channel = PrivateIslandWorldRedisProtocol.requestChannel(nodeId);
        LOG.info("IslandPrepareWorker listening on channel '{}'.", channel);

        JedisPubSub localSub = new JedisPubSub() {
            @Override
            public void onMessage(String ch, String message) {
                handlePrepareMessage(message);
            }
        };
        subscriber = localSub;

        try (Jedis j = RedisClient.get().getResource()) {
            jedis = j;
            // Blockiert, bis unsubscribe() oder Connection-Close
            j.subscribe(localSub, channel);
        } catch (Exception e) {
            if (running) {
                CoreError.of(
                                CoreErrorCode.ISLAND_PREPARE_WORKER_SUBSCRIBE_FAILED, // anpassen
                                CoreErrorSeverity.ERROR,
                                "IslandPrepareWorker subscribe loop failed."
                        )
                        .withCause(e)
                        .withContextEntry("nodeId", nodeId)
                        .withContextEntry("channel", channel)
                        .log();
            } else {
                LOG.info("IslandPrepareWorker for node '{}' stopped gracefully.", nodeId);
            }
        } finally {
            jedis = null;
            subscriber = null;
            running = false;
        }
    }

    private void handlePrepareMessage(String message) {
        if (!running || server.method_16043()) {
            LOG.info("Ignoring prepare message during shutdown: '{}'", message);
            return;
        }

        try {
            String[] parts = message.split(";");
            if (parts.length < 2) {
                CoreError.of(
                                CoreErrorCode.ISLAND_PREPARE_WORKER_INVALID_MESSAGE, // anpassen
                                CoreErrorSeverity.WARN,
                                "Invalid island prepare message."
                        )
                        .withContextEntry("nodeId", nodeId)
                        .withContextEntry("message", message)
                        .log();
                return;
            }

            UUID requestId = UUID.fromString(parts[0]);
            UUID ownerId = UUID.fromString(parts[1]);

            LOG.info("Received island prepare request requestId='{}', owner='{}'", requestId, ownerId);

            PrivateIslandWorldManager manager = PrivateIslandWorldManager.get(server);

            // Island asynchron vorbereiten
            manager.getOrCreateIslandWorld(ownerId).whenComplete((world, throwable) -> {
                String respChannel = PrivateIslandWorldRedisProtocol.responseChannel(requestId);

                try (Jedis pub = RedisClient.get().getResource()) {
                    if (throwable != null || world == null) {
                        String err = throwable != null ? throwable.getMessage() : "world is null";
                        String payload = PrivateIslandWorldRedisProtocol
                                .formatErrResponse(requestId, ownerId, err);
                        pub.publish(respChannel, payload);

                        CoreError.of(
                                        CoreErrorCode.ISLAND_PREPARE_WORKER_WORLD_FAILED, // anpassen
                                        CoreErrorSeverity.WARN,
                                        "Island prepare failed while creating/loading world."
                                )
                                .withContextEntry("nodeId", nodeId)
                                .withContextEntry("ownerId", ownerId.toString())
                                .withContextEntry("requestId", requestId.toString())
                                .withContextEntry("respChannel", respChannel)
                                .withContextEntry("error", err)
                                .log();
                    } else {
                        String payload = PrivateIslandWorldRedisProtocol
                                .formatOkResponse(requestId, ownerId);
                        pub.publish(respChannel, payload);
                        LOG.info("Island prepared successfully for owner '{}' (world='{}').",
                                ownerId, world.method_27983().method_29177());
                    }
                } catch (Exception e) {
                    CoreError.of(
                                    CoreErrorCode.ISLAND_PREPARE_WORKER_PUBLISH_FAILED, // anpassen
                                    CoreErrorSeverity.ERROR,
                                    "Error while publishing island prepare response."
                            )
                            .withCause(e)
                            .withContextEntry("nodeId", nodeId)
                            .withContextEntry("ownerId", ownerId.toString())
                            .withContextEntry("requestId", requestId.toString())
                            .withContextEntry("respChannel", respChannel)
                            .log();
                }
            });

        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.ISLAND_PREPARE_WORKER_HANDLE_FAILED, // anpassen
                            CoreErrorSeverity.ERROR,
                            "Error handling island prepare message."
                    )
                    .withCause(e)
                    .withContextEntry("nodeId", nodeId)
                    .withContextEntry("message", message)
                    .log();
        }
    }
}
