package dev.huntertagog.coresystem.server.islands;

import lombok.Getter;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_7225;

public final class PrivateIslandInitState extends class_18 {
    public static final String KEY = "coresystem_island_init";

    private static final int CURRENT_SCHEMA = 1;

    // --------- getters/setters (minimal) ----------
    @Getter
    private boolean initialized = false;
    private int schema = CURRENT_SCHEMA;

    private long initEpochMs = 0L;

    // optional, aber sehr hilfreich fürs Troubleshooting
    private long seed = 0L;
    private String preset = "";   // z.B. REALISTIC_SINGLE
    private String style = "";    // z.B. MIXED
    private String configHash = ""; // z.B. sha1/xxhash64 von RuntimeWorldConfig/Env

    public PrivateIslandInitState() {
    }

    public static final class_18.class_8645<PrivateIslandInitState> TYPE =
            new class_18.class_8645<>(
                    PrivateIslandInitState::new,
                    PrivateIslandInitState::fromNbt,
                    null // passt für custom saved data
            );

    public void markInitialized() {
        this.initialized = true;
        this.initEpochMs = System.currentTimeMillis();
        this.schema = CURRENT_SCHEMA;
        this.method_80(); // wichtig: damit MC es speichert
    }

    public void setDebugMeta(long seed, String preset, String style, String configHash) {
        this.seed = seed;
        this.preset = preset != null ? preset : "";
        this.style = style != null ? style : "";
        this.configHash = configHash != null ? configHash : "";
        this.method_80();
    }

    public void setUninitialized() {
        this.initialized = false;
        this.method_80();
    }

    // --------- PersistentState serialization ----------
    @Override
    public class_2487 method_75(class_2487 nbt, class_7225.class_7874 registryLookup) {
        nbt.method_10569("schema", schema);
        nbt.method_10556("initialized", initialized);
        nbt.method_10544("initEpochMs", initEpochMs);

        // optional meta
        nbt.method_10544("seed", seed);
        if (!preset.isEmpty()) nbt.method_10582("preset", preset);
        if (!style.isEmpty()) nbt.method_10582("style", style);
        if (!configHash.isEmpty()) nbt.method_10582("configHash", configHash);

        return nbt;
    }

    public static PrivateIslandInitState fromNbt(class_2487 nbt, class_7225.class_7874 lookup) {
        PrivateIslandInitState s = new PrivateIslandInitState();

        // Schema/Versioning (Migration-ready)
        int schema = nbt.method_10573("schema", class_2487.field_33253) ? nbt.method_10550("schema") : 0;
        s.schema = schema;

        // Backward-compatible reads
        s.initialized = nbt.method_10577("initialized");
        s.initEpochMs = nbt.method_10573("initEpochMs", class_2487.field_33254) ? nbt.method_10537("initEpochMs") : 0L;

        // optional meta
        s.seed = nbt.method_10573("seed", class_2487.field_33254) ? nbt.method_10537("seed") : 0L;
        s.preset = nbt.method_10573("preset", class_2487.field_33258) ? nbt.method_10558("preset") : "";
        s.style = nbt.method_10573("style", class_2487.field_33258) ? nbt.method_10558("style") : "";
        s.configHash = nbt.method_10573("configHash", class_2487.field_33258) ? nbt.method_10558("configHash") : "";

        // Mini-Migration Beispiel: schema==0 -> schema=1 (falls du früher ohne schema gespeichert hast)
        if (s.schema < CURRENT_SCHEMA) {
            s.schema = CURRENT_SCHEMA;
            // keine markDirty() hier zwingend nötig, aber kann sinnvoll sein:
            // s.markDirty();
        }

        return s;
    }
}
