package dev.huntertagog.coresystem.server.permission;

import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.common.permission.CorePermission;
import dev.huntertagog.coresystem.common.permission.PermissionService;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.minecraft.class_2168;
import net.minecraft.class_3222;

public final class LuckPermsPermissionService implements PermissionService {

    private static final Logger LOGGER = LoggerFactory.get("LuckPermsPermissionService");

    private final LuckPerms luckPerms;

    public LuckPermsPermissionService() {
        LuckPerms lp = null;
        try {
            lp = LuckPermsProvider.get();
            LOGGER.info("LuckPermsPermissionService initialized – LuckPerms API available.");
        } catch (Exception ex) {

            // ------- CoreError Integration -------
            CoreError.of(
                            CoreErrorCode.PERMISSION_BACKEND_NOT_AVAILABLE,
                            CoreErrorSeverity.WARN,
                            "LuckPerms not present or not initialized."
                    ).withCause(ex)
                    .log();
            // -------------------------------------

        }
        this.luckPerms = lp;
    }

    @Override
    public boolean has(class_2168 source, CorePermission perm) {
        return has(source, perm.key());
    }

    @Override
    public boolean has(class_2168 source, String permissionNode) {

        // Konsole & Commandblocks: immer durchwinken
        if (!source.method_43737()) {
            return true;
        }

        // Fallback wenn LuckPerms fehlt
        if (luckPerms == null) {

            CoreError.of(
                            CoreErrorCode.PERMISSION_BACKEND_NOT_AVAILABLE,
                            CoreErrorSeverity.INFO,
                            "LuckPerms unavailable – using fallback permission policy."
                    ).withContextEntry("permission", permissionNode)
                    .log();

            return source.method_9259(2);
        }

        if (!(source.method_9228() instanceof class_3222 player)) {
            return true;
        }

        try {
            var adapter = luckPerms.getPlayerAdapter(class_3222.class);
            var tristate = adapter.getPermissionData(player).checkPermission(permissionNode);
            return tristate.asBoolean();

        } catch (Exception ex) {

            CoreError.of(
                            CoreErrorCode.PERMISSION_CHECK_FAILED,
                            CoreErrorSeverity.ERROR,
                            "Exception while checking permission via LuckPerms."
                    )
                    .withContextEntry("player", player.method_7334().getName())
                    .withContextEntry("permission", permissionNode)
                    .withCause(ex)
                    .log();
            return false; // konservative Fail-Policy
        }
    }
}
