package dev.huntertagog.coresystem.server.playerdata;

import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.common.playerdata.PlayerDataSyncService;
import dev.huntertagog.coresystem.common.playerdata.PlayerInventoryCodec;
import dev.huntertagog.coresystem.common.playerdata.PlayerInventorySnapshot;
import dev.huntertagog.coresystem.server.redis.RedisClient;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import redis.clients.jedis.Jedis;

import java.io.IOException;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_3222;

public final class RedisPlayerDataSyncService implements PlayerDataSyncService {

    private static final Logger LOG = LoggerFactory.get("PlayerDataSyncService");
    private static final String KEY_PREFIX = "cs:playerdata:inv:";
    private static final int TTL_SECONDS = 7 * 24 * 60 * 60; // 7 Tage

    @Override
    public void saveInventorySnapshot(@NotNull class_3222 player,
                                      @NotNull String context,
                                      @Nullable String reason) {

        UUID uuid = player.method_5667();
        String key = buildKey(uuid, context);

        String payload;
        try {
            payload = PlayerInventoryCodec.encodeInventoryToBase64(Objects.requireNonNull(player.method_5682()), player);
        } catch (IOException e) {
            CoreError.of(
                            CoreErrorCode.PLAYERDATA_NBT_ENCODE_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to encode inventory snapshot"
                    )
                    .withCause(e)
                    .withContextEntry("playerUuid", uuid.toString())
                    .withContextEntry("playerName", player.method_7334().getName())
                    .withContextEntry("context", context)
                    .log();
            return;
        }

        long now = System.currentTimeMillis();
        PlayerInventorySnapshot snapshot = new PlayerInventorySnapshot(
                uuid,
                context,
                now,
                payload,
                "v1"
        );

        try (Jedis jedis = RedisClient.get().getResource()) {
            // Simple JSON-ähnliche Struktur per String concat; für mehr Struktur ggf. Gson nutzen
            String value = snapshot.payloadBase64(); // vorerst nur Payload
            jedis.setex(key, TTL_SECONDS, value);
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.PLAYERDATA_REDIS_SAVE_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to save inventory snapshot to Redis"
                    )
                    .withCause(e)
                    .withContextEntry("redisKey", key)
                    .withContextEntry("playerUuid", uuid.toString())
                    .withContextEntry("playerName", player.method_7334().getName())
                    .withContextEntry("context", context)
                    .log();
            return;
        }

        LOG.debug("Saved inventory snapshot for {} ({}) context={}",
                player.method_7334().getName(), uuid, context);
    }

    @Override
    public @NotNull Optional<PlayerInventorySnapshot> findInventorySnapshot(@NotNull UUID uuid,
                                                                            @NotNull String context) {
        String key = buildKey(uuid, context);

        String payload;
        try (Jedis jedis = RedisClient.get().getResource()) {
            payload = jedis.get(key);
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.PLAYERDATA_REDIS_LOAD_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to load inventory snapshot from Redis"
                    )
                    .withCause(e)
                    .withContextEntry("redisKey", key)
                    .withContextEntry("playerUuid", uuid.toString())
                    .withContextEntry("context", context)
                    .log();
            return Optional.empty();
        }

        if (payload == null || payload.isEmpty()) {
            return Optional.empty();
        }

        long now = System.currentTimeMillis();
        PlayerInventorySnapshot snapshot = new PlayerInventorySnapshot(
                uuid,
                context,
                now, // createdAt nicht bekannt → jetzt; wenn du mehr willst, nimm Gson und speichere alles
                payload,
                "v1"
        );
        return Optional.of(snapshot);
    }

    @Override
    public boolean applyInventorySnapshot(@NotNull class_3222 player,
                                          @NotNull String context,
                                          boolean clearAfter) {

        UUID uuid = player.method_5667();
        Optional<PlayerInventorySnapshot> opt = findInventorySnapshot(uuid, context);
        if (opt.isEmpty()) {
            return false;
        }

        PlayerInventorySnapshot snapshot = opt.get();

        try {
            PlayerInventoryCodec.applyInventoryFromBase64(player.method_5682(), player, snapshot.payloadBase64());
        } catch (IOException e) {
            CoreError.of(
                            CoreErrorCode.PLAYERDATA_NBT_DECODE_FAILED,
                            CoreErrorSeverity.ERROR,
                            "Failed to apply inventory snapshot (NBT decode failed)"
                    )
                    .withCause(e)
                    .withContextEntry("playerUuid", uuid.toString())
                    .withContextEntry("playerName", player.method_7334().getName())
                    .withContextEntry("context", context)
                    .log();
            return false;
        }

        if (clearAfter) {
            deleteInventorySnapshot(uuid, context);
        }

        LOG.debug("Applied inventory snapshot for {} ({}) context={}",
                player.method_7334().getName(), uuid, context);
        return true;
    }

    @Override
    public void deleteInventorySnapshot(@NotNull UUID uuid, @NotNull String context) {
        String key = buildKey(uuid, context);
        try (Jedis jedis = RedisClient.get().getResource()) {
            jedis.del(key);
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.PLAYERDATA_REDIS_DELETE_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to delete inventory snapshot from Redis"
                    )
                    .withCause(e)
                    .withContextEntry("redisKey", key)
                    .withContextEntry("playerUuid", uuid.toString())
                    .withContextEntry("context", context)
                    .log();
        }
    }

    private static String buildKey(UUID uuid, String context) {
        // Kontext klein & safe halten (ohne Leerzeichen)
        String normalizedContext = context.toLowerCase().replace(' ', '_');
        return KEY_PREFIX + normalizedContext + ":" + uuid;
    }
}
