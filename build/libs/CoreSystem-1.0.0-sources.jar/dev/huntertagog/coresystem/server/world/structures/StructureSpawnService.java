package dev.huntertagog.coresystem.server.world.structures;

import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.common.provider.Service;
import dev.huntertagog.coresystem.server.world.structures.config.StructureSpawnConfig;
import dev.huntertagog.coresystem.server.world.structures.config.StructureSpawnConfig.Group;
import dev.huntertagog.coresystem.server.world.structures.config.StructureSpawnConfig.StructureEntry;
import dev.huntertagog.coresystem.server.world.structures.config.StructureSpawnConfigLoader;
import dev.huntertagog.coresystem.server.world.structures.state.StructureSpawnState;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2791;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.class_3532;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.io.File;
import java.util.*;

/**
 * Steuert die Placement-Logik für konfigurierbare NBT-Strukturen:
 * - gruppenbasierter Mindestabstand
 * - Biome-Filter
 * - y_offset relativ zur Terrainhöhe
 * - Terrain-Slope-Checks
 */
public final class StructureSpawnService implements Service {

    private static final Logger LOG = LoggerFactory.get("StructureSpawnService");

    private final File configDir;
    private StructureSpawnConfig config;

    public StructureSpawnService(File configDir) {
        this.configDir = configDir;

        try {
            this.config = StructureSpawnConfigLoader.load(configDir);
        } catch (Exception e) {
            CoreError error = CoreError.of(
                            CoreErrorCode.MESSAGE_ERROR,
                            CoreErrorSeverity.ERROR,
                            "Failed to load StructureSpawnConfig on startup"
                    )
                    .withContextEntry("configDir", safePath(configDir))
                    .withContextEntry("exception", e.toString());
            error.log();

            LOG.error("Failed to load structure spawn config from {} during service init.", safePath(configDir), e);
            // Re-throw, damit das Fehlverhalten sichtbar bleibt
            throw e;
        }

        ServerWorldEvents.LOAD.register(this::onWorldLoad);
        ServerChunkEvents.CHUNK_LOAD.register(this::onChunkLoad);
    }

    // -----------------------------
    // Hot-Reload API
    // -----------------------------

    public void reload(MinecraftServer server) {
        StructureSpawnConfig newConfig;
        try {
            newConfig = StructureSpawnConfigLoader.load(this.configDir);
        } catch (Exception e) {
            CoreError error = CoreError.of(
                            CoreErrorCode.MESSAGE_ERROR,
                            CoreErrorSeverity.ERROR,
                            "Failed to reload StructureSpawnConfig"
                    )
                    .withContextEntry("configDir", safePath(configDir))
                    .withContextEntry("exception", e.toString());
            error.log();

            LOG.error("Failed to reload structure spawn config from {}. Keeping previous config.", safePath(configDir), e);
            return;
        }

        this.config = newConfig;

        for (class_3218 world : server.method_3738()) {
            if (!world.method_27983().equals(class_1937.field_25179)) continue;

            try {
                StructureSpawnState state = StructureSpawnState.get(world);
                state.getStructures().clear();
                state.method_80();

                planWorldTargets(world);
            } catch (Exception e) {
                CoreError error = CoreError.of(
                                CoreErrorCode.MESSAGE_ERROR,
                                CoreErrorSeverity.WARN,
                                "Failed to re-plan structure spawn targets on reload"
                        )
                        .withContextEntry("world", world.method_27983().method_29177().toString())
                        .withContextEntry("exception", e.toString());
                error.log();

                LOG.warn("Error while re-planning structure targets for world {} on reload.",
                        world.method_27983().method_29177(), e);
            }
        }
    }

    private static String safePath(File file) {
        return file != null ? file.getPath() : "<null>";
    }

    // -----------------------------
    // World-Load: Ziele generieren
    // -----------------------------

    private void onWorldLoad(MinecraftServer server, class_3218 world) {
        if (!world.method_27983().equals(class_1937.field_25179)) return;

        try {
            planWorldTargets(world);
        } catch (Exception e) {
            CoreError error = CoreError.of(
                            CoreErrorCode.MESSAGE_ERROR,
                            CoreErrorSeverity.WARN,
                            "Failed to plan structure spawn targets on world load"
                    )
                    .withContextEntry("world", world.method_27983().method_29177().toString())
                    .withContextEntry("exception", e.toString());
            error.log();

            LOG.warn("Error while planning structure targets for world {} on load.",
                    world.method_27983().method_29177(), e);
        }
    }

    private void planWorldTargets(class_3218 world) {
        if (config == null || config.groups == null || config.groups.isEmpty()) {
            CoreError error = CoreError.of(
                            CoreErrorCode.MESSAGE_ERROR,
                            CoreErrorSeverity.WARN,
                            "StructureSpawnService.planWorldTargets called with missing or empty config"
                    )
                    .withContextEntry("world", world.method_27983().method_29177().toString())
                    .withContextEntry("configDir", safePath(configDir));
            error.log();

            LOG.warn("Skipping structure planning for world {}: config missing or has no groups.",
                    world.method_27983().method_29177());
            return;
        }

        StructureSpawnState state = StructureSpawnState.get(world);
        net.minecraft.class_5819 random = world.method_8409();

        for (Group group : config.groups) {
            if (group.structures == null || group.structures.isEmpty()) continue;

            int radius = Math.max(1, group.world_radius);
            int minDistance = Math.max(0, group.min_distance);
            int minDistanceSq = minDistance * minDistance;

            List<class_2338> groupTargets = collectGroupTargets(state, group);

            for (StructureEntry entry : group.structures) {
                if (entry.id == null || entry.id.isBlank() || entry.count <= 0) continue;

                class_2960 structId = class_2960.method_60654(entry.id);
                StructureSpawnState.StructureData data = state.getOrCreate(structId);

                while (data.targets.size() < entry.count) {
                    class_2338 candidate = findValidSpawnPosition(
                            world, random, radius, entry, groupTargets, minDistanceSq
                    );

                    if (candidate == null) {
                        CoreError error = CoreError.of(
                                        CoreErrorCode.MESSAGE_ERROR,
                                        CoreErrorSeverity.WARN,
                                        "Could not find valid spawn position for structure"
                                )
                                .withContextEntry("structureId", entry.id)
                                .withContextEntry("world", world.method_27983().method_29177().toString())
                                .withContextEntry("radius", String.valueOf(radius))
                                .withContextEntry("minDistance", String.valueOf(minDistance))
                                .withContextEntry("requestedCount", String.valueOf(entry.count))
                                .withContextEntry("currentPlanned", String.valueOf(data.targets.size()));
                        error.log();

                        LOG.warn("No valid spawn position found for structure '{}' in world {} (planned {}/{}).",
                                entry.id, world.method_27983().method_29177(),
                                data.targets.size(), entry.count);
                        break;
                    }

                    data.targets.add(candidate);
                    groupTargets.add(candidate);
                    state.method_80();
                }
            }
        }
    }

    private List<class_2338> collectGroupTargets(StructureSpawnState state, Group group) {
        List<class_2338> result = new ArrayList<>();
        if (group.structures == null) return result;

        for (StructureEntry entry : group.structures) {
            if (entry.id == null || entry.id.isBlank()) continue;
            class_2960 structId = class_2960.method_60654(entry.id);
            StructureSpawnState.StructureData data = state.getStructures().get(structId);
            if (data == null) continue;
            result.addAll(data.targets);
        }

        return result;
    }

    // -----------------------------
    // Chunk-Load: Platzierung
    // -----------------------------

    private void onChunkLoad(class_3218 world, class_2791 chunk) {
        StructureSpawnState state = StructureSpawnState.get(world);
        Map<class_2960, StructureSpawnState.StructureData> map = state.getStructures();

        class_1923 chunkPos = chunk.method_12004();
        int minX = chunkPos.method_8326();
        int maxX = chunkPos.method_8327();
        int minZ = chunkPos.method_8328();
        int maxZ = chunkPos.method_8329();

        boolean changed = false;

        for (Map.Entry<class_2960, StructureSpawnState.StructureData> entry : map.entrySet()) {
            class_2960 structId = entry.getKey();
            StructureSpawnState.StructureData data = entry.getValue();
            if (data.isFullyPlaced()) continue;

            for (int i = 0; i < data.targets.size(); i++) {
                if (data.placed.get(i)) continue;

                class_2338 target = data.targets.get(i);

                boolean isInThisChunk =
                        target.method_10263() >= minX && target.method_10263() <= maxX &&
                                target.method_10260() >= minZ && target.method_10260() <= maxZ;

                if (!isInThisChunk) continue;

                try {
                    if (placeStructure(world, target, structId)) {
                        data.placed.set(i);
                        changed = true;
                    }
                } catch (Exception e) {
                    CoreError error = CoreError.of(
                                    CoreErrorCode.MESSAGE_ERROR,
                                    CoreErrorSeverity.WARN,
                                    "Exception while placing structure"
                            )
                            .withContextEntry("structureId", structId.toString())
                            .withContextEntry("world", world.method_27983().method_29177().toString())
                            .withContextEntry("target", target.method_23854())
                            .withContextEntry("exception", e.toString());
                    error.log();

                    LOG.warn("Error while placing structure '{}' at {} in world {}.",
                            structId, target.method_23854(), world.method_27983().method_29177(), e);
                }
            }
        }

        if (changed) {
            state.method_80();
        }
    }

    // -----------------------------
    // Strukturplatzierung
    // -----------------------------

    private boolean placeStructure(class_3218 world, class_2338 origin, class_2960 structureId) {
        var manager = world.method_14183();
        Optional<class_3499> templateOpt = manager.method_15094(structureId);

        if (templateOpt.isEmpty()) {
            CoreError error = CoreError.of(
                            CoreErrorCode.MESSAGE_ERROR,
                            CoreErrorSeverity.WARN,
                            "Structure template not found"
                    )
                    .withContextEntry("structureId", structureId.toString())
                    .withContextEntry("world", world.method_27983().method_29177().toString())
                    .withContextEntry("origin", origin.method_23854());
            error.log();

            LOG.warn("Structure template '{}' not found for placement in world {} at {}.",
                    structureId, world.method_27983().method_29177(), origin.method_23854());
            return false;
        }

        class_3499 template = templateOpt.get();
        net.minecraft.class_5819 random = world.method_8409();

        class_2470 rotation = class_2470.values()[random.method_43048(class_2470.values().length)];
        class_2415 mirror = random.method_43056() ? class_2415.field_11302 : class_2415.field_11301;

        class_3492 placement = new class_3492()
                .method_15133(false)
                .method_15123(rotation)
                .method_15125(mirror);
        // .setIgnoreAirBlocks(true); // falls du später Terrain schützen willst

        return template.method_15172(world, origin, origin, placement, random, 2);
    }

    // -----------------------------
    // Positionsermittlung & Checks
    // -----------------------------

    private class_2338 findValidSpawnPosition(class_3218 world,
                                            net.minecraft.class_5819 random,
                                            int radius,
                                            StructureEntry entry,
                                            List<class_2338> groupTargets,
                                            int minDistanceSq) {

        for (int attempt = 0; attempt < 256; attempt++) {
            int x = class_3532.method_15395(random, -radius, radius);
            int z = class_3532.method_15395(random, -radius, radius);

            int surfaceY = world.method_8624(class_2902.class_2903.field_13194, x, z);
            int originY = surfaceY + entry.y_offset; // zentrale y_offset-Logik

            class_2338 origin = new class_2338(x, originY, z);

            if (!isBiomeAllowedForEntry(world, origin, entry)) continue;
            if (!isTerrainSlopeOk(world, new class_2338(x, surfaceY, z))) continue;
            if (!isSurfaceBlockOk(world, new class_2338(x, surfaceY - 1, z))) continue;
            if (!world.method_8316(new class_2338(x, surfaceY, z)).method_15769()) continue;
            if (!isFarEnoughFromOthers(origin, groupTargets, minDistanceSq)) continue;

            return origin;
        }

        return null;
    }

    private boolean isBiomeAllowedForEntry(class_3218 world, class_2338 pos, StructureEntry entry) {
        if (entry.biomes == null || entry.biomes.isEmpty()) {
            return true;
        }

        var biome = world.method_23753(pos).comp_349();
        var biomeKeyOpt = world.method_30349()
                .method_30530(class_7924.field_41236)
                .method_29113(biome);

        if (biomeKeyOpt.isEmpty()) return false;

        class_2960 biomeId = biomeKeyOpt.get().method_29177();

        for (String allowed : entry.biomes) {
            if (biomeId.toString().equals(allowed)) {
                return true;
            }
        }

        return false;
    }

    private boolean isTerrainSlopeOk(class_3218 world, class_2338 surfacePos) {
        int x = surfacePos.method_10263();
        int z = surfacePos.method_10260();

        int yCenter = surfacePos.method_10264();
        int yN = world.method_8624(class_2902.class_2903.field_13194, x, z - 4);
        int yS = world.method_8624(class_2902.class_2903.field_13194, x, z + 4);
        int yW = world.method_8624(class_2902.class_2903.field_13194, x - 4, z);
        int yE = world.method_8624(class_2902.class_2903.field_13194, x + 4, z);

        int maxDelta = Math.max(
                Math.max(Math.abs(yCenter - yN), Math.abs(yCenter - yS)),
                Math.max(Math.abs(yCenter - yW), Math.abs(yCenter - yE))
        );

        return maxDelta <= 4;
    }

    private boolean isSurfaceBlockOk(class_3218 world, class_2338 posBelowSurface) {
        var state = world.method_8320(posBelowSurface);

        if (!state.method_26227().method_15769()) return false;

        var block = state.method_26204();
        String name = block.method_9518().getString().toLowerCase(Locale.ROOT);

        if (name.contains("leaves") || name.contains("ice")) return false;

        return true;
    }

    private boolean isFarEnoughFromOthers(class_2338 candidate, List<class_2338> existingTargets, int minDistanceSq) {
        if (minDistanceSq <= 0) return true;

        for (class_2338 other : existingTargets) {
            if (candidate.method_10262(other) < minDistanceSq) {
                return false;
            }
        }

        return true;
    }
}
