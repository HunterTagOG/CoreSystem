package dev.huntertagog.coresystem.server.world;

import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import it.unimi.dsi.fastutil.objects.*;
import net.minecraft.class_1928;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

public final class GameRuleStore {

    private final Reference2BooleanMap<class_1928.class_4313<class_1928.class_4310>> booleanRules =
            new Reference2BooleanOpenHashMap<>();

    private final Reference2IntMap<class_1928.class_4313<class_1928.class_4312>> intRules =
            new Reference2IntOpenHashMap<>();

    // ----------------------------------------------------
    // Setter
    // ----------------------------------------------------

    public void set(class_1928.class_4313<class_1928.class_4310> key, boolean value) {
        this.booleanRules.put(key, value);
    }

    public void set(class_1928.class_4313<class_1928.class_4312> key, int value) {
        this.intRules.put(key, value);
    }

    // ----------------------------------------------------
    // Anwenden auf GameRules
    // ----------------------------------------------------

    public void applyTo(class_1928 rules, @Nullable MinecraftServer server) {

        // ----------------------------
        // Boolean GameRules
        // ----------------------------
        Reference2BooleanMaps.fastForEach(this.booleanRules, entry -> {
            try {
                class_1928.class_4310 rule = rules.method_20746(entry.getKey());
                if (rule == null) {
                    CoreError.of(
                                    CoreErrorCode.MESSAGE_ERROR,
                                    CoreErrorSeverity.WARN,
                                    "GameRuleStore: BooleanRule key not found"
                            )
                            .withContextEntry("ruleKey", safeKey(entry.getKey()))
                            .log();
                    return;
                }

                rule.method_20758(entry.getBooleanValue(), server);

            } catch (Throwable t) {
                CoreError.of(
                                CoreErrorCode.MESSAGE_ERROR,
                                CoreErrorSeverity.ERROR,
                                "GameRuleStore: Failed to apply BooleanRule"
                        )
                        .withContextEntry("ruleKey", safeKey(entry.getKey()))
                        .withContextEntry("value", String.valueOf(entry.getBooleanValue()))
                        .withContextEntry("exception", t.toString())
                        .log();
            }
        });

        // ----------------------------
        // Int GameRules
        // ----------------------------
        Reference2IntMaps.fastForEach(this.intRules, entry -> {
            try {
                class_1928.class_4312 rule = rules.method_20746(entry.getKey());
                if (rule == null) {
                    CoreError.of(
                                    CoreErrorCode.MESSAGE_ERROR,
                                    CoreErrorSeverity.WARN,
                                    "GameRuleStore: IntRule key not found"
                            )
                            .withContextEntry("ruleKey", safeKey(entry.getKey()))
                            .log();
                    return;
                }

                rule.method_35236(entry.getIntValue(), server);

            } catch (Throwable t) {
                CoreError.of(
                                CoreErrorCode.MESSAGE_ERROR,
                                CoreErrorSeverity.ERROR,
                                "GameRuleStore: Failed to apply IntRule"
                        )
                        .withContextEntry("ruleKey", safeKey(entry.getKey()))
                        .withContextEntry("value", String.valueOf(entry.getIntValue()))
                        .withContextEntry("exception", t.toString())
                        .log();
            }
        });
    }

    // ----------------------------------------------------
    // Helper (saubere Ausgabe des Rule-Key)
    // ----------------------------------------------------

    private static String safeKey(class_1928.class_4313<?> key) {
        return key == null ? "<null>" : key.method_20771();
    }
}
