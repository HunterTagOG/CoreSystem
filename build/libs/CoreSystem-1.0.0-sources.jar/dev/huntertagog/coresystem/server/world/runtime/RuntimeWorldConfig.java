package dev.huntertagog.coresystem.server.world.runtime;

import dev.huntertagog.coresystem.server.world.GameRuleStore;
import net.minecraft.class_1267;
import net.minecraft.class_1928;
import net.minecraft.class_2378;
import net.minecraft.class_2794;
import net.minecraft.class_2874;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_6880;
import net.minecraft.class_7134;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

public final class RuntimeWorldConfig {
    private long seed = 0;
    private class_5321<class_2874> dimensionType = class_7134.field_37666;
    private class_2794 generator = null;
    private long timeOfDay = 6000;
    private class_1267 difficulty = class_1267.field_5802;
    private final GameRuleStore gameRules = new GameRuleStore();

    private int sunnyTime = Integer.MAX_VALUE;
    private boolean raining;
    private int rainTime;
    private boolean thundering;
    private int thunderTime;

    public RuntimeWorldConfig setSeed(long seed) {
        this.seed = seed;
        return this;
    }

    public RuntimeWorldConfig setDimensionType(class_5321<class_2874> dimensionType) {
        this.dimensionType = dimensionType;
        return this;
    }

    public RuntimeWorldConfig setGenerator(class_2794 generator) {
        this.generator = generator;
        return this;
    }

    public RuntimeWorldConfig setTimeOfDay(long timeOfDay) {
        this.timeOfDay = timeOfDay;
        return this;
    }

    public RuntimeWorldConfig setDifficulty(class_1267 difficulty) {
        this.difficulty = difficulty;
        return this;
    }

    public RuntimeWorldConfig setGameRule(class_1928.class_4313<class_1928.class_4310> key, boolean value) {
        this.gameRules.set(key, value);
        return this;
    }

    public RuntimeWorldConfig setGameRule(class_1928.class_4313<class_1928.class_4312> key, int value) {
        this.gameRules.set(key, value);
        return this;
    }

    public RuntimeWorldConfig setSunny(int sunnyTime) {
        this.sunnyTime = sunnyTime;
        this.raining = false;
        this.thundering = false;
        return this;
    }

    public RuntimeWorldConfig setRaining(int rainTime) {
        this.raining = rainTime > 0;
        this.rainTime = rainTime;
        return this;
    }

    public RuntimeWorldConfig setRaining(boolean raining) {
        this.raining = raining;
        return this;
    }

    public RuntimeWorldConfig setThundering(int thunderTime) {
        this.thundering = thunderTime > 0;
        this.thunderTime = thunderTime;
        return this;
    }

    public RuntimeWorldConfig setThundering(boolean thundering) {
        this.thundering = thundering;
        return this;
    }

    public long getSeed() {
        return this.seed;
    }

    public class_5321<class_2874> getDimensionType() {
        return this.dimensionType;
    }

    public class_6880<class_2874> getDimensionType(MinecraftServer server) {
        class_2378<class_2874> dimRegistry = server.method_30611()
                .method_30530(class_7924.field_41241);

        return dimRegistry.method_40290(this.dimensionType);
    }

    public class_5363 buildDimensionOptions(MinecraftServer server, class_2794 generator) {
        class_6880<class_2874> dimTypeEntry = getDimensionType(server);
        return new class_5363(dimTypeEntry, generator);
    }

    @Nullable
    public class_2794 getGenerator() {
        return this.generator;
    }

    public long getTimeOfDay() {
        return this.timeOfDay;
    }

    public class_1267 getDifficulty() {
        return this.difficulty;
    }

    public GameRuleStore getGameRules() {
        return this.gameRules;
    }

    public int getSunnyTime() {
        return this.sunnyTime;
    }

    public int getRainTime() {
        return this.rainTime;
    }

    public int getThunderTime() {
        return this.thunderTime;
    }

    public boolean isRaining() {
        return this.raining;
    }

    public boolean isThundering() {
        return this.thundering;
    }
}

