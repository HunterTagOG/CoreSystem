package dev.huntertagog.coresystem.server.world.runtime;

import dev.huntertagog.coresystem.server.islands.PrivateIslandWorldService;
import dev.huntertagog.coresystem.server.world.PrivateIslandWorldAccess;
import net.minecraft.class_3218;

public record RuntimeWorldHandle(PrivateIslandWorldService piws, class_3218 world) {

    public void setTickWhenEmpty(boolean tickWhenEmpty) {
        ((PrivateIslandWorldAccess) this.world).piws$setTickWhenEmpty(tickWhenEmpty);
    }

    public void delete() {
        this.piws.enqueueWorldDeletion(this.world);
    }

    public class_3218 asWorld() {
        return this.world;
    }
}
