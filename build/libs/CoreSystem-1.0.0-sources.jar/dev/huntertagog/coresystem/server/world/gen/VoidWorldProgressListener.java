package dev.huntertagog.coresystem.server.world.gen;

import net.minecraft.class_1923;
import net.minecraft.class_2806;
import net.minecraft.class_3949;
import org.jetbrains.annotations.Nullable;

public final class VoidWorldProgressListener implements class_3949 {
    public static final VoidWorldProgressListener INSTANCE = new VoidWorldProgressListener();

    private VoidWorldProgressListener() {
    }

    @Override
    public void method_17675() {
    }

    @Override
    public void method_17669(class_1923 spawnPos) {

    }

    @Override
    public void method_17670(class_1923 pos, @Nullable class_2806 status) {
    }

    @Override
    public void method_17671() {
    }
}
