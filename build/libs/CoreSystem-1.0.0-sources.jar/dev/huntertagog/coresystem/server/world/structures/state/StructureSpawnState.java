package dev.huntertagog.coresystem.server.world.structures.state;

import java.util.*;
import net.minecraft.class_18;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_26;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_7225;

/**
 * Persistenter Zustand:
 * - je Struktur-ID eine Liste von Ziel-Positionen
 * - BitSet zum Markieren, welche Ziele bereits platziert wurden
 * <p>
 * Liegt pro Welt unter: world/data/coresystem_structure_spawns.dat
 */
public class StructureSpawnState extends class_18 {

    // 1.21.x: Type wird direkt über den Konstruktor gebaut, kein create(...)
    public static final class_8645<StructureSpawnState> TYPE = new class_18.class_8645<>(
            StructureSpawnState::new,
            StructureSpawnState::fromNbt,
            null
    );

    public static class StructureData {
        public final List<class_2338> targets = new ArrayList<>();
        public final BitSet placed = new BitSet();

        public boolean isFullyPlaced() {
            return placed.cardinality() >= targets.size();
        }
    }

    private final Map<class_2960, StructureData> structures = new HashMap<>();

    public StructureSpawnState() {
    }

    public static StructureSpawnState get(class_3218 world) {
        class_26 manager = world.method_17983();
        return manager.method_17924(TYPE, "coresystem_structure_spawns");
    }

    // ---------- Serialisierung ----------

    @Override
    public class_2487 method_75(class_2487 nbt, class_7225.class_7874 registryLookup) {
        class_2499 list = new class_2499();

        for (Map.Entry<class_2960, StructureData> entry : structures.entrySet()) {
            class_2960 id = entry.getKey();
            StructureData data = entry.getValue();

            class_2487 structNbt = new class_2487();
            structNbt.method_10582("Id", id.toString());

            class_2499 targetsList = new class_2499();
            for (class_2338 pos : data.targets) {
                class_2487 p = new class_2487();
                p.method_10569("x", pos.method_10263());
                p.method_10569("y", pos.method_10264());
                p.method_10569("z", pos.method_10260());
                targetsList.add(p);
            }
            structNbt.method_10566("Targets", targetsList);

            long[] bits = data.placed.toLongArray();
            structNbt.method_10564("PlacedBits", bits);

            list.add(structNbt);
        }

        nbt.method_10566("Structures", list);
        return nbt;
    }

    // Loader, von TYPE benutzt
    public static StructureSpawnState fromNbt(class_2487 nbt, class_7225.class_7874 registryLookup) {
        StructureSpawnState state = new StructureSpawnState();
        class_2499 list = nbt.method_10554("Structures", class_2520.field_33260);

        for (class_2520 element : list) {
            class_2487 structNbt = (class_2487) element;
            class_2960 id = class_2960.method_60654(structNbt.method_10558("Id"));

            StructureData data = new StructureData();

            class_2499 targetsList = structNbt.method_10554("Targets", class_2520.field_33260);
            for (class_2520 tElem : targetsList) {
                class_2487 p = (class_2487) tElem;
                class_2338 pos = new class_2338(p.method_10550("x"), p.method_10550("y"), p.method_10550("z"));
                data.targets.add(pos);
            }

            long[] bits = structNbt.method_10565("PlacedBits");
            if (bits.length > 0) {
                data.placed.clear();
                data.placed.or(BitSet.valueOf(bits));
            }

            state.structures.put(id, data);
        }

        return state;
    }

    // ---------- API ----------

    public Map<class_2960, StructureData> getStructures() {
        return structures;
    }

    public StructureData getOrCreate(class_2960 id) {
        return structures.computeIfAbsent(id, k -> new StructureData());
    }
}
