package dev.huntertagog.coresystem.server.world;

public interface PrivateIslandWorldAccess {
    void piws$setTickWhenEmpty(boolean tickWhenEmpty);
}
