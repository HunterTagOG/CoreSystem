package dev.huntertagog.coresystem.server.world.gen;

import com.mojang.serialization.MapCodec;
import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.server.world.island.IslandHeightmap;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1923;
import net.minecraft.class_1992;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2794;
import net.minecraft.class_2893;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3233;
import net.minecraft.class_4543;
import net.minecraft.class_4966;
import net.minecraft.class_5138;
import net.minecraft.class_5539;
import net.minecraft.class_6748;
import net.minecraft.class_7138;

public class OceanIslandChunkGenerator extends class_2794 {

    private static final Logger LOG = LoggerFactory.get("OceanIslandChunkGen");

    private final int minY;
    private final int worldHeight;
    private final int seaLevel;

    private final IslandHeightmap heightmap;

    // Vanilla-Template-Generator (für Caves/Carver/Fine-Tuning)
    private final class_2794 templateGenerator;

    private static final class_2680 STONE = class_2246.field_10340.method_9564();
    private static final class_2680 DIRT = class_2246.field_10566.method_9564();
    private static final class_2680 GRASS = class_2246.field_10219.method_9564();
    private static final class_2680 WATER = class_2246.field_10382.method_9564();

    // --- Dummy-CODEC nur für Persistenz ---
    public static final MapCodec<OceanIslandChunkGenerator> CODEC =
            MapCodec.unit(() -> {
                throw new UnsupportedOperationException(
                        "OceanIslandChunkGenerator should not be created via Codec (runtime-only)"
                );
            });

    @Override
    protected MapCodec<? extends class_2794> method_28506() {
        return CODEC;
    }

    public OceanIslandChunkGenerator(class_2794 templateWorld,
                                     class_3218 world,
                                     IslandHeightmap heightmap) {
        super(
                new class_1992(world.method_22385().method_22393(class_2338.field_10980)),
                templateWorld::method_44216
        );

        this.templateGenerator = templateWorld;
        this.minY = world.method_31607();
        this.worldHeight = world.method_31605();
        this.seaLevel = world.method_8615();
        this.heightmap = heightmap;
    }

    // -------------------------------------------------
    // Carving: Vanilla-Caves + Custom Underwater-Tunnel
    // -------------------------------------------------
    @Override
    public void method_12108(class_3233 region,
                      long seed,
                      class_7138 noiseConfig,
                      class_4543 biomeAccess,
                      class_5138 structureAccessor,
                      class_2791 chunk,
                      class_2893.class_2894 carverStep) {

        class_1923 pos = chunk.method_12004();

        try {
            // 1) Vanilla-Carver laufen lassen (Caves, Aquifers etc.)
            templateGenerator.method_12108(region, seed, noiseConfig, biomeAccess, structureAccessor, chunk, carverStep);

            // 2) Unsere Underwater-Tunnel nur im AIR-Step
            if (carverStep == class_2893.class_2894.field_13169) {
                carveUnderwaterTunnels(chunk);
            }
        } catch (Exception e) {
            CoreError error = CoreError.of(
                            CoreErrorCode.MESSAGE_ERROR,
                            CoreErrorSeverity.ERROR,
                            "Exception during carve in OceanIslandChunkGenerator"
                    )
                    .withCause(e)
                    .withContextEntry("chunkX", pos.field_9181)
                    .withContextEntry("chunkZ", pos.field_9180)
                    .withContextEntry("carverStep", carverStep.name());

            LOG.error(error.toLogString(), e);
        }
    }

    @Override
    public void method_12110(class_3233 region,
                             class_5138 structures,
                             class_7138 noiseConfig,
                             class_2791 chunk) {
        // Terrain kommt vollständig aus populateNoise
    }

    @Override
    public void method_12107(class_3233 region) {
        // Entities werden über Biome / späteren Pass gesteuert
    }

    @Override
    public int method_12104() {
        return this.worldHeight;
    }

    // ------------------------------------
    // Kern: Terrain + Cliff-Caves / Spikes
    // ------------------------------------
    @Override
    public CompletableFuture<class_2791> method_12088(class_6748 blender,
                                                  class_7138 noiseConfig,
                                                  class_5138 structureAccessor,
                                                  class_2791 chunk) {

        class_1923 pos = chunk.method_12004();

        try {
            int startX = pos.method_8326();
            int startZ = pos.method_8328();
            int endX = pos.method_8327();
            int endZ = pos.method_8329();

            for (int x = startX; x <= endX; x++) {
                for (int z = startZ; z <= endZ; z++) {

                    int localX = x - startX;
                    int localZ = z - startZ;

                    // genau EIN mal abfragen, danach nur noch weiterreichen
                    int terrainY = heightmap.sampleHeight(x, z);
                    int floorY = heightmap.sampleSeafloorHeight(x, z);

                    // --- reiner Ozean (keine Insel) ---
                    if (terrainY < 0) {
                        // Seafloor → STONE
                        for (int y = minY; y <= floorY; y++) {
                            setBlock(chunk, localX, y, localZ, STONE);
                        }
                        // darüber Wasser bis Meeresspiegel
                        for (int y = floorY + 1; y <= seaLevel; y++) {
                            setBlock(chunk, localX, y, localZ, WATER);
                        }
                        continue;
                    }

                    // -----------------------------
                    // 1. Solider Unterbau: Stone
                    // -----------------------------
                    int groundHeight = Math.max(minY + 1, terrainY - 5);
                    for (int y = minY; y < groundHeight; y++) {
                        setBlock(chunk, localX, y, localZ, STONE);
                    }

                    // -----------------------------
                    // 2. Erdschicht (Dirt)
                    // -----------------------------
                    for (int y = groundHeight; y < terrainY; y++) {
                        setBlock(chunk, localX, y, localZ, DIRT);
                    }

                    // -----------------------------
                    // 3. Oberfläche (Grass)
                    // -----------------------------
                    setBlock(chunk, localX, terrainY, localZ, GRASS);

                    // -----------------------------
                    // 4. Wasser auffüllen, falls Insel im Wasser
                    // -----------------------------
                    for (int y = terrainY + 1; y <= seaLevel; y++) {
                        setBlock(chunk, localX, y, localZ, WATER);
                    }

                    // --------------------------------
                    // 5. Cliff-Caves & Spikes an Wand
                    // --------------------------------
                    if (terrainY > seaLevel && floorY < seaLevel - 3) {

                        // 5.1 Risse/Höhlen in der Wand
                        for (int y = floorY + 2; y <= terrainY - 3; y++) {
                            if (heightmap.isCliffCavity(x, y, z)) {
                                setBlock(chunk, localX, y, localZ, WATER);
                            }
                        }

                        // 5.2 Spikes / Felsnasen aus Boden/Wand
                        for (int y = floorY + 1; y <= seaLevel - 2; y++) {
                            if (heightmap.isCliffSpike(x, y, z)) {
                                class_2680 current = chunk.method_8320(new class_2338(localX, y, localZ));
                                if (current.method_27852(class_2246.field_10382)) {
                                    setBlock(chunk, localX, y, localZ, STONE);
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            CoreError error = CoreError.of(
                            CoreErrorCode.MESSAGE_ERROR,
                            CoreErrorSeverity.ERROR,
                            "Exception during populateNoise in OceanIslandChunkGenerator"
                    )
                    .withCause(e)
                    .withContextEntry("chunkX", pos.field_9181)
                    .withContextEntry("chunkZ", pos.field_9180);

            LOG.error(error.toLogString(), e);
        }

        // Im Fehlerfall: Chunk trotzdem zurückgeben (teilweise generiert)
        return CompletableFuture.completedFuture(chunk);
    }

    private void setBlock(class_2791 chunk, int localX, int y, int localZ, class_2680 state) {
        if (state == null) return;
        int relY = y - minY;
        if (relY < 0 || relY >= worldHeight) return;
        chunk.method_12010(new class_2338(localX, y, localZ), state, false);
    }

    @Override
    public int method_16398() {
        return this.seaLevel;
    }

    @Override
    public int method_33730() {
        return this.minY;
    }

    @Override
    public int method_16397(int x,
                         int z,
                         class_2902.class_2903 heightmapType,
                         class_5539 world,
                         class_7138 noiseConfig) {
        int h = heightmap.sampleHeight(x, z);
        return h < 0 ? minY : h;
    }

    @Override
    public class_4966 method_26261(int x,
                                               int z,
                                               class_5539 world,
                                               class_7138 noiseConfig) {
        int h = heightmap.sampleHeight(x, z);
        if (h < 0) {
            return new class_4966(minY, new class_2680[0]);
        }
        class_2680[] states = new class_2680[h - minY + 1];
        for (int i = 0; i < states.length; i++) {
            states[i] = (i == states.length - 1) ? GRASS : STONE;
        }
        return new class_4966(minY, states);
    }

    @Override
    public void method_40450(List<String> text,
                                class_7138 noiseConfig,
                                class_2338 pos) {
        text.add("Generator: OceanIslandChunkGenerator");
    }

    // -------------------------------------------------
    // Custom Underwater-Tunnel (Cave-Feld aus Heightmap)
    // -------------------------------------------------
    private void carveUnderwaterTunnels(class_2791 chunk) {
        class_1923 pos = chunk.method_12004();
        int startX = pos.method_8326();
        int startZ = pos.method_8328();

        for (int localX = 0; localX < 16; localX++) {
            int x = startX + localX;

            for (int localZ = 0; localZ < 16; localZ++) {
                int z = startZ + localZ;

                int seafloorY = heightmap.sampleSeafloorHeight(x, z);
                int minY = Math.max(this.minY + 1, seafloorY + 2);
                int maxY = this.seaLevel - 3;

                if (maxY <= minY) {
                    continue;
                }

                for (int y = minY; y <= maxY; y++) {
                    if (!heightmap.isUnderwaterCaveAt(x, y, z)) {
                        continue;
                    }

                    class_2338 p = new class_2338(localX, y, localZ);
                    class_2680 current = chunk.method_8320(p);

                    if (!current.method_26215() && current.method_26204() != class_2246.field_10382) {
                        chunk.method_12010(p, WATER, false);
                    }
                }
            }
        }
    }
}
