package dev.huntertagog.coresystem.server.protection;

import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;

public final class WorldProtectionBootstrap {

    private static final Logger LOG = LoggerFactory.get("WorldProtectionBootstrap");

    private WorldProtectionBootstrap() {
    }

    public static void register(MinecraftServer server) {
        WorldProtectionService protection = ServiceProvider.getService(WorldProtectionService.class);
        if (protection == null) {
            LOG.warn("WorldProtectionService not available – world protection disabled.");
            return;
        }

        ServerWorldEvents.LOAD.register((MinecraftServer srv, class_3218 world) -> {
            protection.applyOnWorldLoad(world);
        });

        LOG.info("WorldProtectionBootstrap wired to ServerWorldEvents.LOAD");
    }
}
