package dev.huntertagog.coresystem.server.command.impl;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.common.error.CoreErrorUtil;
import dev.huntertagog.coresystem.common.permission.CorePermission;
import dev.huntertagog.coresystem.common.permission.PermissionKeys;
import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import dev.huntertagog.coresystem.common.region.*;
import dev.huntertagog.coresystem.common.region.visual.RegionOutlineService;
import dev.huntertagog.coresystem.common.text.CoreMessage;
import dev.huntertagog.coresystem.common.text.Messages;
import dev.huntertagog.coresystem.server.command.BaseCommand;
import dev.huntertagog.coresystem.server.command.CommandMeta;
import dev.huntertagog.coresystem.server.command.CommandUtil;
import dev.huntertagog.coresystem.server.command.CoreCommand;
import dev.huntertagog.coresystem.server.region.RegionDefinition;
import dev.huntertagog.coresystem.server.region.image.RegionImageServerService;
import java.util.*;
import java.util.stream.Collectors;
import net.minecraft.class_1937;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7157;
import net.minecraft.class_7924;

import static net.minecraft.class_2170.method_9247;

@CommandMeta(
        value = "region",
        permission = PermissionKeys.REGION_ADMIN, // definiere dir einen passenden Key
        enabled = true
)
public final class RegionCommand extends BaseCommand implements CoreCommand {

    public RegionCommand() {
    }

    /**
     * In-Memory Selection pro Spieler
     */
    private static final Map<UUID, Selection> SELECTIONS = new HashMap<>();

    private record Selection(class_2960 worldId, class_2338 pos1, class_2338 pos2) {
    }

    @Override
    public void register(CommandDispatcher<class_2168> dispatcher,
                         class_7157 registryAccess,
                         class_2170.class_5364 env) {

        dispatcher.register(
                method_9247("region")
                        // /region pos1
                        .then(
                                CommandUtil.literalWithPermission(this, "pos1", CorePermission.REGION_ADMIN)
                                        .executes(this::executePos1)
                        )
                        // /region pos2
                        .then(
                                CommandUtil.literalWithPermission(this, "pos2", CorePermission.REGION_ADMIN)
                                        .executes(this::executePos2)
                        )
                        // /region create <id> <name...>
                        .then(
                                CommandUtil.literalWithPermission(this, "create", CorePermission.REGION_ADMIN)
                                        .then(class_2170.method_9244("id", StringArgumentType.word())
                                                .then(class_2170.method_9244("name", StringArgumentType.greedyString())
                                                        .executes(this::executeCreate)
                                                ))
                        )
                        // /region delete <id>
                        .then(
                                CommandUtil.literalWithPermission(this, "delete", CorePermission.REGION_ADMIN)
                                        .then(class_2170.method_9244("id", StringArgumentType.word())
                                                .executes(this::executeDelete)
                                        )
                        )
                        // /region list
                        .then(
                                CommandUtil.literalWithPermission(this, "list", CorePermission.REGION_ADMIN)
                                        .executes(this::executeList)
                        )
                        // /region info <id>
                        .then(
                                CommandUtil.literalWithPermission(this, "info", CorePermission.REGION_ADMIN)
                                        .then(class_2170.method_9244("id", StringArgumentType.word())
                                                .executes(this::executeInfo)
                                        )
                        )
                        // /region flag add/remove <id> <flag>
                        .then(
                                CommandUtil.literalWithPermission(this, "flag", CorePermission.REGION_ADMIN)
                                        .then(method_9247("add")
                                                .then(class_2170.method_9244("id", StringArgumentType.word())
                                                        .then(class_2170.method_9244("flag", StringArgumentType.word())
                                                                .executes(ctx -> executeFlagModify(ctx, true))
                                                        )
                                                )
                                        )
                                        .then(method_9247("remove")
                                                .then(class_2170.method_9244("id", StringArgumentType.word())
                                                        .then(class_2170.method_9244("flag", StringArgumentType.word())
                                                                .executes(ctx -> executeFlagModify(ctx, false))
                                                        )
                                                )
                                        )
                        )
                        // /region cmd add-enter <id> <command...>
                        // /region cmd add-leave <id> <command...>
                        // /region cmd clear-enter <id>
                        // /region cmd clear-leave <id>
                        .then(
                                CommandUtil.literalWithPermission(this, "cmd", CorePermission.REGION_ADMIN)
                                        .then(method_9247("add-enter")
                                                .then(class_2170.method_9244("id", StringArgumentType.word())
                                                        .then(class_2170.method_9244("command", StringArgumentType.greedyString())
                                                                .executes(ctx -> executeCmdAdd(ctx, true))
                                                        )
                                                )
                                        )
                                        .then(method_9247("add-leave")
                                                .then(class_2170.method_9244("id", StringArgumentType.word())
                                                        .then(class_2170.method_9244("command", StringArgumentType.greedyString())
                                                                .executes(ctx -> executeCmdAdd(ctx, false))
                                                        )
                                                )
                                        )
                                        .then(method_9247("clear-enter")
                                                .then(class_2170.method_9244("id", StringArgumentType.word())
                                                        .executes(ctx -> executeCmdClear(ctx, true))
                                                )
                                        )
                                        .then(method_9247("clear-leave")
                                                .then(class_2170.method_9244("id", StringArgumentType.word())
                                                        .executes(ctx -> executeCmdClear(ctx, false))
                                                )
                                        )
                        )
                        .then(
                                CommandUtil.literalWithPermission(this, "image", CorePermission.REGION_ADMIN)

                                        // /region image set <id> wall <facing> <imageKey> [baseY]
                                        .then(method_9247("set")
                                                .then(class_2170.method_9244("id", StringArgumentType.word())
                                                        .then(method_9247("wall")
                                                                .then(class_2170.method_9244("facing", StringArgumentType.word())
                                                                        .suggests((ctx, builder) -> {
                                                                            // no redis here:
                                                                            for (String option : List.of("NORTH", "SOUTH", "EAST", "WEST")) {
                                                                                builder.suggest(option);
                                                                            }
                                                                            return builder.buildFuture();
                                                                        })
                                                                        .then(class_2170.method_9244("imageKey", StringArgumentType.word())
                                                                                .executes(this::executeImageSetWall)
                                                                        )
                                                                )
                                                        )

                                                        // /region image set <id> floor <baseY> <imageKey>
                                                        .then(method_9247("floor")
                                                                .then(class_2170.method_9244("baseY", IntegerArgumentType.integer())
                                                                        .then(class_2170.method_9244("imageKey", StringArgumentType.word())
                                                                                .executes(this::executeImageSetFloor)
                                                                        )
                                                                )
                                                        )
                                                )
                                        )

                                        // /region image clear <id>
                                        .then(method_9247("clear")
                                                .then(class_2170.method_9244("id", StringArgumentType.word())
                                                        .executes(this::executeImageClear)
                                                )
                                        )
                        )
        );
    }

    // ------------------------------------------------------------------------
    // /region pos1
    // ------------------------------------------------------------------------

    private int executePos1(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        class_3222 player = src.method_44023();
        if (player == null) {
            Messages.send(src, CoreMessage.ONLY_PLAYERS);
            return 0;
        }

        class_2338 pos = player.method_24515();
        class_2960 worldId = worldId(player.method_37908());

        Selection old = SELECTIONS.get(player.method_5667());
        class_2338 pos2 = old != null ? old.pos2() : pos;

        Selection sel = new Selection(worldId, pos, pos2);
        SELECTIONS.put(player.method_5667(), sel);

        // ✔ Outline anzeigen (kleiner Marker)
        RegionOutlineService outline = ServiceProvider.getService(RegionOutlineService.class);
        if (outline != null) {
            outline.showSelection(
                    player,
                    player.method_37908().method_27983().method_29177(),
                    pos,
                    pos,           // nur ein Block
                    20 * 5         // 5 Sekunden
            );
        }

        src.method_45068(
                class_2561.method_43470("§a[Region] Pos1 gesetzt bei §e" + formatPos(pos) + " §7(" + worldId + ")")
        );
        return 1;
    }

    // ------------------------------------------------------------------------
    // /region pos2
    // ------------------------------------------------------------------------

    private int executePos2(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        class_3222 player = src.method_44023();
        if (player == null) {
            Messages.send(src, CoreMessage.ONLY_PLAYERS);
            return 0;
        }

        class_2338 pos = player.method_24515();
        class_2960 worldId = worldId(player.method_37908());

        Selection old = SELECTIONS.get(player.method_5667());
        class_2338 pos1 = old != null ? old.pos1() : pos;

        Selection sel = new Selection(worldId, pos1, pos);
        SELECTIONS.put(player.method_5667(), sel);

        // ✔ Outline für die komplette Box
        RegionOutlineService outline = ServiceProvider.getService(RegionOutlineService.class);
        if (outline != null) {
            outline.showSelection(
                    player,
                    player.method_37908().method_27983().method_29177(),
                    pos1,
                    pos,
                    20 * 5 // 5 Sekunden
            );
        }

        src.method_45068(
                class_2561.method_43470("§a[Region] Pos2 gesetzt bei §e" + formatPos(pos) + " §7(" + worldId + ")")
        );
        return 1;
    }

    // ------------------------------------------------------------------------
    // /region create <id> <name...>
    // ------------------------------------------------------------------------

    private int executeCreate(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        class_3222 player = src.method_44023();
        if (player == null) {
            Messages.send(src, CoreMessage.ONLY_PLAYERS);
            return 0;
        }

        RegionService regions = ServiceProvider.getService(RegionService.class);
        if (regions == null) {
            CoreErrorUtil.notify(src,
                    CoreError.of(CoreErrorCode.SERVICE_MISSING, CoreErrorSeverity.CRITICAL,
                                    "RegionService not available for /region create")
                            .withContextEntry("command", "region create")
            );
            return 0;
        }

        String id = StringArgumentType.getString(ctx, "id");
        String name = StringArgumentType.getString(ctx, "name");

        Selection sel = SELECTIONS.get(player.method_5667());
        if (sel == null || sel.pos1() == null || sel.pos2() == null) {
            src.method_45068(
                    class_2561.method_43470("§c[Region] Du musst zuerst §e/region pos1 §cund §e/region pos2 §csetzen.")
            );
            return 0;
        }

        // beide Punkte müssen in derselben Welt liegen
        class_2960 worldId = sel.worldId();

        class_2338 a = sel.pos1();
        class_2338 b = sel.pos2();

        int minX = Math.min(a.method_10263(), b.method_10263());
        int minY = Math.min(a.method_10264(), b.method_10264());
        int minZ = Math.min(a.method_10260(), b.method_10260());
        int maxX = Math.max(a.method_10263(), b.method_10263());
        int maxY = Math.max(a.method_10264(), b.method_10264());
        int maxZ = Math.max(a.method_10260(), b.method_10260());

        RegionDefinition def = new RegionDefinition(
                id,
                name,
                player.method_5667(),
                worldId,
                minX, minY, minZ,
                maxX, maxY, maxZ,
                EnumSet.noneOf(RegionFlag.class),
                List.of(),
                List.of()
        );

        regions.registerRegion(def);

        // ✔ Outline der fertigen Region anzeigen
        RegionOutlineService outline = ServiceProvider.getService(RegionOutlineService.class);
        if (outline != null) {
            outline.showRegion(player, def, 20 * 8); // 8 Sekunden
        }

        src.method_45068(
                class_2561.method_43470("§a[Region] Region §e" + id + " §aerstellt. Bereich: §7" +
                        minX + "," + minY + "," + minZ + " §8-> §7" + maxX + "," + maxY + "," + maxZ)
        );

        return 1;
    }

    // ------------------------------------------------------------------------
    // /region delete <id>
    // ------------------------------------------------------------------------

    private int executeDelete(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();

        RegionService regions = ServiceProvider.getService(RegionService.class);
        if (regions == null) {
            CoreErrorUtil.notify(src,
                    CoreError.of(CoreErrorCode.SERVICE_MISSING, CoreErrorSeverity.CRITICAL,
                                    "RegionService not available for /region delete")
                            .withContextEntry("command", "region delete")
            );
            return 0;
        }

        String id = StringArgumentType.getString(ctx, "id");

        Optional<RegionDefinition> existing = regions.findById(id);
        if (existing.isEmpty()) {
            src.method_45068(
                    class_2561.method_43470("§c[Region] Unbekannte Region-ID: §e" + id)
            );
            return 0;
        }

        regions.removeRegion(id);

        src.method_45068(
                class_2561.method_43470("§a[Region] Region §e" + id + " §awurde gelöscht.")
        );
        return 1;
    }

    // ------------------------------------------------------------------------
    // /region list
    // ------------------------------------------------------------------------

    private int executeList(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();

        RegionService regions = ServiceProvider.getService(RegionService.class);
        if (regions == null) {
            CoreErrorUtil.notify(src,
                    CoreError.of(CoreErrorCode.SERVICE_MISSING, CoreErrorSeverity.CRITICAL,
                                    "RegionService not available for /region list")
                            .withContextEntry("command", "region list")
            );
            return 0;
        }

        List<RegionDefinition> all;
        try {
            all = regions.getAllRegions();
        } catch (UnsupportedOperationException ex) {
            // falls du getAllRegions noch nicht hast
            src.method_45068(
                    class_2561.method_43470("§c[Region] getAllRegions() ist im aktuellen RegionService nicht implementiert.")
            );
            return 0;
        }

        if (all.isEmpty()) {
            src.method_45068(
                    class_2561.method_43470("§7[Region] Es sind aktuell keine Regionen definiert.")
            );
            return 1;
        }

        src.method_45068(
                class_2561.method_43470("§a[Region] Registrierte Regionen (§e" + all.size() + "§a):")
        );

        for (RegionDefinition r : all) {
            String flags = r.flags().isEmpty()
                    ? "-"
                    : r.flags().stream().map(Enum::name).collect(Collectors.joining(","));

            src.method_45068(
                    class_2561.method_43470(" §7- §e" + r.id() + " §8| §f" + r.name() +
                            " §8| §7" + r.worldId() +
                            " §8| §7Flags: §b" + flags)
            );
        }

        return 1;
    }

    // ------------------------------------------------------------------------
    // /region info <id>
    // ------------------------------------------------------------------------

    private int executeInfo(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();

        RegionService regions = ServiceProvider.getService(RegionService.class);
        if (regions == null) {
            CoreErrorUtil.notify(src,
                    CoreError.of(CoreErrorCode.SERVICE_MISSING, CoreErrorSeverity.CRITICAL,
                                    "RegionService not available for /region info")
                            .withContextEntry("command", "region info")
            );
            return 0;
        }

        String id = StringArgumentType.getString(ctx, "id");
        Optional<RegionDefinition> opt = regions.findById(id);

        if (opt.isEmpty()) {
            src.method_45068(
                    class_2561.method_43470("§c[Region] Unbekannte Region-ID: §e" + id)
            );
            return 0;
        }

        RegionDefinition r = opt.get();

        String flags = r.flags().isEmpty()
                ? "-"
                : r.flags().stream().map(Enum::name).collect(Collectors.joining(", "));

        String enterCmds = r.onEnterCommands().isEmpty()
                ? "-"
                : String.join(" §8|| §7", r.onEnterCommands());

        String leaveCmds = r.onLeaveCommands().isEmpty()
                ? "-"
                : String.join(" §8|| §7", r.onLeaveCommands());

        src.method_45068(
                class_2561.method_43470("§a[Region] Info zu §e" + r.id())
        );
        src.method_45068(
                class_2561.method_43470(" §7Name: §f" + r.name())
        );
        src.method_45068(
                class_2561.method_43470(" §7Welt: §f" + r.worldId())
        );
        src.method_45068(
                class_2561.method_43470(" §7Bounds: §f" +
                        r.minX() + "," + r.minY() + "," + r.minZ() +
                        " §8-> §f" +
                        r.maxX() + "," + r.maxY() + "," + r.maxZ())
        );
        src.method_45068(
                class_2561.method_43470(" §7Flags: §b" + flags)
        );
        src.method_45068(
                class_2561.method_43470(" §7OnEnter-Cmds: §f" + enterCmds)
        );
        src.method_45068(
                class_2561.method_43470(" §7OnLeave-Cmds: §f" + leaveCmds)
        );

        return 1;
    }

    // ------------------------------------------------------------------------
    // /region flag add/remove <id> <flag>
    // ------------------------------------------------------------------------

    private int executeFlagModify(CommandContext<class_2168> ctx, boolean add) {
        class_2168 src = ctx.getSource();

        RegionService regions = ServiceProvider.getService(RegionService.class);
        if (regions == null) {
            CoreErrorUtil.notify(src,
                    CoreError.of(CoreErrorCode.SERVICE_MISSING, CoreErrorSeverity.CRITICAL,
                                    "RegionService not available for /region flag")
                            .withContextEntry("command", "region flag")
            );
            return 0;
        }

        String id = StringArgumentType.getString(ctx, "id");
        String flagRaw = StringArgumentType.getString(ctx, "flag");

        Optional<RegionDefinition> opt = regions.findById(id);
        if (opt.isEmpty()) {
            src.method_45068(
                    class_2561.method_43470("§c[Region] Unbekannte Region-ID: §e" + id)
            );
            return 0;
        }

        RegionFlag flag;
        try {
            flag = RegionFlag.valueOf(flagRaw.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            src.method_45068(
                    class_2561.method_43470("§c[Region] Unbekanntes Flag: §e" + flagRaw)
            );
            return 0;
        }

        RegionDefinition r = opt.get();
        Set<RegionFlag> newFlags = EnumSet.copyOf(r.flags());

        if (add) {
            newFlags.add(flag);
        } else {
            newFlags.remove(flag);
        }

        RegionDefinition updated = new RegionDefinition(
                r.id(),
                r.name(),
                r.ownerId(),
                r.worldId(),
                r.minX(), r.minY(), r.minZ(),
                r.maxX(), r.maxY(), r.maxZ(),
                newFlags,
                r.onEnterCommands(),
                r.onLeaveCommands()
        );

        regions.registerRegion(updated);

        src.method_45068(
                class_2561.method_43470("§a[Region] Flag §e" + flag.name() + " §awurde " +
                        (add ? "§ahinzugefügt" : "§centfernt") +
                        " §7für Region §e" + id)
        );

        return 1;
    }

    // ------------------------------------------------------------------------
    // /region cmd add-enter|add-leave <id> <command...>
    // ------------------------------------------------------------------------

    private int executeCmdAdd(CommandContext<class_2168> ctx, boolean enter) {
        class_2168 src = ctx.getSource();

        try {
            RegionService regions = ServiceProvider.getService(RegionService.class);
            if (regions == null) {
                src.method_45068(class_2561.method_43470("§c[Region] RegionService nicht verfügbar."));
                return 0;
            }

            String id = StringArgumentType.getString(ctx, "id");
            String cmdRaw = StringArgumentType.getString(ctx, "command");
            String cmd = cmdRaw == null ? "" : cmdRaw.trim();

            if (cmd.isEmpty()) {
                src.method_45068(class_2561.method_43470("§c[Region] Command darf nicht leer sein."));
                return 0;
            }

            Optional<RegionDefinition> opt = regions.findById(id);
            if (opt.isEmpty()) {
                src.method_45068(class_2561.method_43470("§c[Region] Unbekannte Region-ID: §e" + id));
                return 0;
            }

            RegionDefinition r = opt.get();
            List<String> enterCmds = new ArrayList<>(r.onEnterCommands());
            List<String> leaveCmds = new ArrayList<>(r.onLeaveCommands());

            if (enter) enterCmds.add(cmd);
            else leaveCmds.add(cmd);

            RegionDefinition updated = new RegionDefinition(
                    r.id(), r.name(), r.ownerId(), r.worldId(),
                    r.minX(), r.minY(), r.minZ(),
                    r.maxX(), r.maxY(), r.maxZ(),
                    r.flags(),
                    enterCmds,
                    leaveCmds
            );

            regions.registerRegion(updated);

            src.method_45068(class_2561.method_43470("§a[Region] Command für " +
                    (enter ? "§eOnEnter" : "§eOnLeave") + " §ahinzugefügt: §7" + cmd));

            return 1;

        } catch (Exception e) {
            // Business-taugliches Logging mit Kontext
            LoggerFactory.get("RegionCommand").error(
                    "Region cmd add failed. enter={} input='{}'",
                    enter, ctx.getInput(), e
            );

            src.method_45068(class_2561.method_43470("§c[Region] Interner Fehler. Details im Server-Log."));
            return 0;
        }
    }

    // ------------------------------------------------------------------------
    // /region cmd clear-enter|clear-leave <id>
    // ------------------------------------------------------------------------

    private int executeCmdClear(CommandContext<class_2168> ctx, boolean enter) {
        class_2168 src = ctx.getSource();

        RegionService regions = ServiceProvider.getService(RegionService.class);
        if (regions == null) {
            CoreErrorUtil.notify(src,
                    CoreError.of(CoreErrorCode.SERVICE_MISSING, CoreErrorSeverity.CRITICAL,
                                    "RegionService not available for /region cmd clear-*")
                            .withContextEntry("command", "region cmd clear")
            );
            return 0;
        }

        String id = StringArgumentType.getString(ctx, "id");

        Optional<RegionDefinition> opt = regions.findById(id);
        if (opt.isEmpty()) {
            src.method_45068(
                    class_2561.method_43470("§c[Region] Unbekannte Region-ID: §e" + id)
            );
            return 0;
        }

        RegionDefinition r = opt.get();

        List<String> enterCmds = enter ? List.of() : r.onEnterCommands();
        List<String> leaveCmds = enter ? r.onLeaveCommands() : List.of();

        RegionDefinition updated = new RegionDefinition(
                r.id(),
                r.name(),
                r.ownerId(),
                r.worldId(),
                r.minX(), r.minY(), r.minZ(),
                r.maxX(), r.maxY(), r.maxZ(),
                r.flags(),
                enterCmds,
                leaveCmds
        );

        regions.registerRegion(updated);

        src.method_45068(
                class_2561.method_43470("§a[Region] " +
                        (enter ? "OnEnter" : "OnLeave") +
                        "-Commands für Region §e" + id + " §awurden geleert.")
        );

        return 1;
    }

    // ------------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------------

    private static class_2960 worldId(class_1937 world) {
        return world.method_27983().method_29177();
    }

    private static String formatPos(class_2338 pos) {
        return pos.method_10263() + ";" + pos.method_10264() + ";" + pos.method_10260();
    }

    private static String normalizeTextureId(String raw) {
        if (raw == null) return "";
        raw = raw.trim();

        var id = class_2960.method_12829(raw);
        if (id != null) return id.method_12832(); // drop namespace

        return raw.replace(".png", "");
    }

    private static class_3218 resolveRegionWorld(class_2168 src, RegionDefinition region) {
        var server = src.method_9211();
        if (server == null) return null;
        var worldKey = class_5321.method_29179(class_7924.field_41223, region.worldId());
        return server.method_3847(worldKey);
    }

    // ------------------------------------------------------------------------
    // /region image set <id> <imageKey> <mode> [yaw]
    // ------------------------------------------------------------------------

    private int executeImageSetWall(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();

        RegionService regions = ServiceProvider.getService(RegionService.class);
        if (regions == null) {
            src.method_45068(class_2561.method_43470("§c[Region] RegionService nicht verfügbar."));
            return 0;
        }

        String id = StringArgumentType.getString(ctx, "id");
        RegionDefinition region = regions.findById(id).orElse(null);
        if (region == null) {
            src.method_45068(class_2561.method_43470("§c[Region] Unbekannte Region: §e" + id));
            return 0;
        }

        RegionImageFacing facing = RegionImageFacing.valueOf(StringArgumentType.getString(ctx, "facing").toUpperCase(Locale.ROOT));
        if (!facing.name().matches("NORTH|SOUTH|EAST|WEST")) {
            src.method_45068(class_2561.method_43470("§c[Region] Facing muss north|south|east|west sein."));
            return 0;
        }

        String texture = normalizeTextureId(StringArgumentType.getString(ctx, "imageKey"));

        RegionImageDef def = new RegionImageDef(
                region.id(),
                region.worldId(),
                new class_238(
                        region.minX(), region.minY(), region.minZ(),
                        region.maxX(), region.maxY(), region.maxZ()
                ),
                RegionImageMode.WALL,
                facing,
                0,              // baseY irrelevant bei WALL
                texture
        );

        class_3218 world = resolveRegionWorld(src, region);
        RegionImageServerService.upsertAndBroadcast(world, def);

        src.method_45068(class_2561.method_43470(
                "§a[Region] Image gesetzt (WALL) §e" + id +
                        " §7facing=§f" + facing +
                        " §7tex=§f" + texture
        ));
        return 1;
    }

    private int executeImageSetFloor(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();

        RegionService regions = ServiceProvider.getService(RegionService.class);
        if (regions == null) {
            src.method_45068(class_2561.method_43470("§c[Region] RegionService nicht verfügbar."));
            return 0;
        }

        String id = StringArgumentType.getString(ctx, "id");
        RegionDefinition region = regions.findById(id).orElse(null);
        if (region == null) {
            src.method_45068(class_2561.method_43470("§c[Region] Unbekannte Region: §e" + id));
            return 0;
        }

        int baseY = IntegerArgumentType.getInteger(ctx, "baseY");
        String textureId = normalizeTextureId(StringArgumentType.getString(ctx, "imageKey"));

        RegionImageDef def = new RegionImageDef(
                region.id(),
                region.worldId(),
                new class_238(
                        region.minX(), region.minY(), region.minZ(),
                        region.maxX(), region.maxY(), region.maxZ()
                ),
                RegionImageMode.FLOOR,
                RegionImageFacing.NORTH,    // irrelevant bei FLOOR
                baseY,
                textureId
        );

        class_3218 world = resolveRegionWorld(src, region);
        RegionImageServerService.upsertAndBroadcast(world, def);

        src.method_45068(class_2561.method_43470(
                "§a[Region] Image gesetzt (FLOOR) §e" + id +
                        " §7baseY=§f" + baseY +
                        " §7tex=§f" + textureId
        ));
        return 1;
    }

    private int executeImageClear(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();

        RegionService regions = ServiceProvider.getService(RegionService.class);
        if (regions == null) {
            src.method_45068(class_2561.method_43470("§c[Region] RegionService nicht verfügbar."));
            return 0;
        }

        String id = StringArgumentType.getString(ctx, "id");
        RegionDefinition region = regions.findById(id).orElse(null);
        if (region == null) {
            src.method_45068(class_2561.method_43470("§c[Region] Unbekannte Region: §e" + id));
            return 0;
        }

        class_3218 world = resolveRegionWorld(src, region);
        RegionImageServerService.removeAndBroadcast(world, id);

        src.method_45068(class_2561.method_43470("§a[Region] Image entfernt für §e" + id));
        return 1;
    }
}
