package dev.huntertagog.coresystem.server.command;

import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;

public abstract class BaseCommand implements CoreCommand {

    private boolean requiresUsed = false;

    protected BaseCommand() {
    }

    @Override
    public void markRequiresUsed() {
        this.requiresUsed = true;
    }

    @Override
    public boolean isRequiresUsed() {
        return this.requiresUsed;
    }

    protected static Logger logger(String className) {
        return LoggerFactory.get(className);
    }
}

