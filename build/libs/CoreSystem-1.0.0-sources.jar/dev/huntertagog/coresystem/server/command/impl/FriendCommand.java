package dev.huntertagog.coresystem.server.command.impl;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import dev.huntertagog.coresystem.common.friends.FriendService;
import dev.huntertagog.coresystem.common.friends.OfflineFriendMessage;
import dev.huntertagog.coresystem.common.permission.PermissionService;
import dev.huntertagog.coresystem.common.player.PlayerLookup;
import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import dev.huntertagog.coresystem.common.text.CoreMessage;
import dev.huntertagog.coresystem.common.text.Messages;
import dev.huntertagog.coresystem.server.command.BaseCommand;
import dev.huntertagog.coresystem.server.command.CommandSuggestions;
import dev.huntertagog.coresystem.server.command.CoreCommand;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_7157;
import net.minecraft.server.MinecraftServer;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public final class FriendCommand extends BaseCommand implements CoreCommand {

    public FriendCommand() {
    }

    @Override
    public void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {

        dispatcher.register(
                method_9247("friend")
                        .executes(this::executeGui)
                        .then(method_9247("add")
                                .then(method_9244("player", StringArgumentType.word())
                                        .suggests(CommandSuggestions.onlinePlayers())
                                        .executes(ctx -> add(ctx.getSource(), StringArgumentType.getString(ctx, "player")))))
                        .then(method_9247("accept")
                                .then(method_9244("player", StringArgumentType.word())
                                        .suggests(CommandSuggestions.onlinePlayers())
                                        .executes(ctx -> accept(ctx.getSource(), StringArgumentType.getString(ctx, "player")))))
                        .then(method_9247("deny")
                                .then(method_9244("player", StringArgumentType.word())
                                        .suggests(CommandSuggestions.onlinePlayers())
                                        .executes(ctx -> deny(ctx.getSource(), StringArgumentType.getString(ctx, "player")))))
                        .then(method_9247("remove")
                                .then(method_9244("player", StringArgumentType.word())
                                        .suggests(CommandSuggestions.onlinePlayers())
                                        .executes(ctx -> remove(ctx.getSource(), StringArgumentType.getString(ctx, "player")))))
                        .then(method_9247("list")
                                .executes(ctx -> list(ctx.getSource())))
                        .then(method_9247("requests")
                                .executes(ctx -> requests(ctx.getSource())))
                        .then(method_9247("msg")
                                .then(method_9244("player", StringArgumentType.word())
                                        .suggests(CommandSuggestions.onlinePlayers())
                                        .then(method_9244("message", StringArgumentType.greedyString())
                                                .executes(ctx -> msg(
                                                        ctx.getSource(),
                                                        StringArgumentType.getString(ctx, "player"),
                                                        StringArgumentType.getString(ctx, "message")
                                                )))))
        );
    }

    // ---------------------------------------------------------------------
    // Core: Permission Gate
    // ---------------------------------------------------------------------

    private static boolean canUse(class_2168 src) {
        PermissionService perms = ServiceProvider.getService(PermissionService.class);
        // Falls du keine Permission willst, gib hier einfach true zurück.
        return perms == null || perms.has(src, "coresystem.friend.use");
    }

    private static FriendService friendsOrFail(class_2168 src) {
        FriendService friends = ServiceProvider.getService(FriendService.class);
        if (friends == null) {
            Messages.send(src, CoreMessage.SERVICE_UNAVAILABLE);
            return null;
        }
        return friends;
    }

    // ---------------------------------------------------------------------
    // /friend add <player>
    // ---------------------------------------------------------------------

    private int add(class_2168 src, String name) {
        if (!canUse(src)) {
            Messages.send(src, CoreMessage.NO_PERMISSION);
            return 0;
        }

        class_3222 self = src.method_44023();
        if (self == null) {
            Messages.send(src, CoreMessage.ONLY_PLAYERS);
            return 0;
        }

        FriendService friends = friendsOrFail(src);
        if (friends == null) return 0;

        MinecraftServer server = src.method_9211();

        Optional<UUID> otherOpt = PlayerLookup.resolveUuid(server, name);
        if (otherOpt.isEmpty()) {
            Messages.send(src, CoreMessage.PLAYER_UNKNOWN, name);
            return 0;
        }

        UUID other = otherOpt.get();
        UUID me = self.method_5667();

        if (me.equals(other)) {
            Messages.send(src, CoreMessage.FRIEND_SELF_DENY);
            return 0;
        }

        if (friends.areFriends(me, other)) {
            Messages.send(src, CoreMessage.FRIEND_ALREADY, name);
            return 0;
        }

        boolean ok = friends.sendRequest(me, other);
        if (!ok) {
            Messages.send(src, CoreMessage.FRIEND_REQUEST_FAILED, name);
            return 0;
        }

        Messages.send(self, CoreMessage.FRIEND_REQUEST_SENT, name);

        // Wenn Ziel online: Sofort-Hinweis
        class_3222 online = server.method_3760().method_14602(other);
        if (online != null) {
            Messages.send(online, CoreMessage.FRIEND_REQUEST_RECEIVED, self.method_7334().getName());
        }

        return 1;
    }

    // ---------------------------------------------------------------------
    // /friend accept <player>
    // ---------------------------------------------------------------------

    private int accept(class_2168 src, String name) {
        if (!canUse(src)) {
            Messages.send(src, CoreMessage.NO_PERMISSION);
            return 0;
        }

        class_3222 self = src.method_44023();
        if (self == null) {
            Messages.send(src, CoreMessage.ONLY_PLAYERS);
            return 0;
        }

        FriendService friends = friendsOrFail(src);
        if (friends == null) return 0;

        Optional<UUID> fromOpt = PlayerLookup.resolveUuid(src.method_9211(), name);
        if (fromOpt.isEmpty()) {
            Messages.send(src, CoreMessage.PLAYER_UNKNOWN, name);
            return 0;
        }

        UUID from = fromOpt.get();
        boolean ok = friends.acceptRequest(self.method_5667(), from);

        if (!ok) {
            Messages.send(src, CoreMessage.FRIEND_ACCEPT_FAILED, name);
            return 0;
        }

        Messages.send(self, CoreMessage.FRIEND_ACCEPTED, name);

        // Wenn der andere online: Feedback
        class_3222 otherOnline = src.method_9211().method_3760().method_14602(from);
        if (otherOnline != null) {
            Messages.send(otherOnline, CoreMessage.FRIEND_ACCEPTED_OTHER, self.method_7334().getName());
        }

        return 1;
    }

    // ---------------------------------------------------------------------
    // /friend deny <player>
    // ---------------------------------------------------------------------

    private int deny(class_2168 src, String name) {
        if (!canUse(src)) {
            Messages.send(src, CoreMessage.NO_PERMISSION);
            return 0;
        }

        class_3222 self = src.method_44023();
        if (self == null) {
            Messages.send(src, CoreMessage.ONLY_PLAYERS);
            return 0;
        }

        FriendService friends = friendsOrFail(src);
        if (friends == null) return 0;

        Optional<UUID> fromOpt = PlayerLookup.resolveUuid(src.method_9211(), name);
        if (fromOpt.isEmpty()) {
            Messages.send(src, CoreMessage.PLAYER_UNKNOWN, name);
            return 0;
        }

        UUID from = fromOpt.get();
        boolean ok = friends.denyRequest(self.method_5667(), from);

        if (!ok) {
            Messages.send(src, CoreMessage.FRIEND_DENY_FAILED, name);
            return 0;
        }

        Messages.send(self, CoreMessage.FRIEND_DENIED, name);

        class_3222 otherOnline = src.method_9211().method_3760().method_14602(from);
        if (otherOnline != null) {
            Messages.send(otherOnline, CoreMessage.FRIEND_DENIED_OTHER, self.method_7334().getName());
        }

        return 1;
    }

    // ---------------------------------------------------------------------
    // /friend remove <player>
    // ---------------------------------------------------------------------

    private int remove(class_2168 src, String name) {
        if (!canUse(src)) {
            Messages.send(src, CoreMessage.NO_PERMISSION);
            return 0;
        }

        class_3222 self = src.method_44023();
        if (self == null) {
            Messages.send(src, CoreMessage.ONLY_PLAYERS);
            return 0;
        }

        FriendService friends = friendsOrFail(src);
        if (friends == null) return 0;

        Optional<UUID> otherOpt = PlayerLookup.resolveUuid(src.method_9211(), name);
        if (otherOpt.isEmpty()) {
            Messages.send(src, CoreMessage.PLAYER_UNKNOWN, name);
            return 0;
        }

        boolean ok = friends.removeFriend(self.method_5667(), otherOpt.get());
        if (!ok) {
            Messages.send(src, CoreMessage.FRIEND_REMOVE_FAILED, name);
            return 0;
        }

        Messages.send(self, CoreMessage.FRIEND_REMOVED, name);
        return 1;
    }

    // ---------------------------------------------------------------------
    // /friend list
    // ---------------------------------------------------------------------

    private int list(class_2168 src) {
        if (!canUse(src)) {
            Messages.send(src, CoreMessage.NO_PERMISSION);
            return 0;
        }

        class_3222 self = src.method_44023();
        if (self == null) {
            Messages.send(src, CoreMessage.ONLY_PLAYERS);
            return 0;
        }

        FriendService friends = friendsOrFail(src);
        if (friends == null) return 0;

        List<UUID> list = friends.getFriends(self.method_5667());
        if (list == null || list.isEmpty()) {
            Messages.send(self, CoreMessage.FRIEND_LIST_EMPTY);
            return 1;
        }

        Messages.send(self, CoreMessage.FRIEND_LIST_HEADER, list.size());

        for (UUID u : list) {
            String n = PlayerLookup.resolveName(src.method_9211(), u).orElse(u.toString().substring(0, 8));
            boolean online = src.method_9211().method_3760().method_14602(u) != null;

            class_2561 line = class_2561.method_43470(" - ")
                    .method_27692(class_124.field_1063)
                    .method_10852(class_2561.method_43470(n).method_27692(online ? class_124.field_1060 : class_124.field_1080))
                    .method_10852(class_2561.method_43470(online ? " (online)" : " (offline)").method_27692(class_124.field_1063));

            self.method_43496(line);
        }

        return 1;
    }

    // ---------------------------------------------------------------------
    // /friend requests
    // ---------------------------------------------------------------------

    private int requests(class_2168 src) {
        if (!canUse(src)) {
            Messages.send(src, CoreMessage.NO_PERMISSION);
            return 0;
        }

        class_3222 self = src.method_44023();
        if (self == null) {
            Messages.send(src, CoreMessage.ONLY_PLAYERS);
            return 0;
        }

        FriendService friends = friendsOrFail(src);
        if (friends == null) return 0;

        List<UUID> incoming = friends.getIncomingRequests(self.method_5667());
        List<UUID> outgoing = friends.getOutgoingRequests(self.method_5667());

        int in = incoming == null ? 0 : incoming.size();
        int out = outgoing == null ? 0 : outgoing.size();

        Messages.send(self, CoreMessage.FRIEND_REQUESTS_HEADER, in, out);

        if (in > 0) {
            Messages.send(self, CoreMessage.FRIEND_REQUESTS_INCOMING);
            for (UUID u : incoming) {
                String n = PlayerLookup.resolveName(src.method_9211(), u).orElse(u.toString().substring(0, 8));
                self.method_43496(class_2561.method_43470(" - " + n + "  §7(/friend accept " + n + " | /friend deny " + n + ")"));
            }
        }

        if (out > 0) {
            Messages.send(self, CoreMessage.FRIEND_REQUESTS_OUTGOING);
            for (UUID u : outgoing) {
                String n = PlayerLookup.resolveName(src.method_9211(), u).orElse(u.toString().substring(0, 8));
                self.method_43496(class_2561.method_43470(" - " + n));
            }
        }

        return 1;
    }

    // ---------------------------------------------------------------------
    // /friend msg <player> <message>
    // ---------------------------------------------------------------------

    private int msg(class_2168 src, String targetName, String message) {
        if (!canUse(src)) {
            Messages.send(src, CoreMessage.NO_PERMISSION);
            return 0;
        }

        class_3222 self = src.method_44023();
        if (self == null) {
            Messages.send(src, CoreMessage.ONLY_PLAYERS);
            return 0;
        }

        if (message == null || message.isBlank()) {
            Messages.send(self, CoreMessage.FRIEND_MSG_EMPTY);
            return 0;
        }

        FriendService friends = friendsOrFail(src);
        if (friends == null) return 0;

        Optional<UUID> targetOpt = PlayerLookup.resolveUuid(src.method_9211(), targetName);
        if (targetOpt.isEmpty()) {
            Messages.send(src, CoreMessage.PLAYER_UNKNOWN, targetName);
            return 0;
        }

        UUID target = targetOpt.get();

        if (!friends.areFriends(self.method_5667(), target)) {
            Messages.send(self, CoreMessage.FRIEND_MSG_NOT_FRIENDS, targetName);
            return 0;
        }

        // online => sofort DM (als Chat)
        class_3222 online = src.method_9211().method_3760().method_14602(target);
        if (online != null) {
            class_2561 toTarget = class_2561.method_43470("§b[DM] §f" + self.method_7334().getName() + "§7: §f" + message);
            online.method_43496(toTarget);

            Messages.send(self, CoreMessage.FRIEND_MSG_SENT, online.method_7334().getName());
            return 1;
        }

        // offline => persist
        OfflineFriendMessage off = new OfflineFriendMessage(
                target,
                self.method_5667(),
                self.method_7334().getName(),
                message,
                System.currentTimeMillis()
        );

        friends.sendOfflineMessage(off);
        Messages.send(self, CoreMessage.FRIEND_MSG_QUEUED, targetName);

        return 1;
    }

    // ---------------------------------------------------------------------
    // /friend gui
    // ---------------------------------------------------------------------
    private int executeGui(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        class_3222 player = src.method_44023();
        if (player == null) {
            Messages.send(src, CoreMessage.ONLY_PLAYERS);
            return 0;
        }

        dev.huntertagog.coresystem.common.friends.gui.FriendGuiServerNet.openFor(src.method_9211(), player);
        return 1;
    }
}
