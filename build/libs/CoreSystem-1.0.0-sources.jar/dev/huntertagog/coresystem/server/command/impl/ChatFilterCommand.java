package dev.huntertagog.coresystem.server.command.impl;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import dev.huntertagog.coresystem.common.chat.ChatFilterService;
import dev.huntertagog.coresystem.common.permission.PermissionKeys;
import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import dev.huntertagog.coresystem.common.text.CoreMessage;
import dev.huntertagog.coresystem.common.text.Messages;
import dev.huntertagog.coresystem.server.command.BaseCommand;
import dev.huntertagog.coresystem.server.command.CommandMeta;
import dev.huntertagog.coresystem.server.command.CoreCommand;
import java.util.Set;
import net.minecraft.class_2168;
import net.minecraft.class_7157;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

@CommandMeta(value = "coresystem_chatfilter", permission = PermissionKeys.STAFF_CHAT_ADMIN, enabled = true)
public final class ChatFilterCommand extends BaseCommand implements CoreCommand {

    public ChatFilterCommand() {
    }

    @Override
    public void register(CommandDispatcher<class_2168> dispatcher,
                         class_7157 registryAccess,
                         net.minecraft.class_2170.class_5364 environment) {

        dispatcher.register(
                method_9247("chatfilter")
                        // /chatfilter add <wort>
                        .then(method_9247("add")
                                .then(method_9244("word", StringArgumentType.word())
                                        .executes(ctx -> {
                                            class_2168 src = ctx.getSource();
                                            String word = StringArgumentType.getString(ctx, "word");

                                            ChatFilterService service = ServiceProvider.getService(ChatFilterService.class);
                                            if (service == null) {
                                                Messages.send(src, CoreMessage.SERVICE_UNAVAILABLE);
                                                return 0;
                                            }

                                            service.addBadWord(word);
                                            Messages.send(src, CoreMessage.CHATFILTER_ADDED, word.toLowerCase());
                                            return 1;
                                        })
                                )
                        )

                        // /chatfilter remove <wort>
                        .then(method_9247("remove")
                                .then(method_9244("word", StringArgumentType.word())
                                        .executes(ctx -> {
                                            class_2168 src = ctx.getSource();
                                            String word = StringArgumentType.getString(ctx, "word");

                                            ChatFilterService service = ServiceProvider.getService(ChatFilterService.class);
                                            if (service == null) {
                                                Messages.send(src, CoreMessage.SERVICE_UNAVAILABLE);
                                                return 0;
                                            }

                                            service.removeBadWord(word);
                                            Messages.send(src, CoreMessage.CHATFILTER_REMOVED, word.toLowerCase());
                                            return 1;
                                        })
                                )
                        )

                        // /chatfilter list
                        .then(method_9247("list")
                                .executes(ctx -> {
                                    class_2168 src = ctx.getSource();

                                    ChatFilterService service = ServiceProvider.getService(ChatFilterService.class);
                                    if (service == null) {
                                        Messages.send(src, CoreMessage.SERVICE_UNAVAILABLE);
                                        return 0;
                                    }

                                    Set<String> words = service.getBadWords();
                                    if (words.isEmpty()) {
                                        Messages.send(src, CoreMessage.CHATFILTER_LIST_EMPTY);
                                        return 1;
                                    }

                                    Messages.send(src, CoreMessage.CHATFILTER_LIST_HEADER, words.size());
                                    for (String w : words) {
                                        Messages.send(src, CoreMessage.CHATFILTER_LIST_ENTRY, w);
                                    }
                                    return 1;
                                })
                        )
        );
    }
}
