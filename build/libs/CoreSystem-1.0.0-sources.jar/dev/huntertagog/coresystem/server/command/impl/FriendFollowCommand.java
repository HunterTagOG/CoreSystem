package dev.huntertagog.coresystem.server.command.impl;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import dev.huntertagog.coresystem.common.friends.FriendService;
import dev.huntertagog.coresystem.common.friends.follow.FollowLimitResolver;
import dev.huntertagog.coresystem.common.permission.PermissionService;
import dev.huntertagog.coresystem.common.player.PlayerContext;
import dev.huntertagog.coresystem.common.player.PlayerProfileLookup;
import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import dev.huntertagog.coresystem.common.text.CoreMessage;
import dev.huntertagog.coresystem.common.text.Messages;
import dev.huntertagog.coresystem.server.command.BaseCommand;
import dev.huntertagog.coresystem.server.command.CoreCommand;
import dev.huntertagog.coresystem.server.friends.follow.RedisDailyUsageCounter;
import dev.huntertagog.coresystem.server.friends.follow.RedisFollowRequestStore;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_3222;
import net.minecraft.class_7157;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public final class FriendFollowCommand extends BaseCommand implements CoreCommand {

    public FriendFollowCommand() {
    }

    private final RedisFollowRequestStore requests = new RedisFollowRequestStore();
    private final RedisDailyUsageCounter daily = new RedisDailyUsageCounter();

    @Override
    public void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {

        dispatcher.register(
                method_9247("friend")
                        .then(method_9247("follow")
                                // /friend follow <player>
                                .then(method_9244("player", StringArgumentType.word())
                                        .executes(ctx -> requestFollow(ctx.getSource(),
                                                StringArgumentType.getString(ctx, "player"))))
                                // /friend follow accept <player>
                                .then(method_9247("accept")
                                        .then(method_9244("player", StringArgumentType.word())
                                                .executes(ctx -> acceptFollow(ctx.getSource(),
                                                        StringArgumentType.getString(ctx, "player")))))
                                // /friend follow deny <player>
                                .then(method_9247("deny")
                                        .then(method_9244("player", StringArgumentType.word())
                                                .executes(ctx -> denyFollow(ctx.getSource(),
                                                        StringArgumentType.getString(ctx, "player")))))
                        )
        );
    }

    private int requestFollow(class_2168 source, String targetName) {
        class_3222 requester = source.method_44023();
        if (requester == null) {
            Messages.send(source, CoreMessage.ONLY_PLAYERS);
            return 0;
        }

        PermissionService perms = ServiceProvider.getService(PermissionService.class);
        if (perms == null || !perms.has(source, "coresystem.friend.follow.use")) {
            Messages.send(source, CoreMessage.NO_PERMISSION);
            return 0;
        }

        // Target muss online sein, sonst kannst du nicht "requesten"
        class_3222 target = source.method_9211().method_3760().method_14566(targetName);
        if (target == null) {
            Messages.send(source, CoreMessage.PLAYER_NOT_ONLINE, targetName);
            return 0;
        }

        UUID a = requester.method_5667();
        UUID b = target.method_5667();

        if (a.equals(b)) {
            Messages.send(source, CoreMessage.FOLLOW_SELF_DENY);
            return 0;
        }

        FriendService friends = ServiceProvider.getService(FriendService.class);
        if (friends == null || !friends.areFriends(a, b)) {
            Messages.send(source, CoreMessage.FOLLOW_NOT_FRIENDS);
            return 0;
        }

        // Daily Limit
        int limit = FollowLimitResolver.resolveDailyLimit(perms, source);
        if (limit != Integer.MAX_VALUE) {
            int used = daily.get(a);
            if (used >= limit) {
                Messages.send(source, CoreMessage.FOLLOW_DAILY_LIMIT, used, limit);
                return 0;
            }
        }

        // Duplicate request?
        if (requests.hasRequest(b, a)) {
            Messages.send(source, CoreMessage.FOLLOW_ALREADY_REQUESTED, target.method_7334().getName());
            return 0;
        }

        // Store request (TTL)
        requests.putRequest(b, a, requester.method_7334().getName(), System.currentTimeMillis());

        // Notify both
        Messages.send(requester, CoreMessage.FOLLOW_REQUEST_SENT, target.method_7334().getName());
        Messages.send(target, CoreMessage.FOLLOW_REQUEST_RECEIVED, requester.method_7334().getName());

        return 1;
    }

    private int acceptFollow(class_2168 source, String requesterName) {
        class_3222 target = source.method_44023();
        if (target == null) {
            Messages.send(source, CoreMessage.ONLY_PLAYERS);
            return 0;
        }

        class_3222 requester = source.method_9211().method_3760().method_14566(requesterName);
        if (requester == null) {
            Messages.send(source, CoreMessage.PLAYER_NOT_ONLINE, requesterName);
            return 0;
        }

        UUID targetId = target.method_5667();
        UUID requesterId = requester.method_5667();

        if (!requests.hasRequest(targetId, requesterId)) {
            Messages.send(source, CoreMessage.FOLLOW_NO_REQUEST, requester.method_7334().getName());
            return 0;
        }

        // Consume request first (so it can’t be replayed)
        requests.removeRequest(targetId, requesterId);

        // Daily usage increments on the requester (the one who is following)
        PermissionService perms = ServiceProvider.getService(PermissionService.class);
        int limit = (perms != null) ? FollowLimitResolver.resolveDailyLimit(perms, requester.method_5671()) : 3;
        if (limit != Integer.MAX_VALUE) {
            int usedNow = daily.incrementAndGet(requesterId);
            if (usedNow > limit) {
                // exceeded due to race: deny the follow
                Messages.send(requester, CoreMessage.FOLLOW_DAILY_LIMIT, usedNow, limit);
                Messages.send(target, CoreMessage.FOLLOW_ACCEPT_RACE_DENY, requester.method_7334().getName());
                return 0;
            }
        }

        // Resolve target last location from your PlayerContext method
        PlayerContext ctx = PlayerContext.of(requester); // requester context
        Optional<PlayerProfileLookup.LastLocation> locOpt = ctx.resolveLastLocation(targetId);

        if (locOpt.isEmpty() || locOpt.get().lastServer().equalsIgnoreCase("unknown")) {
            Messages.send(requester, CoreMessage.FOLLOW_TARGET_LOCATION_UNKNOWN, target.method_7334().getName());
            Messages.send(target, CoreMessage.FOLLOW_ACCEPTED_BUT_UNKNOWN, requester.method_7334().getName());
            return 1;
        }

        String serverName = locOpt.get().lastServer();

        // Notify
        Messages.send(requester, CoreMessage.FOLLOW_ACCEPTED, target.method_7334().getName(), serverName);
        Messages.send(target, CoreMessage.FOLLOW_ACCEPTED_TARGET, requester.method_7334().getName());

        // Proxy connect
        String cmd = "proxycommand \"server " + serverName + "\"";
        source.method_9211().method_3734().method_44252(requester.method_5671().method_9217(), cmd);

        return 1;
    }

    private int denyFollow(class_2168 source, String requesterName) {
        class_3222 target = source.method_44023();
        if (target == null) {
            Messages.send(source, CoreMessage.ONLY_PLAYERS);
            return 0;
        }

        class_3222 requester = source.method_9211().method_3760().method_14566(requesterName);
        if (requester == null) {
            Messages.send(source, CoreMessage.PLAYER_NOT_ONLINE, requesterName);
            return 0;
        }

        UUID targetId = target.method_5667();
        UUID requesterId = requester.method_5667();

        if (!requests.hasRequest(targetId, requesterId)) {
            Messages.send(source, CoreMessage.FOLLOW_NO_REQUEST, requester.method_7334().getName());
            return 0;
        }

        requests.removeRequest(targetId, requesterId);

        Messages.send(target, CoreMessage.FOLLOW_DENIED_TARGET, requester.method_7334().getName());
        Messages.send(requester, CoreMessage.FOLLOW_DENIED, target.method_7334().getName());

        return 1;
    }
}
