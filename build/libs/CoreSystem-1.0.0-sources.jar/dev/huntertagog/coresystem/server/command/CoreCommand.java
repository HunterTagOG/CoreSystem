package dev.huntertagog.coresystem.server.command;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_7157;

public interface CoreCommand {

    /**
     * Registrierung im Brigadier-Dispatcher.
     */
    void register(CommandDispatcher<class_2168> dispatcher,
                  class_7157 registryAccess,
                  class_2170.class_5364 environment);

    /**
     * Internes Flag: wurde in diesem Command ein `.requires(...)` gesetzt?
     */
    default void markRequiresUsed() {
    }

    /**
     * Read-only Flag für den CommandsProvider.
     */
    default boolean isRequiresUsed() {
        return false;
    }
}
