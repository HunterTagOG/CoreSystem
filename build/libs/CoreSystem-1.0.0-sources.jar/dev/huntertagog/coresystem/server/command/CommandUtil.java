package dev.huntertagog.coresystem.server.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.common.permission.CorePermission;
import dev.huntertagog.coresystem.common.permission.PermissionService;
import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import java.util.Map;
import net.minecraft.class_2168;

import static dev.huntertagog.coresystem.server.command.BaseCommand.logger;
import static net.minecraft.class_2170.method_9247;

public final class CommandUtil {

    private CommandUtil() {
    }

    // ------------------------------------------------------------------------
    // INTERNER HILFER – Permission check mit CoreError-Handling
    // ------------------------------------------------------------------------
    private static boolean safeHasPermission(
            PermissionService perms,
            class_2168 source,
            CorePermission perm,
            BaseCommand owner
    ) {
        try {
            return perms != null && perms.has(source, perm);
        } catch (Exception e) {
            CoreError error = new CoreError(
                    CoreErrorCode.PERMISSION_CHECK_FAILED,
                    CoreErrorSeverity.ERROR,
                    "Permission check failed in CommandUtil.requirePermission()",
                    e,
                    Map.of(
                            "command", owner.getClass().getName(),
                            "permission", perm.key(),
                            "source", source.method_9214()
                    )
            );
            logger("CommandUtil").error(error.toLogString(), e);
            return false; // sicherer Fallback
        }
    }

    // ------------------------------------------------------------------------
    // requirePermission(...)
    // ------------------------------------------------------------------------
    public static LiteralArgumentBuilder<class_2168> requirePermission(
            BaseCommand command,
            CorePermission perm,
            LiteralArgumentBuilder<class_2168> builder
    ) {
        PermissionService permissionService = ServiceProvider.getService(PermissionService.class);
        command.markRequiresUsed();

        return builder.requires(source -> safeHasPermission(permissionService, source, perm, command));
    }

    // ------------------------------------------------------------------------
    // literalWithPermission(...)
    // ------------------------------------------------------------------------
    public static LiteralArgumentBuilder<class_2168> literalWithPermission(
            BaseCommand command,
            String name,
            CorePermission perm
    ) {
        PermissionService permissionService = ServiceProvider.getService(PermissionService.class);
        command.markRequiresUsed();

        return method_9247(name)
                .requires(source -> safeHasPermission(permissionService, source, perm, command));
    }
}
