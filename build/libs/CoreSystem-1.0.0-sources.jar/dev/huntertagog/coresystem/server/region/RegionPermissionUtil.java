package dev.huntertagog.coresystem.server.region;

import dev.huntertagog.coresystem.common.player.PlayerRelationshipUtil;
import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import dev.huntertagog.coresystem.common.region.RegionFlag;
import dev.huntertagog.coresystem.common.region.RegionService;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/**
 * Region-Permissions inkl. Friends + Clans.
 * <p>
 * Regel:
 * - keine Region -> erlaubt
 * - Owner -> erlaubt
 * - Friend / Clan-Manager des Owners -> erlaubt
 * - Flag nicht gesetzt -> erlaubt
 * - Flag gesetzt und nicht trusted -> deny
 */
public final class RegionPermissionUtil {

    private RegionPermissionUtil() {
    }

    public static boolean canBreak(class_3218 world, class_2338 pos, class_3222 player) {
        return canModify(world, pos, player, RegionFlag.BLOCK_BREAK);
    }

    public static boolean canPlace(class_3218 world, class_2338 pos, class_3222 player) {
        return canModify(world, pos, player, RegionFlag.BLOCK_PLACE);
    }

    private static boolean canModify(class_3218 world,
                                     class_2338 pos,
                                     class_3222 player,
                                     RegionFlag flag) {

        RegionService regions = ServiceProvider.getService(RegionService.class);
        if (regions == null) {
            return true; // kein Region-System aktiv → kein Guard
        }

        List<RegionDefinition> regOpt = regions.findRegionsAt(world, pos);
        if (regOpt.isEmpty()) {
            return true; // keine Region an Pos → kein Guard
        }

        RegionDefinition region = regOpt.getFirst(); // die oberste Region
        UUID ownerId = region.ownerId();
        UUID actorId = player.method_5667();

        // Owner / Friends / Clan-Manager dürfen immer
        if (PlayerRelationshipUtil.isTrustedForOwner(ownerId, actorId)) {
            return true;
        }

        // Region ohne dieses Flag -> nichts zu tun
        return !region.flags().contains(flag);
    }
}
