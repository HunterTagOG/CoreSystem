package dev.huntertagog.coresystem.server.region;

import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import dev.huntertagog.coresystem.common.region.RegionFlag;
import dev.huntertagog.coresystem.common.region.RegionService;
import dev.huntertagog.coresystem.common.text.CoreMessage;
import dev.huntertagog.coresystem.common.text.Messages;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class RegionGuardHooks {

    private RegionGuardHooks() {
    }

    public static void register() {

        /* ---------------------------------------------------
         * 1) BLOCK BREAK
         * --------------------------------------------------- */
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {

            if (!(world instanceof class_3218 serverWorld)) return true;

            if (!(player instanceof class_3222 spe)) {
                return true;
            }

            RegionService regions = ServiceProvider.getService(RegionService.class);
            if (regions == null) return true;

            if (regions.hasFlagAt(serverWorld, pos, RegionFlag.BLOCK_BREAK)) {
                deny(player, CoreMessage.REGION_BLOCK_BREAK_DENY);
                return false;
            }

            if (!RegionPermissionUtil.canBreak(serverWorld, pos, spe)) {
                deny(spe, CoreMessage.REGION_BLOCK_BREAK_DENY);
                return false;
            }

            return true;
        });


        /* ---------------------------------------------------
         * 2) BLOCK PLACE  (UseBlockCallback)
         * --------------------------------------------------- */
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {

            if (!(world instanceof class_3218 serverWorld)) return class_1269.field_5811;

            if (!(player instanceof class_3222 spe)) {
                return class_1269.field_5811;
            }

            RegionService regions = ServiceProvider.getService(RegionService.class);
            if (regions == null) return class_1269.field_5811;

            // Player möchte am Block pos einen Block setzen
            class_2338 pos = hitResult.method_17777().method_10093(hitResult.method_17780());

            if (regions.hasFlagAt(serverWorld, pos, RegionFlag.BLOCK_PLACE)) {
                deny(player, CoreMessage.REGION_BLOCK_PLACE_DENY);
                return class_1269.field_5814; // blockiert Block-Place
            }

            if (!RegionPermissionUtil.canPlace(serverWorld, pos, spe)) {
                deny(spe, CoreMessage.REGION_BLOCK_PLACE_DENY);
                return class_1269.field_5814;
            }

            return class_1269.field_5811;
        });
    }


    private static void deny(class_1657 player, CoreMessage msg) {
        if (!(player instanceof class_3222 serverPlayerEntity)) return;
        Messages.send(serverPlayerEntity, msg);

        // Visuelles Feedback
        player.method_23667(player.method_6058(), true);
    }
}
