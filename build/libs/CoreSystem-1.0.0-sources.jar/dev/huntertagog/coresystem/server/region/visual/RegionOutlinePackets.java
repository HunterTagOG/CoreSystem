package dev.huntertagog.coresystem.server.region.visual;

import dev.huntertagog.coresystem.common.region.visual.RegionOutlinePayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public final class RegionOutlinePackets {

    private RegionOutlinePackets() {
    }

    public static void sendOutline(class_3222 player,
                                   class_2960 worldId,
                                   class_2338 min,
                                   class_2338 max,
                                   int colorArgb,
                                   int durationTicks) {

        RegionOutlinePayload payload = new RegionOutlinePayload(
                worldId, min, max, colorArgb, durationTicks
        );

        // NEUES API (1.20.5+)
        ServerPlayNetworking.send(player, payload);
    }
}
