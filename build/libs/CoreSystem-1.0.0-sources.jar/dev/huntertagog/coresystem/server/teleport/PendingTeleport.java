package dev.huntertagog.coresystem.server.teleport;

import org.jetbrains.annotations.Nullable;

import java.util.UUID;

public final class PendingTeleport {

    private final UUID playerUuid;
    private final String targetServer;      // z. B. "islands-1"
    private final String inventoryContext;  // z. B. "network-global" oder "pre-minigame"
    private final long createdAt;           // epoch millis
    private final @Nullable String reason;  // optional: "portal-islands", "hub-command"

    public PendingTeleport(UUID playerUuid,
                           String targetServer,
                           String inventoryContext,
                           long createdAt,
                           @Nullable String reason) {
        this.playerUuid = playerUuid;
        this.targetServer = targetServer;
        this.inventoryContext = inventoryContext;
        this.createdAt = createdAt;
        this.reason = reason;
    }

    public UUID playerUuid() {
        return playerUuid;
    }

    public String targetServer() {
        return targetServer;
    }

    public String inventoryContext() {
        return inventoryContext;
    }

    public long createdAt() {
        return createdAt;
    }

    public @Nullable String reason() {
        return reason;
    }
}
