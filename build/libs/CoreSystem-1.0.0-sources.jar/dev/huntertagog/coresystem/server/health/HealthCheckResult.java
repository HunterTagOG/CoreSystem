package dev.huntertagog.coresystem.server.health;

import dev.huntertagog.coresystem.common.health.HealthStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.Map;

public final class HealthCheckResult {

    private final @NotNull String name;
    private final @NotNull HealthStatus status;
    private final @NotNull String message;
    private final @NotNull Map<String, String> details;

    private HealthCheckResult(@NotNull String name,
                              @NotNull HealthStatus status,
                              @NotNull String message,
                              @NotNull Map<String, String> details) {
        this.name = name;
        this.status = status;
        this.message = message;
        this.details = Collections.unmodifiableMap(details);
    }

    public static HealthCheckResult of(@NotNull String name,
                                       @NotNull HealthStatus status,
                                       @NotNull String message,
                                       @Nullable Map<String, String> details) {
        return new HealthCheckResult(
                name,
                status,
                message,
                details != null ? details : Collections.emptyMap()
        );
    }

    public String name() {
        return name;
    }

    public HealthStatus status() {
        return status;
    }

    public String message() {
        return message;
    }

    public Map<String, String> details() {
        return details;
    }
}
