package dev.huntertagog.coresystem.server.event;

@FunctionalInterface
public interface DomainEventListener<E extends DomainEvent> {

    void onEvent(E event);
}
