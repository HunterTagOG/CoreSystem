package dev.huntertagog.coresystem.server.audit;

import com.google.gson.Gson;
import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.audit.AuditLogEntry;
import dev.huntertagog.coresystem.common.audit.AuditLogService;
import dev.huntertagog.coresystem.common.error.CoreError;
import dev.huntertagog.coresystem.common.error.CoreErrorCode;
import dev.huntertagog.coresystem.common.error.CoreErrorSeverity;
import dev.huntertagog.coresystem.server.redis.RedisClient;
import org.jetbrains.annotations.NotNull;
import redis.clients.jedis.Jedis;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public final class RedisAuditLogService implements AuditLogService {

    private static final Logger LOG = LoggerFactory.get("RedisAuditLogService");
    private static final String KEY_PREFIX = "cs:audit:";
    private static final int MAX_ENTRIES_PER_DAY = 50_000;

    private static final DateTimeFormatter DAY_FMT = DateTimeFormatter.BASIC_ISO_DATE; // yyyyMMdd

    private final Gson gson = new Gson();

    @Override
    public void log(@NotNull AuditLogEntry entry) {
        String day = DAY_FMT.format(LocalDate.now());
        String key = KEY_PREFIX + day;

        String json = gson.toJson(entry);

        try (Jedis jedis = RedisClient.get().getResource()) {
            jedis.rpush(key, json);
            jedis.ltrim(key, -MAX_ENTRIES_PER_DAY, -1);
        } catch (Exception e) {
            CoreError.of(
                            CoreErrorCode.AUDIT_LOG_WRITE_FAILED,
                            CoreErrorSeverity.WARN,
                            "Failed to append audit log entry to Redis"
                    )
                    .withCause(e)
                    .withContextEntry("redisKey", key)
                    .withContextEntry("action", entry.action())
                    .withContextEntry("actionType", entry.actionType().name())
                    .withContextEntry("actorType", entry.actorType().name())
                    .log();

            LOG.warn("Audit log write failed for action={} actor={}",
                    entry.action(), entry.actorName(), e);
        }
    }
}
