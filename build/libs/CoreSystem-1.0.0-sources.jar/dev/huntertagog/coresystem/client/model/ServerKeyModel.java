package dev.huntertagog.coresystem.client.model;

import dev.huntertagog.coresystem.common.item.impl.ServerKeyItem;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

public class ServerKeyModel extends GeoModel<ServerKeyItem> {

    @Override
    public class_2960 getModelResource(ServerKeyItem animatable) {
        return class_2960.method_60655("coresystem", "geo/server_key.geo.json");
    }

    @Override
    public class_2960 getTextureResource(ServerKeyItem animatable) {
        return class_2960.method_60655("coresystem", "textures/item/server_key.png");
    }

    @Override
    public class_2960 getAnimationResource(ServerKeyItem animatable) {
        return class_2960.method_60655("coresystem", "animations/server_key.animation.json");
    }
}
