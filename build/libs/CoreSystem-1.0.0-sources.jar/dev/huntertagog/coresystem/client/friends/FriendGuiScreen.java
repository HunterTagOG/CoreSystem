package dev.huntertagog.coresystem.client.friends;

import dev.huntertagog.coresystem.common.friends.gui.FriendGuiPackets;
import dev.huntertagog.coresystem.common.friends.gui.FriendGuiSnapshot;
import io.wispforest.owo.ui.base.BaseOwoScreen;
import io.wispforest.owo.ui.component.ButtonComponent;
import io.wispforest.owo.ui.component.CheckboxComponent;
import io.wispforest.owo.ui.component.Components;
import io.wispforest.owo.ui.container.Containers;
import io.wispforest.owo.ui.container.FlowLayout;
import io.wispforest.owo.ui.container.ScrollContainer;
import io.wispforest.owo.ui.container.StackLayout;
import io.wispforest.owo.ui.core.*;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1068;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_640;
import org.jetbrains.annotations.NotNull;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public final class FriendGuiScreen extends BaseOwoScreen<FlowLayout> {

    private static final DateTimeFormatter TS =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").withZone(ZoneId.systemDefault());

    private FriendGuiSnapshot snapshot;

    private StackLayout contentStack;

    private FlowLayout friendsContent;
    private FlowLayout incomingContent;
    private FlowLayout outgoingContent;

    private CheckboxComponent allowRequests;
    private CheckboxComponent allowFollow;
    private CheckboxComponent showLastSeen;

    private Component activePanel;

    public void applySnapshot(FriendGuiSnapshot snapshot) {
        this.snapshot = snapshot;
        if (this.uiAdapter != null) rebuildAll();
    }

    @Override
    protected @NotNull OwoUIAdapter<FlowLayout> createAdapter() {
        return OwoUIAdapter.create(this, Containers::verticalFlow);
    }

    @Override
    protected void build(FlowLayout root) {
        root.sizing(Sizing.fill(100), Sizing.fill(100));
        root.padding(Insets.of(10));
        root.gap(10);

        root.child(
                Components.label(class_2561.method_43470("Friends"))
                        .horizontalTextAlignment(HorizontalAlignment.CENTER)
                        .sizing(Sizing.fill(100), Sizing.fixed(18))
        );

        FlowLayout body = Containers.horizontalFlow(Sizing.fill(100), Sizing.fill(100));
        body.gap(10);

        // Tabs
        FlowLayout tabs = Containers.verticalFlow(Sizing.fixed(120), Sizing.fill(100));
        tabs.gap(6);

        // Content stack
        contentStack = Containers.stack(Sizing.fill(100), Sizing.fill(100));
        contentStack.id("content");

        Component friendsPanel = buildFriendsPanel().id("panel_friends");
        Component requestsPanel = buildRequestsPanel().id("panel_requests");
        Component settingsPanel = buildSettingsPanel().id("panel_settings");

        // Default: friends anzeigen
        activePanel = friendsPanel;
        contentStack.child(activePanel);

        // Tabs
        tabs.child(Components.button(class_2561.method_43470("Friends"), b -> switchPanel(friendsPanel)));
        tabs.child(Components.button(class_2561.method_43470("Requests"), b -> switchPanel(requestsPanel)));
        tabs.child(Components.button(class_2561.method_43470("Settings"), b -> switchPanel(settingsPanel)));

        body.child(tabs);
        body.child(contentStack);

        root.child(body);

        if (snapshot != null) rebuildAll();
    }

    private void switchPanel(Component next) {
        if (contentStack == null || next == null) return;

        if (activePanel != null) {
            contentStack.removeChild(activePanel);
        }
        activePanel = next;
        contentStack.child(activePanel);
    }

    private Component buildFriendsPanel() {
        FlowLayout panel = Containers.verticalFlow(Sizing.fill(100), Sizing.fill(100));
        panel.gap(6);

        friendsContent = Containers.verticalFlow(Sizing.fill(100), Sizing.content());
        friendsContent.gap(4);

        ScrollContainer<FlowLayout> scroll = Containers.verticalScroll(
                Sizing.fill(100),
                Sizing.fill(100),
                friendsContent
        );

        panel.child(scroll);
        return panel;
    }

    private Component buildRequestsPanel() {
        FlowLayout panel = Containers.verticalFlow(Sizing.fill(100), Sizing.fill(100));
        panel.gap(10);

        panel.child(Components.label(class_2561.method_43470("Incoming")).color(Color.ofRgb(0xA0A0A0)));

        incomingContent = Containers.verticalFlow(Sizing.fill(100), Sizing.content());
        incomingContent.gap(4);

        panel.child(Containers.verticalScroll(Sizing.fill(100), Sizing.fixed(160), incomingContent));

        panel.child(Components.label(class_2561.method_43470("Outgoing")).color(Color.ofRgb(0xA0A0A0)));

        outgoingContent = Containers.verticalFlow(Sizing.fill(100), Sizing.content());
        outgoingContent.gap(4);

        panel.child(Containers.verticalScroll(Sizing.fill(100), Sizing.fixed(160), outgoingContent));

        return panel;
    }

    private Component buildSettingsPanel() {
        FlowLayout panel = Containers.verticalFlow(Sizing.fill(100), Sizing.fill(100));
        panel.gap(8);

        allowRequests = Components.checkbox(class_2561.method_43470("Allow friend requests"));
        allowFollow = Components.checkbox(class_2561.method_43470("Allow follow"));
        showLastSeen = Components.checkbox(class_2561.method_43470("Show last seen"));

        ButtonComponent save = Components.button(class_2561.method_43470("Save"), b -> pushSettings());

        panel.child(allowRequests);
        panel.child(allowFollow);
        panel.child(showLastSeen);
        panel.child(save);

        return panel;
    }

    private void rebuildAll() {
        rebuildFriends();
        rebuildRequests();
        applySettings();
    }

    private void rebuildFriends() {
        if (friendsContent == null) return;
        friendsContent.clearChildren();

        if (snapshot == null || snapshot.friends().isEmpty()) {
            friendsContent.child(Components.label(class_2561.method_43470("No friends yet.")).color(Color.ofRgb(0xA0A0A0)));
            return;
        }

        for (var f : snapshot.friends()) {
            friendsContent.child(friendRow(f));
        }
    }

    private Component friendRow(FriendGuiSnapshot.FriendEntry f) {
        FlowLayout row = Containers.horizontalFlow(Sizing.fill(100), Sizing.fixed(30));
        row.verticalAlignment(VerticalAlignment.CENTER);
        row.gap(8);

        row.child(playerHead(f.uuid(), 20));

        String status = f.online() ? "Online" : "Offline";
        class_2561 name = class_2561.method_43470(f.name()).method_27692(f.online() ? class_124.field_1060 : class_124.field_1080);

        String lastSeen = "-";
        if (!f.online() && snapshot.settings().showLastSeen() && f.lastSeenEpochMillis() > 0) {
            lastSeen = TS.format(Instant.ofEpochMilli(f.lastSeenEpochMillis()));
        }

        FlowLayout textCol = Containers.verticalFlow(Sizing.fill(100), Sizing.fixed(30));
        textCol.child(Components.label(name).sizing(Sizing.fill(100), Sizing.fixed(12)));
        textCol.child(Components.label(class_2561.method_43470(status + " | Last: " + lastSeen))
                .color(Color.ofRgb(0xA0A0A0))
                .sizing(Sizing.fill(100), Sizing.fixed(12)));

        row.child(textCol);

        ButtonComponent remove = Components.button(class_2561.method_43470("Remove"), b -> sendRemove(f.uuid()));
        remove.sizing(Sizing.fixed(70), Sizing.fixed(20));
        row.child(remove);

        return row;
    }

    private void rebuildRequests() {
        if (incomingContent == null || outgoingContent == null) return;

        incomingContent.clearChildren();
        outgoingContent.clearChildren();

        if (snapshot == null) return;

        if (snapshot.incoming().isEmpty()) {
            incomingContent.child(Components.label(class_2561.method_43470("No incoming requests.")).color(Color.ofRgb(0xA0A0A0)));
        } else {
            for (var r : snapshot.incoming()) incomingContent.child(incomingRow(r));
        }

        if (snapshot.outgoing().isEmpty()) {
            outgoingContent.child(Components.label(class_2561.method_43470("No outgoing requests.")).color(Color.ofRgb(0xA0A0A0)));
        } else {
            for (var r : snapshot.outgoing()) outgoingContent.child(outgoingRow(r));
        }
    }

    private Component incomingRow(FriendGuiSnapshot.RequestEntry r) {
        FlowLayout row = Containers.horizontalFlow(Sizing.fill(100), Sizing.fixed(26));
        row.verticalAlignment(VerticalAlignment.CENTER);
        row.gap(8);

        row.child(playerHead(r.uuid(), 18));
        row.child(Components.label(class_2561.method_43470(r.name())).sizing(Sizing.fill(100), Sizing.fixed(18)));

        ButtonComponent accept = Components.button(class_2561.method_43470("Accept"), b -> sendAccept(r.uuid()));
        ButtonComponent deny = Components.button(class_2561.method_43470("Deny"), b -> sendDeny(r.uuid()));
        accept.sizing(Sizing.fixed(60), Sizing.fixed(18));
        deny.sizing(Sizing.fixed(50), Sizing.fixed(18));

        row.child(accept);
        row.child(deny);

        return row;
    }

    private Component outgoingRow(FriendGuiSnapshot.RequestEntry r) {
        FlowLayout row = Containers.horizontalFlow(Sizing.fill(100), Sizing.fixed(26));
        row.verticalAlignment(VerticalAlignment.CENTER);
        row.gap(8);

        row.child(playerHead(r.uuid(), 18));
        row.child(Components.label(class_2561.method_43470(r.name())).sizing(Sizing.fill(100), Sizing.fixed(18)));

        ButtonComponent cancel = Components.button(class_2561.method_43470("Cancel"), b -> sendCancel(r.uuid()));
        cancel.sizing(Sizing.fixed(60), Sizing.fixed(18));
        row.child(cancel);

        return row;
    }

    private void applySettings() {
        if (snapshot == null || allowRequests == null) return;
        allowRequests.checked(snapshot.settings().allowRequests());
        allowFollow.checked(snapshot.settings().allowFollow());
        showLastSeen.checked(snapshot.settings().showLastSeen());
    }

    // ----------------------------------------
    // Checkbox → boolean (OWO versionssicher)
    // ----------------------------------------
    private static boolean readChecked(CheckboxComponent box) {
        try {
            // neuere OWO-Versionen
            return (boolean) box.getClass().getMethod("checked").invoke(box);
        } catch (Exception ignored) {
        }

        try {
            // ältere OWO-Versionen
            return (boolean) box.getClass().getMethod("isChecked").invoke(box);
        } catch (Exception ignored) {
        }

        try {
            // Fallback
            return (boolean) box.getClass().getMethod("value").invoke(box);
        } catch (Exception ignored) {
        }

        return false;
    }

    // ------------------------------------------------------------
    // Head as textures (no custom component, no sizing-issues)
    // ------------------------------------------------------------

    private Component playerHead(UUID uuid, int sizePx) {
        class_2960 skin = resolveSkin(uuid);

        var head = Components.texture(skin, 8, 8, 8, 8, 64, 64);
        var hat = Components.texture(skin, 40, 8, 8, 8, 64, 64);

        StackLayout box = Containers.stack(Sizing.fixed(sizePx), Sizing.fixed(sizePx));
        box.child(head);
        box.child(hat);
        return box;
    }

    private class_2960 resolveSkin(UUID uuid) {
        class_310 mc = class_310.method_1551();
        if (mc != null && mc.method_1562() != null) {
            class_640 entry = mc.method_1562().method_2871(uuid);
            if (entry != null) {
                return entry.method_52810().comp_1626();
            }
        }
        // deine Mapping-Version hat offenbar nur getTexture() ohne UUID → nimm Default (Steve/Alex)
        return class_1068.method_4649();
    }

    // ------------------------------------------------------------
    // New payload networking (ClientPlayNetworking.send(CustomPayload))
    // ------------------------------------------------------------

    private void sendAccept(UUID from) {
        ClientPlayNetworking.send(new FriendGuiPackets.C2SAccept(from));
    }

    private void sendDeny(UUID from) {
        ClientPlayNetworking.send(new FriendGuiPackets.C2SDeny(from));
    }

    private void sendRemove(UUID other) {
        ClientPlayNetworking.send(new FriendGuiPackets.C2SRemove(other));
    }

    private void sendCancel(UUID target) {
        ClientPlayNetworking.send(new FriendGuiPackets.C2SCancel(target));
    }

    private void pushSettings() {
        boolean allowReq = readChecked(allowRequests);
        boolean allowFol = readChecked(allowFollow);
        boolean showLast = readChecked(showLastSeen);

        ClientPlayNetworking.send(
                new FriendGuiPackets.C2SSetSettings(
                        allowReq,
                        allowFol,
                        showLast
                )
        );
    }

    @Override
    public void method_25419() {
        super.method_25419();
        FriendGuiClientNet.clearCurrent();
    }
}
