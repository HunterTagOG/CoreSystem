package dev.huntertagog.coresystem.client.util;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_642;
import java.util.Locale;
import java.util.Set;

@Environment(EnvType.CLIENT)
public final class ServerEnvironmentUtil {

    // hier trägst du alle „legalen“ Server ein
    private static final Set<String> ALLOWED_HOSTS = Set.of(
            "play.cobblecrew.net",
            "mc.cobblecrew.net"
    );

    private ServerEnvironmentUtil() {
    }

    /**
     * true, wenn der Client gerade mit einem deiner Server verbunden ist.
     */
    public static boolean isCobbleverseServer() {
        class_310 client = class_310.method_1551();

        // Singleplayer / Lan -> verbieten
        if (client.method_1576() != null) {
            return false;
        }

        class_634 handler = client.method_1562();
        if (handler == null) {
            return false;
        }

        class_642 info = handler.method_45734();
        if (info == null || info.field_3761 == null) {
            return false;
        }

        String addr = info.field_3761.toLowerCase(Locale.ROOT).trim();

        // typischerweise "play.cobblecrew.net", "play.cobblecrew.net:25565", "123.123.123.123:25565"
        if (addr.contains(":")) {
            addr = addr.substring(0, addr.indexOf(':'));
        }

        for (String allowed : ALLOWED_HOSTS) {
            if (addr.equalsIgnoreCase(allowed)) {
                return true;
            }
        }

        return false;
    }
}
