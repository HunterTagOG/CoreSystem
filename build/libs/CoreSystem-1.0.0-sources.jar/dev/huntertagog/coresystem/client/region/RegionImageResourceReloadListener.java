package dev.huntertagog.coresystem.client.region;

import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3264;

public final class RegionImageResourceReloadListener {

    private RegionImageResourceReloadListener() {
    }

    public static void register() {
        ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(
                new SimpleSynchronousResourceReloadListener() {
                    @Override
                    public class_2960 getFabricId() {
                        return class_2960.method_60655("coresystem", "region_image_reload");
                    }

                    @Override
                    public void method_14491(net.minecraft.class_3300 manager) {
                        // MVP: optional validation only – kein Upload erforderlich.
                        // Du kannst hier z.B. bei Bedarf fehlende Texturen loggen.
                    }
                }
        );
    }
}
