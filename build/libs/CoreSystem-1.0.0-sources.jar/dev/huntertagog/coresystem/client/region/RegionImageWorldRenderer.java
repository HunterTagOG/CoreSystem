package dev.huntertagog.coresystem.client.region;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.region.RegionImageDef;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import org.joml.Matrix4f;

public final class RegionImageWorldRenderer {

    private static Logger LOG = LoggerFactory.get("RegionImageWorldRenderer");

    private static final float EPS = 0.01f;
    private static final double MAX_RENDER_DISTANCE = 96.0; // Business-Default, nach Bedarf

    private RegionImageWorldRenderer() {
    }

    public static void init() {
        WorldRenderEvents.LAST.register(RegionImageWorldRenderer::renderAll);
    }

    private static void renderAll(WorldRenderContext ctx) {
        var client = class_310.method_1551();
        if (client.field_1687 == null) return;

        var frustum = ctx.frustum();
        var camera = ctx.camera();
        class_243 camPos = camera.method_19326();

        for (RegionImageDef def : RegionImageClientCache.snapshot().values()) {
            if (!def.worldId().equals(client.field_1687.method_27983().method_29177())) continue;

            // 1) Frustum Box (leicht “aufblasen”, damit nix flackert)
            class_238 box = def.bounds().method_1014(0.25);

            if (frustum != null && !frustum.method_23093(box)) continue;

            // 2) Distanz-Gate (Kosten senken)
            class_243 center = box.method_1005();
            if (center.method_1025(camPos) > (MAX_RENDER_DISTANCE * MAX_RENDER_DISTANCE)) continue;

            renderOne(ctx, def, camPos);
        }
        var consumers = ctx.consumers();
        if (consumers instanceof class_4597.class_4598 immediate) {
            immediate.method_22993(); // <- Ohne das bleibt es oft “unsichtbar”
        }
    }

    private static void renderOne(WorldRenderContext ctx, RegionImageDef def, class_243 camPos) {
        class_2960 tex = RegionImageClientMapper.textureIdentifier(String.valueOf(def.textureId()));
        LOG.info("[RegionImage] Binding texture {}", tex);

        class_4587 matrices = ctx.matrixStack();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        // MVP: depth test optional – du kannst das später togglen
        // RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);

        class_1921 layer = class_1921.method_23689(tex);
        class_4597 consumers = ctx.consumers();
        assert consumers != null;
        class_4588 vc = consumers.getBuffer(layer);

        assert matrices != null;
        matrices.method_22903();
        matrices.method_22904(-camPos.field_1352, -camPos.field_1351, -camPos.field_1350);

        drawRegionQuad(matrices, vc, def);

        matrices.method_22909();

        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
    }

    private static void drawRegionQuad(class_4587 matrices, class_4588 vc, RegionImageDef def) {
        final int light = 0xF000F0; // fullbright

        // bounds kommen bei dir als double
        final double minX = def.bounds().field_1323;
        final double minY = def.bounds().field_1322;
        final double minZ = def.bounds().field_1321;
        final double maxX = def.bounds().field_1320;
        final double maxY = def.bounds().field_1325;
        final double maxZ = def.bounds().field_1324;

        final Matrix4f mat = matrices.method_23760().method_23761();

        // -------------------------
        // FLOOR (oben korrekt, unten UV-flip)
        // -------------------------
        if (def.mode() == dev.huntertagog.coresystem.common.region.RegionImageMode.FLOOR) {
            final float yTop = (float) def.baseY() + EPS;
            final float yBottom = yTop - EPS * 2f;

            final float xL = (float) minX;
            final float xR = (float) maxX + 1f;
            final float zN = (float) minZ;
            final float zS = (float) maxZ + 1f;

            // TOP (normal +Y) UV normal
            quadUv(vc, mat,
                    xL, yTop, zN, 0f, 0f,
                    xR, yTop, zN, 1f, 0f,
                    xR, yTop, zS, 1f, 1f,
                    xL, yTop, zS, 0f, 1f,
                    light, 0f, 1f, 0f);

            // BOTTOM (normal -Y) -> U flip (1-u)
            quadUv(vc, mat,
                    xL, yBottom, zN, 1f, 0f,
                    xL, yBottom, zS, 1f, 1f,
                    xR, yBottom, zS, 0f, 1f,
                    xR, yBottom, zN, 0f, 0f,
                    light, 0f, -1f, 0f);

            return;
        }

        // -------------------------
        // WALL (Front normal, Back U-flip)
        // -------------------------
        class_2350 facing = class_2350.method_10168(String.valueOf(def.facing()));
        if (facing == null || facing.method_10166().method_10178()) facing = class_2350.field_11043;

        final float xL = (float) minX;
        final float xR = (float) maxX + 1f;
        final float yB = (float) minY;
        final float yT = (float) maxY + 1f;
        final float zN = (float) minZ;
        final float zS = (float) maxZ + 1f;

        switch (facing) {
            case field_11043 -> {
                final float zFront = zN - EPS;
                final float zBack = zFront + EPS * 2f;

                // FRONT (normal +Z)
                quadUv(vc, mat,
                        xL, yT, zFront, 0f, 0f,
                        xR, yT, zFront, 1f, 0f,
                        xR, yB, zFront, 1f, 1f,
                        xL, yB, zFront, 0f, 1f,
                        light, 0f, 0f, 1f);

                // BACK (normal -Z) -> U flip
                quadUv(vc, mat,
                        xL, yB, zBack, 1f, 1f,
                        xR, yB, zBack, 0f, 1f,
                        xR, yT, zBack, 0f, 0f,
                        xL, yT, zBack, 1f, 0f,
                        light, 0f, 0f, -1f);
            }

            case field_11035 -> {
                final float zFront = zS + EPS;
                final float zBack = zFront - EPS * 2f;

                // FRONT (normal -Z) (Player sieht SOUTH-Seite)
                quadUv(vc, mat,
                        xR, yT, zFront, 0f, 0f,
                        xL, yT, zFront, 1f, 0f,
                        xL, yB, zFront, 1f, 1f,
                        xR, yB, zFront, 0f, 1f,
                        light, 0f, 0f, -1f);

                // BACK (normal +Z) -> U flip
                quadUv(vc, mat,
                        xR, yB, zBack, 1f, 1f,
                        xL, yB, zBack, 0f, 1f,
                        xL, yT, zBack, 0f, 0f,
                        xR, yT, zBack, 1f, 0f,
                        light, 0f, 0f, 1f);
            }

            case field_11039 -> {
                final float xFront = xL - EPS;
                final float xBack = xFront + EPS * 2f;

                // FRONT (normal +X)
                quadUv(vc, mat,
                        xFront, yT, zN, 0f, 0f,
                        xFront, yT, zS, 1f, 0f,
                        xFront, yB, zS, 1f, 1f,
                        xFront, yB, zN, 0f, 1f,
                        light, 1f, 0f, 0f);

                // BACK (normal -X) -> U flip
                quadUv(vc, mat,
                        xBack, yB, zN, 1f, 1f,
                        xBack, yB, zS, 0f, 1f,
                        xBack, yT, zS, 0f, 0f,
                        xBack, yT, zN, 1f, 0f,
                        light, -1f, 0f, 0f);
            }

            case field_11034 -> {
                final float xFront = xR + EPS;
                final float xBack = xFront - EPS * 2f;

                // FRONT (normal -X)
                quadUv(vc, mat,
                        xFront, yT, zS, 0f, 0f,
                        xFront, yT, zN, 1f, 0f,
                        xFront, yB, zN, 1f, 1f,
                        xFront, yB, zS, 0f, 1f,
                        light, -1f, 0f, 0f);

                // BACK (normal +X) -> U flip
                quadUv(vc, mat,
                        xBack, yB, zS, 1f, 1f,
                        xBack, yB, zN, 0f, 1f,
                        xBack, yT, zN, 0f, 0f,
                        xBack, yT, zS, 1f, 0f,
                        light, 1f, 0f, 0f);
            }
        }
    }

    private static void quadUv(class_4588 vc,
                               Matrix4f mat,
                               float x1, float y1, float z1, float u1, float v1,
                               float x2, float y2, float z2, float u2, float v2,
                               float x3, float y3, float z3, float u3, float v3,
                               float x4, float y4, float z4, float u4, float v4,
                               int light,
                               float nx, float ny, float nz) {

        vc.method_22918(mat, x1, y1, z1).method_1336(255, 255, 255, 255).method_22913(u1, v1).method_22922(class_4608.field_21444).method_60803(light).method_22914(nx, ny, nz);
        vc.method_22918(mat, x2, y2, z2).method_1336(255, 255, 255, 255).method_22913(u2, v2).method_22922(class_4608.field_21444).method_60803(light).method_22914(nx, ny, nz);
        vc.method_22918(mat, x3, y3, z3).method_1336(255, 255, 255, 255).method_22913(u3, v3).method_22922(class_4608.field_21444).method_60803(light).method_22914(nx, ny, nz);
        vc.method_22918(mat, x4, y4, z4).method_1336(255, 255, 255, 255).method_22913(u4, v4).method_22922(class_4608.field_21444).method_60803(light).method_22914(nx, ny, nz);
    }
}
