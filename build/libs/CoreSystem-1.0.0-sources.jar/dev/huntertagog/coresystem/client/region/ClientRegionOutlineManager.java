package dev.huntertagog.coresystem.client.region;

import com.google.common.collect.Lists;
import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_761;
import net.minecraft.client.render.*;
import java.util.List;

public final class ClientRegionOutlineManager {

    private static final Logger LOG = LoggerFactory.get("RegionOutlineClient");

    private static ClientRegionOutlineManager INSTANCE;

    private static final class Outline {
        final class_2960 worldId;
        final class_238 box;
        final int color;
        long expireAt; // world time in ticks

        Outline(class_2960 worldId, class_238 box, int color, long expireAt) {
            this.worldId = worldId;
            this.box = box;
            this.color = color;
            this.expireAt = expireAt;
        }
    }

    private final List<Outline> outlines = Lists.newCopyOnWriteArrayList();

    private ClientRegionOutlineManager() {
        WorldRenderEvents.AFTER_ENTITIES.register(this::onRender);
    }

    public static void init() {
        if (INSTANCE == null) {
            INSTANCE = new ClientRegionOutlineManager();
            LOG.info("ClientRegionOutlineManager initialized.");
        }
    }

    public static ClientRegionOutlineManager getInstance() {
        return INSTANCE;
    }

    public void addOutline(class_2960 worldId,
                           class_2338 min,
                           class_2338 max,
                           int colorArgb,
                           int durationTicks) {

        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) return;

        int minX = Math.min(min.method_10263(), max.method_10263());
        int minY = Math.min(min.method_10264(), max.method_10264());
        int minZ = Math.min(min.method_10260(), max.method_10260());
        int maxX = Math.max(min.method_10263(), max.method_10263()) + 1;
        int maxY = Math.max(min.method_10264(), max.method_10264()) + 1;
        int maxZ = Math.max(min.method_10260(), max.method_10260()) + 1;

        class_238 box = new class_238(minX, minY, minZ, maxX, maxY, maxZ);
        long now = mc.field_1687.method_8510();
        long expireAt = now + durationTicks;

        outlines.add(new Outline(worldId, box, colorArgb, expireAt));
    }

    private void onRender(WorldRenderContext ctx) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) return;

        class_2960 currentWorldId = mc.field_1687.method_27983().method_29177();
        long time = mc.field_1687.method_8510();

        class_4184 camera = ctx.camera();
        class_4587 matrices = ctx.matrixStack();

        // consumers() ist als VertexConsumerProvider getypt
        class_4597 provider = ctx.consumers();
        if (!(provider instanceof class_4597.class_4598 vcp)) {
            // sollte in der Praxis nie passieren, aber defensiv.
            return;
        }

        class_4588 consumer = vcp.getBuffer(class_1921.method_23594());

        double camX = camera.method_19326().field_1352;
        double camY = camera.method_19326().field_1351;
        double camZ = camera.method_19326().field_1350;

        // abgelaufene Outlines rauswerfen
        outlines.removeIf(o -> o.expireAt <= time);

        for (Outline o : outlines) {
            if (!o.worldId.equals(currentWorldId)) continue;

            assert matrices != null;
            matrices.method_22903();

            double x1 = o.box.field_1323 - camX;
            double y1 = o.box.field_1322 - camY;
            double z1 = o.box.field_1321 - camZ;
            double x2 = o.box.field_1320 - camX;
            double y2 = o.box.field_1325 - camY;
            double z2 = o.box.field_1324 - camZ;

            float a = ((o.color >> 24) & 0xFF) / 255.0f;
            float r = ((o.color >> 16) & 0xFF) / 255.0f;
            float g = ((o.color >> 8) & 0xFF) / 255.0f;
            float b = (o.color & 0xFF) / 255.0f;

            class_761.method_22980(matrices, consumer, x1, y1, z1, x2, y2, z2, r, g, b, a);
            matrices.method_22909();
        }

        // Buffer flushen
        vcp.method_22993();
    }
}
