package dev.huntertagog.coresystem;

import dev.huntertagog.coresystem.common.Log.Logger;
import dev.huntertagog.coresystem.common.Log.LoggerFactory;
import dev.huntertagog.coresystem.common.item.ModItemGroups;
import dev.huntertagog.coresystem.common.item.ModItems;
import dev.huntertagog.coresystem.common.message.DefaultPlayerMessageService;
import dev.huntertagog.coresystem.common.message.PlayerMessageService;
import dev.huntertagog.coresystem.common.provider.ServiceProvider;
import dev.huntertagog.coresystem.common.rct.rewards.RctRewardHooks;
import dev.huntertagog.coresystem.server.command.CommandsProvider;
import dev.huntertagog.coresystem.server.net.ServerSwitcherNetworking;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1802;
import net.minecraft.class_7706;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Läuft auf Client + Server.
 * Muss client-safe sein: KEIN Redis, KEIN LuckPerms, KEINE ServerLifecycle/Join-Events, KEINE Server-Only Klassen.
 */
public final class CoresystemCommon implements ModInitializer {

    private static final Logger LOG = LoggerFactory.get("CoreSystem");
    public static final String MOD_ID = "coresystem";

    @Override
    public void onInitialize() {
        // --------------------------------------------------------------------
        // Statische Registrierungen (client-safe)
        // --------------------------------------------------------------------
        ModItems.init();
        ModItemGroups.init();
        RctRewardHooks.register();

        // Wenn ServerSwitcherNetworking wirklich client-safe ist, kann es bleiben.
        // Falls es Server-only Networking registriert: raus hier, rein in ServerInit.
        ServerSwitcherNetworking.init();

        // ItemGroup Ergänzung (client-safe)
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(entries ->
                entries.addAfter(class_1802.field_8251, ModItems.SERVER_KEY)
        );

        // --------------------------------------------------------------------
        // Services, die wirklich client-agnostisch sind (ohne Redis!)
        // --------------------------------------------------------------------
        ServiceProvider.registerService(CommandsProvider.class, new CommandsProvider());
        ServiceProvider.registerService(PlayerMessageService.class, new DefaultPlayerMessageService());

        LOG.info("CoreSystem common init completed.");
    }

    public static Path getConfigDir() {
        Path base = FabricLoader.getInstance().getConfigDir().resolve("coresystem");
        try {
            Files.createDirectories(base);
        } catch (IOException e) {
            throw new RuntimeException("Failed to create coresystem config directory", e);
        }
        return base;
    }
}
